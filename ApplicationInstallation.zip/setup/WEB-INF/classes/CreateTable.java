import java.io.*;
import java.net.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.Date;

//import portal.PortalUser;

public class CreateTable extends HttpServlet 
{  private PortalUserAccessor myDataAccessor = null;
   
  public void init(ServletConfig config) throws ServletException 
    {
        super.init(config);
     	String value = null;
		String dbDriver = "com.mysql.jdbc.Driver"; 
	    String dbURL =  "jdbc:mysql://localhost/games";
	   	String userid = "ilias";
	   	String passwd = "7107";
	 	myDataAccessor = new PortalUserAccessor(dbDriver, dbURL, userid, passwd);
	}
  
  
   public void doPost( HttpServletRequest req, HttpServletResponse res )
      throws ServletException, IOException
   { // set up response to client
  // 	 String name = req.getParameter("name");
       	String name = "ilias";
    	boolean status;
    	boolean stat=false;
		HttpSession session = req.getSession();
		String portalUser;
	
	if (name.equals("ilias"))	
	{	try
		{	stat =myDataAccessor.PlayerList1();
			if (stat) 
			{ System.out.println("SQL statement is  executed!");
			session.setAttribute("errorMessage","�������������� �� �������!");
        	  RequestDispatcher rd =getServletConfig().getServletContext().getRequestDispatcher("/portal-login2.jsp");
			 rd.forward(req, res);
			}
			else
			{System.out.println("SQL statement is not executed!");
       		 session.setAttribute("errorMessage","SQL statement is not executed!");
        	RequestDispatcher rd =getServletConfig().getServletContext().getRequestDispatcher("/portal-login3.jsp");
			rd.forward(req, res);
			}
			
		}
	 	catch (Exception e)
		{	session.setAttribute("errorMessage","�������� ����� ���������! ��������� ��������.");
			RequestDispatcher rd =getServletConfig().getServletContext().getRequestDispatcher("/portal-login3.jsp");
			rd.forward(req, res);
			return;
		}
		
	   status =new File("/RLGames").mkdir() ;
	   status =new File("/RLGames/Games").mkdir() ;
	  // System.out.println("neo")
	  }
	  else
	  {  session.setAttribute("errorMessage","����� ����� � ������� ������");
      	RequestDispatcher rd =getServletConfig().getServletContext().getRequestDispatcher("/portal-login3.jsp");
			rd.forward(req, res);
     
	  }

}
}
