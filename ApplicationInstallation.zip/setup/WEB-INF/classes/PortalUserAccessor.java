import java.sql.*;
import java.io.*;
import java.io.File;
import java.util.*;


public class PortalUserAccessor
{
    // data members
    private Connection dbConnection;
    private PreparedStatement displayStatement;
    private PreparedStatement registerStatement;
   String stat;
 
  	/**
	 *  Constructor that make a database connection and prepares SQL statements
	 */
    public PortalUserAccessor(String dbDriver, String dbURL, String userID, String passwd)
    {       
        // use println statements to send status messages to web server console
        try {
            log("GamesDataAccessor init: Start");
            
            log("GamesDataAccessor init: Loading Database Driver: " + dbDriver);
            Class.forName(dbDriver);
            
            log("GamesDataAccessor init: Getting a connection to - " + dbURL);
           // dbConnection = DriverManager.getConnection(dbURL, userID, passwd);
            dbConnection = DriverManager.getConnection(dbURL, userID, passwd);
            log("GamesDataAccessor init: Preparing display statement");
            }
  
        catch (Exception e)
        {
            cleanUp();
            log(e);   
        }      
    }

    
	/**
	 *  Closes the database connection
	 */
    public void cleanUp()
    {
        try {
            log("Closing database connection");
            dbConnection.close();
        }
        catch (SQLException e)
        {
            log(e);   
        }        
    }
    
	/**
	 *  Queries the database and gets a list of players
	 */
   

	public boolean PlayerList1()  
    {
        boolean status;
        boolean stat=false;
       //Vector gamesVector = new Vector();
         try {
            
           registerStatement = dbConnection.prepareStatement
	         ("CREATE TABLE   games.genikastoixeia (login varchar(30) NOT NULL,numOfWinGames int,numOfLostGames int ,numOfMovesForGainedGames int,	numOfMovesForLostGames int,	numOfMoves int,	PRIMARY KEY (login))");
		  	registerStatement.executeUpdate();  
			registerStatement = dbConnection.prepareStatement
			("CREATE TABLE   games.peximata (login varchar(30),	adate DATE,arxtime TIME,tdate DATE,teltime TIME,ergasia varchar (10),PRIMARY KEY (login,adate,arxtime))");
	       	registerStatement.executeUpdate();  
	      	registerStatement = dbConnection.prepareStatement
		 	("CREATE TABLE   games.guestbook (login varchar(30),adate DATE,arxtime TIME, sxolia varchar (255),PRIMARY KEY (login,adate,arxtime))");
	       	registerStatement.executeUpdate();  
	       	stat=true;
	     }
	       catch (Exception e)
       	 {  stat=false;
       	 	}
       	 finally
       	 { return stat;
       	 }
   
       
	    
	}
	/**
	 *  Simply closes the database connection
	 */
    public void destroy()
    {
        log("GamesDataAccessor: destroy");
        cleanUp();
    }
      
	/**
	 *  Simple method for logging messages to console.
	 */
    protected void log(Object msg)
    {
        System.out.println(msg);    
    }
}
