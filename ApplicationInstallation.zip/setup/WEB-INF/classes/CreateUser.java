import java.io.*;
import java.net.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.Date;

//import portal.PortalUser;

public class CreateUser extends HttpServlet  
{ 
	 public void init(ServletConfig config) throws ServletException 
    {
        super.init(config);
     	String value = null;
	
	}
  
   
   public void doPost( HttpServletRequest req, HttpServletResponse res )
      throws ServletException, IOException
   { // set up response to client
   		String name=null;
   		String name1=null;
   		String name2=null;
      	 name = req.getParameter("name");
      	  name1 = req.getParameter("name1");
      	  name2 = req.getParameter("name2");	
		HttpSession session = req.getSession();
	//	PortalUser portalUser;
	if (name.equals("ilias"))	
	{ try{
      	Class.forName("com.mysql.jdbc.Driver");
      	String a=null;
      	if  (name1.equals(""))
      	{	name1="root";
      	
      	}
      //	if (name2.equals(null))jdbc:mysql://hostname:port/database?autoReconnect=true&useUnicode=true
      //	{	name2=null;}
      	System.out.println("name "+name +" name1 "+name1+" name2 "+name2);
     	Connection	 con1 = DriverManager.getConnection("jdbc:mysql://localhost/mysql?autoReconnect=true&useUnicode=true",name1,name2);
        try{
      	  Statement st = con1.createStatement();
          st.executeUpdate("CREATE DATABASE games DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci");
          Statement st1 = con1.createStatement();	
         st1.executeUpdate("GRANT SELECT, INSERT,UPDATE,DELETE,CREATE, DROP, INDEX,ALTER ON games.* TO ilias IDENTIFIED BY 'ilias'");	 
          Statement st3 = con1.createStatement();	
          
       //   st3.executeUpdate("create database games CHARACTER SET utf8 COLLATE utf8_general_ci ");
          session.setAttribute("errorMessage","��������������:  USER ��� Database");
          System.out.println("SQL statement is  executed!");
          RequestDispatcher rd =getServletConfig().getServletContext().getRequestDispatcher("/portal-login1.jsp");
		 rd.forward(req, res);
    //	 con1.close();
          }
     	 catch (SQLException s){
        	System.out.println("SQL statement is not executed!");
       		 session.setAttribute("errorMessage","SQL statement is not executed!");
        	RequestDispatcher rd =getServletConfig().getServletContext().getRequestDispatcher("/portal-login.jsp");
			rd.forward(req, res);
        }
     }
    catch (Exception e){
      e.printStackTrace();
      session.setAttribute("errorMessage","  is not connection");
      	RequestDispatcher rd =getServletConfig().getServletContext().getRequestDispatcher("/portal-login.jsp");
			rd.forward(req, res); 
    } 
    }
    else
    { session.setAttribute("errorMessage","����� ����� � ������� ������");
      	RequestDispatcher rd =getServletConfig().getServletContext().getRequestDispatcher("/portal-login.jsp");
			rd.forward(req, res);
    }
 

}  
 }		