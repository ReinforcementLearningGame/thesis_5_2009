package portal;

public class PortalUser {
private String username;

public PortalUser(String username) {
	this.username=username;

}
public String getUsername() { return username; }

}