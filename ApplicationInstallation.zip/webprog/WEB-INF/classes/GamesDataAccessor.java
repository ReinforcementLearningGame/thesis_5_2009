import java.sql.*;
import java.io.*;
import java.io.File;
import java.util.*;
import register.Games;
import java.util.Date;


public class GamesDataAccessor implements Common 
{   
   double[][] v;// array of weights between layers 1->2
   double[][] w;
   int inputNodes,hiddenNodes,outputNodes;
   static int inputSize=DIMBOARD*DIMBOARD-2*DIMBASE*DIMBASE+5;
 
    // data members
    private Connection dbConnection;
    private PreparedStatement displayStatement;
    private PreparedStatement registerStatement;
    private PreparedStatement playerStatement;   
    private PreparedStatement saveStatement;  
     private PreparedStatement saveStatement1;  
    private PreparedStatement displayStatement1;
    private PreparedStatement deleteStatement;
     private PreparedStatement deleteStatement1;
    private PreparedStatement registerStatement1;
    private PreparedStatement ps = null;

  	private final int LOGIN_POSITION  = 1;
    //private final int PASSWORD_POSITION = 2;
    private final int NUMOFWINGAMES_POSITION  = 2;
    private final int NUMOFLOSTGAMES_POSITION = 3;
    private final int NUMOFMOVESFORGAINEDGAMES_POSITION = 4;
    private final int NUMOFMOVESFORLOSTGAMES_POSITION = 5;
    private final int NUMOFMOVES_POSITION     = 6;
 
  	/**
	 *  Constructor that make a database connection and prepares SQL statements
	 */
    public GamesDataAccessor(String dbDriver, String dbURL, String userID, String passwd)
    {       
        // use println statements to send status messages to web server console
        try {
            log("GamesDataAccessor init: Start");
            
            log("GamesDataAccessor init: Loading Database Driver: " + dbDriver);
            Class.forName(dbDriver);
            
            log("GamesDataAccessor init: Getting a connection to - " + dbURL);
            dbConnection = DriverManager.getConnection(dbURL, userID, passwd);
            
            log("GamesDataAccessor init: Preparing display statement");
        	Statement inst = dbConnection.createStatement();
   		    displayStatement1 = dbConnection.prepareStatement("select * from onlinestoixeia order by login ASC");
    PreparedStatement ps = null;
   		    displayStatement = dbConnection.prepareStatement("select * from genikastoixeia order by login ASC");
            log("GamesDataAccessor init: Preparing register statement");
            	registerStatement1 = 
               dbConnection.prepareStatement("insert into onlinestoixeia "+ 
               "(login ,numOfWinGames,numOfLostGames,numOfMovesForGainedGames,numOfMovesForLostGames , numOfMoves)"
                 +  " values (?, ?, ?, ?, ?, ? )");   
         	registerStatement = 
               dbConnection.prepareStatement("insert into genikastoixeia "+ 
               "(login ,numOfWinGames,numOfLostGames,numOfMovesForGainedGames,numOfMovesForLostGames , numOfMoves)"
                 +  " values (?, ?, ?, ?, ?, ? )");   
            playerStatement = 
             dbConnection.prepareStatement("select * from genikastoixeia where login=? ");      
            log("GamesDataAccessor init: End");
            saveStatement = dbConnection.prepareStatement
          ("update genikastoixeia set numOfWinGames=?,numOfLostGames=?,numOfMovesForGainedGames=?,numOfMovesForLostGames=? , numOfMoves=? where login =?");  
         saveStatement1 = dbConnection.prepareStatement
          ("update onlinestoixeia set numOfWinGames=?,numOfLostGames=?,numOfMovesForGainedGames=?,numOfMovesForLostGames=? , numOfMoves=? where login =?");  
		deleteStatement  = dbConnection.prepareStatement
               ("delete from onlinestoixeia where login=?");  
  	//	  deleteStatement1 = dbConnection.prepareStatement
      //    ("update onlinestoixeia set login=' ' where login =?");  
        }
        catch (Exception e)
        {
            cleanUp();
            log(e);   
        }     
    }

    
	/**
	 *  Closes the database connection
	 */
    public void cleanUp()
    {
        try {
            log("Closing database connection");
            dbConnection.close();
        }
        catch (SQLException e)
        {
            log(e);   
        }        
    }
    
	/**
	 *  Queries the database and gets a list of players
	 */
    public Vector getGamesList()
    {
        
        Vector gamesVector = new Vector();
        
        try
        {
            // execute the query to get a list of the players
			System.out.println("starting query...");
            ResultSet dataResultSet = displayStatement.executeQuery();
            System.out.println("finishing query...");
			
			Games aGames = null;

            // build a players vector based on database results
            int size = 1;
			while (dataResultSet.next())
            {
				System.out.println("building games = " + size);
          	    aGames = new Games(dataResultSet);
                gamesVector.addElement(aGames);
            	size++;	
            	
			}

            dataResultSet.close();
			System.out.println("result set closed\n\n");
        }
        catch (SQLException e)
        {
            log(e);    
        }
        finally
        {
          return gamesVector;    
        }
    }
 public Vector getGamesList1()
    {
        
        Vector gamesVector = new Vector();
        
        try
        {
            // execute the query to get a list of the players
			System.out.println("starting query...");
            ResultSet dataResultSet = displayStatement1.executeQuery();
            System.out.println("finishing query...");
			
			Games aGames = null;

            // build a players vector based on database results
            int size = 1;
			while (dataResultSet.next())
            {
				System.out.println("building games = " + size);
          	    aGames = new Games(dataResultSet);
                gamesVector.addElement(aGames);
            	size++;	
            	
			}

            dataResultSet.close();
			System.out.println("result set closed\n\n");
        }
        catch (SQLException e)
        {
            log(e);    
        }
        finally
        {
          return gamesVector;    
        }
    }
     
	public Vector GList (Games aGames)
    {	int size =1;
        boolean status;
        Vector gamesVector = new Vector();
         try {
            // set sql parameters
            playerStatement.setString(LOGIN_POSITION, aGames.getLogin());
		    ResultSet dataResultSet = playerStatement.executeQuery();
		    Games taGames = null;
      		while (dataResultSet.next())
            {
				System.out.println("na gyriso ena = emfanisi " + size);
          	    taGames = new Games(dataResultSet);
                gamesVector.addElement(taGames);
               	size++;	
			}

            dataResultSet.close();
            CreateList1(taGames);/////////////////////////////
			System.out.println("result set closed\n\n");          
        }
        catch (Exception e)
        {  System.out.println("result set closed\n\n");          
		}
		 finally
        { 
          return gamesVector;    
        }
	}	
	
/*	public void Deleteonline (Games aGames)
	{ boolean status;
        Vector gamesVector = new Vector();
         try {
             String a= aGames.getLogin();
             deleteStatement.setString(1,aGames.getLogin());
             System.out.println("mpika  - mpika "+a);  
	         int num=deleteStatement.executeUpdate(); 
	          System.out.println("mpika  - mpika"+aGames.getLogin()+"    "+num);
	          ps = dbConnection.prepareStatement("delete from onlinestoixeia where login = ?");
     	  	    ps.setString(1,aGames.getLogin());
      	 	  ps.executeUpdate();
	       	 	 ps = dbConnection.prepareStatement("delete from games.onlinestoixeia where login = ?");
     	  	    ps.setString(1,aGames.getLogin());
      	 	  ps.executeUpdate();
     	    }
	        catch(Exception e)
      {
          System.out.println("mpika oxi - mpika oxi");  
          e.printStackTrace();
      }
     finally {
		 try {
	        dbConnection.close();
	        
	      } catch (SQLException e) {
	        e.printStackTrace();
	      }
}
   }*/
	public void CreateList(Games aGames)
	{ boolean status;
        Vector gamesVector = new Vector();
         try {
              int g1= Integer.parseInt(aGames.getnumOfWinGames().trim());
	          int g2=Integer.parseInt(aGames.getnumOfLostGames().trim()) ;
	          int g3=Integer.parseInt(aGames.getnumOfMovesForGainedGames().trim()) ;
	          int g4=Integer.parseInt(aGames.getnumOfMovesForLostGames().trim());
	          int g5=Integer.parseInt(aGames.getnumOfMoves().trim()); 
            
            registerStatement.setString(LOGIN_POSITION, aGames.getLogin());
            registerStatement.setInt(NUMOFWINGAMES_POSITION,  g1 ); 
        	registerStatement.setInt(NUMOFLOSTGAMES_POSITION, g2);
            registerStatement.setInt(NUMOFMOVESFORGAINEDGAMES_POSITION, g3);
            registerStatement.setInt(NUMOFMOVESFORLOSTGAMES_POSITION, g4);
            registerStatement.setInt(NUMOFMOVES_POSITION, g5);
                	   	         
	        registerStatement.executeUpdate();  
	        }
	        catch(Exception e)
      {
          System.out.println("sorry");
          e.printStackTrace();
      }
   }
		public void CreateList1(Games aGames)
	{ boolean status;
        Vector gamesVector = new Vector();
         try {
              int g1= Integer.parseInt(aGames.getnumOfWinGames().trim());
	          int g2=Integer.parseInt(aGames.getnumOfLostGames().trim()) ;
	          int g3=Integer.parseInt(aGames.getnumOfMovesForGainedGames().trim()) ;
	          int g4=Integer.parseInt(aGames.getnumOfMovesForLostGames().trim());
	          int g5=Integer.parseInt(aGames.getnumOfMoves().trim()); 
            
            registerStatement1.setString(LOGIN_POSITION, aGames.getLogin());
            registerStatement1.setInt(NUMOFWINGAMES_POSITION,  g1 ); 
        	registerStatement1.setInt(NUMOFLOSTGAMES_POSITION, g2);
            registerStatement1.setInt(NUMOFMOVESFORGAINEDGAMES_POSITION, g3);
            registerStatement1.setInt(NUMOFMOVESFORLOSTGAMES_POSITION, g4);
            registerStatement1.setInt(NUMOFMOVES_POSITION, g5);
                	   	         
	        registerStatement1.executeUpdate();  
	        }
	        catch(Exception e)
      {
          System.out.println("sorry");
          e.printStackTrace();
      }
   }
    public void SaveList(Games aGames)
    {	int size =1;
        boolean status;
        Vector gamesVector = new Vector();
         try {
	           
		 	  int g1= Integer.parseInt(aGames.getnumOfWinGames().trim());
	          int g2=Integer.parseInt(aGames.getnumOfLostGames().trim()) ;
	          int g3=Integer.parseInt(aGames.getnumOfMovesForGainedGames().trim()) ;
	          int g4=Integer.parseInt(aGames.getnumOfMovesForLostGames().trim());
	          int g5=Integer.parseInt(aGames.getnumOfMoves().trim()); 
		    
		      saveStatement.setString(6, aGames.getLogin());
	        //  saveStatement.setString(6, aGames.getPassword());
	          saveStatement.setInt(1,  g1); 
	          saveStatement.setInt(2, g2 );
	          saveStatement.setInt(3, g3 );
	          saveStatement.setInt(4, g4);
	          saveStatement.setInt(5, g5);
		      saveStatement.execute();
			  System.out.println("perasa  closed\n\n="+g1);  //System.out.println("result 11 closed\n\n");          
        }
        catch (Exception e)
        {  	
				System.out.println("result 2 closed\n\n");   
		
		}	
		}
public void SaveList1(Games aGames)
    {	int size =1;
        boolean status;
        Vector gamesVector = new Vector();
         try {
	           
		 	  int g1= Integer.parseInt(aGames.getnumOfWinGames().trim());
	          int g2=Integer.parseInt(aGames.getnumOfLostGames().trim()) ;
	          int g3=Integer.parseInt(aGames.getnumOfMovesForGainedGames().trim()) ;
	          int g4=Integer.parseInt(aGames.getnumOfMovesForLostGames().trim());
	          int g5=Integer.parseInt(aGames.getnumOfMoves().trim()); 
		    
		      saveStatement1.setString(6, aGames.getLogin());
	        
	          saveStatement1.setInt(1,  g1); 
	          saveStatement1.setInt(2, g2 );
	          saveStatement1.setInt(3, g3 );
	          saveStatement1.setInt(4, g4);
	          saveStatement1.setInt(5, g5);
		      saveStatement1.execute();
		 
			  System.out.println("perasa  closed\n\n="+g1);  //System.out.println("result 11 closed\n\n");          
        }
        catch (Exception e)
        {  	
				System.out.println("result 2 closed\n\n");   
		
		}	
		}



  ///////////////////////////////
  	public final void initNetwork(String login)
   {
      int s,j,k,i;
      try
      {
 		 initWeights(1,login);
 		 initWeights(2,login);//loadWeights();  used for the next executions, loads the stored weights
	}
      catch(Exception e)
      { //den xriazete
 	 //     this.initWeights(); //used only for the first execution, just to randomize the weights
      
	}
}
public final void initWeights(int owner,String login)
   {
      int j,k,i;
      java.util.Date helpDate=new Date();  // variable used for randomization
      Random initWeight=new Random(helpDate.getTime());
      for(j=0;j<=hiddenNodes;j++)
      {
         for (k=0;k<outputNodes;k++)
         {
            w[j][k]= initWeight.nextDouble()-0.5;
            //System.out.printf("j "+w[j][k]);
         }
         for(i=0;i<=inputNodes;i++)
         {
            v[i][j]= initWeight.nextDouble()-0.5;
            //System.out.printf("h "+ v[i][j]);
         }
      }
      storeModel(owner,login);
      }
  	public final void storeModel(int owner,String login )
   {
    try
     {    
     
     ObjectOutputStream out1=new ObjectOutputStream(new FileOutputStream(( owner==1)? "/RLGames/Games/"+login+"/whWWeights":"/RLGames/Games/"+login+"/blWWeights"));
          out1.writeObject(w);
          out1.close();
          out1=new ObjectOutputStream(new FileOutputStream(( owner==1)? "/RLGames/Games/"+login+"/whVWeights":"/RLGames/Games/"+login+"/blVWeights"));
          out1.writeObject(v);
          out1.close();
      }
      catch(Exception e)
      {
          System.out.println("sorry");
          e.printStackTrace();
      }
   }
  
	public Vector PlayerList1(Games aGames)// 
    {
        boolean status;
        Vector gamesVector = new Vector();
         try {
            
            
            registerStatement.setString(LOGIN_POSITION, aGames.getLogin());
            registerStatement.setInt(NUMOFWINGAMES_POSITION,  0 ); 
        	registerStatement.setInt(NUMOFLOSTGAMES_POSITION, 0);
            registerStatement.setInt(NUMOFMOVESFORGAINEDGAMES_POSITION, 0);
            registerStatement.setInt(NUMOFMOVESFORLOSTGAMES_POSITION, 0);
            registerStatement.setInt(NUMOFMOVES_POSITION, 0);
                	   	         
	        registerStatement.executeUpdate();  
	        /////////////////////////
	          	 inputNodes=2*inputSize;
		      //number of hidden
		      hiddenNodes=inputSize;
		      //number of output=1
		      outputNodes=1;
		     
		       v=new double[inputNodes+1][hiddenNodes+1];
		      //weights from hidden to output layer
		      w=new double[hiddenNodes+1][outputNodes];
	        status =new File("/RLGames/Games/"+aGames.getLogin()).mkdir();
	        initNetwork(aGames.getLogin());
	        
	        ////////////////////
	         Games taGames=new Games(aGames.getLogin(),"0","0","0","0","0");
	         gamesVector.addElement(taGames);
	      }
         catch (Exception e)
       	 {
           
        	playerStatement.setString(1, aGames.getLogin());
            ResultSet dataResultSet = playerStatement.executeQuery();
        	Games taGames = null;

            // build a players vector based on database results
            int size = 1;
			while (dataResultSet.next())
            {
				System.out.println(" yparxei " + size);
          	    taGames = new Games(dataResultSet);
                gamesVector.addElement(taGames);
              		
            	size++;	
            	System.out.println("palaio");
			}

            dataResultSet.close();
        }
 	
       finally
        {
          return gamesVector;    
        } 
      
    }

	/**
	 *  Simply closes the database connection
	 */
    public void destroy()
    {
        log("GamesDataAccessor: destroy");
        cleanUp();
    }
      
	/**
	 *  Simple method for logging messages to console.
	 */
    protected void log(Object msg)
    {
        System.out.println(msg);    
    }
}
