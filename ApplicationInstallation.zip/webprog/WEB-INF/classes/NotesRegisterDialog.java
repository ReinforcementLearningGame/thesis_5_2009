import java.awt.*;
import javax.swing.*;
import register.BookNote;

public class NotesRegisterDialog extends Dialog 
{   BookNote theGames = null;
    boolean registerButtonPressed = false;
    

	String login;
	//String password;
	String aDate;
 	 String arxtime;
     String sxolia;;
	

	    
	public NotesRegisterDialog(Frame parent, boolean modal,String a)
	{
		super(parent, modal);
		
		setLayout(null);
	//	Color c= new Color(96,160,96);
		Color c=new Color(153,120,218);	
		setBackground(c);
		setSize(insets().left + insets().right +950,insets().top + insets().bottom + 400);
		label1 = new java.awt.Label(a);
		label1.setBounds(insets().left + 20,insets().top + 80,400,24);
		add(label1);
		loginTextField = new java.awt.TextField();
	 	loginTextField.setBackground(java.awt.Color.lightGray);
		loginTextField.setBounds(insets().left + 10,insets().top + 120,900,40);
		add(loginTextField);

		registerButton = new java.awt.Button();
		registerButton.setLabel(" R E G I S T E R ");
		registerButton.setBounds(insets().left + 50,insets().top + 312,100,24);
		registerButton.setBackground(java.awt.Color.lightGray);
		add(registerButton);
		cancelButton = new java.awt.Button();
		cancelButton.setLabel(" C A N C E L ");
		cancelButton.setBounds(insets().left + 350,insets().top + 312,80,24);
		cancelButton.setBackground(java.awt.Color.lightGray);
		add(cancelButton);
		setTitle("RLGame - Web version - v 1.0 - R E G I S T E R  ");
		

		//{{REGISTER_LISTENERS
		SymWindow aSymWindow = new SymWindow();
		this.addWindowListener(aSymWindow);
		SymAction lSymAction = new SymAction();
		cancelButton.addActionListener(lSymAction);
		registerButton.addActionListener(lSymAction);
		//}}
		
	}
	
	public void addNotify()
	{
  	    // Record the size of the window prior to calling parents addNotify.
	    Dimension d = getSize();

		super.addNotify();

		if (fComponentsAdjusted)
			return;

		// Adjust components according to the insets
		setSize(insets().left + insets().right + d.width, insets().top + insets().bottom + d.height);
		Component components[] = getComponents();
		for (int i = 0; i < components.length; i++)
		{
			Point p = components[i].getLocation();
			p.translate(insets().left, insets().top);
			components[i].setLocation(p);
		}
		fComponentsAdjusted = true;
	}

    // Used for addNotify check.
	boolean fComponentsAdjusted = false;



// 	{{DECLARE_CONTROLS
	java.awt.Label label1;
	java.awt.TextField loginTextField;
	java.awt.Button registerButton;
	java.awt.Button cancelButton;
//	}}

	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == NotesRegisterDialog.this)
				Dialog1_WindowClosing(event);
		}
	}
	
	void Dialog1_WindowClosing(java.awt.event.WindowEvent event)
	{
		dispose();
	}

	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == cancelButton)
				cancelButton_Action(event);
			else if (object == registerButton)
				registerButton_Action(event);
		}
	}

	void cancelButton_Action(java.awt.event.ActionEvent event)
	{
		// to do: code goes here.
        registerButtonPressed = false;		
		this.setVisible(false);
	}
	
	public boolean isRegisterButtonPressed()
	{
	    return registerButtonPressed;    
	}

	void registerButton_Action(java.awt.event.ActionEvent event)
	{
		// to do: code goes here.
		registerButtonPressed = true;
		
		sxolia = loginTextField.getText().trim();
 	 	aDate =null; 
	 	login =null; 
		arxtime=null; 
	
	    // create a Games object based on form data
		theGames = new BookNote(login,aDate,arxtime,sxolia);  
		// close this window and return to caller
		this.setVisible(false);
        
	}
	
 	public BookNote getGames()
	{
	    return theGames;    
	} 
}
