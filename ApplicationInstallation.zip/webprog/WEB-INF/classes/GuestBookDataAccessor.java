import java.sql.*;
import java.io.*;
import java.io.File;
import java.util.*;
import java.util.Calendar;

import java.net.*;
import java.awt.*;
import java.util.Date;
import java.text.DateFormat ;
import register.BookNote;

public class GuestBookDataAccessor
{
    // data members
    private Connection dbConnection;
    private PreparedStatement displayStatement1;
     private PreparedStatement displayStatement2;
      private PreparedStatement displayStatement3;
    private PreparedStatement registerStatement;
    private PreparedStatement playerStatement;   
    private PreparedStatement saveStatement;  
   	private final int LOGIN_POSITION  = 1;
  	private final int DATE_POSITION = 2;
  	private final int ARX_POSITION  = 3;
  	private final int NOT_POSITION = 4;
  

    

  	/**
	 *  Constructor that make a database connection and prepares SQL statements
	 */
    public GuestBookDataAccessor(String dbDriver, String dbURL, String userID, String passwd)
    {       
        // use println statements to send status messages to web server console
        try {
            log("GamesDataAccessor init: Start");
            
            log("GamesDataAccessor init: Loading Database Driver: " + dbDriver);
            Class.forName(dbDriver);
            
            log("GamesDataAccessor init: Getting a connection to - " + dbURL);
            dbConnection = DriverManager.getConnection(dbURL, userID, passwd);
            
            log("GamesDataAccessor init: Preparing display statement");
//        	 inst = dbConnection.createStatement();
			displayStatement1 = dbConnection.prepareStatement("select * from guestbook where adate=? order by login  desc");
   		    displayStatement2 = dbConnection.prepareStatement("select * from guestbook where login=? order by adate desc");
   		    displayStatement3 = dbConnection.prepareStatement("select * from guestbook order by adate desc ,arxtime desc");
            log("GamesDataAccessor init: Preparing register statement");
            registerStatement = 
               dbConnection.prepareStatement("insert into guestbook (login,aDate,arxtime,sxolia)values (?,?,?,?)");  
           saveStatement = dbConnection.prepareStatement
          ("update peximata set teltime=?,ergasia=? where login =? and adate=? and ergasia=?"  );  

          //  playerStatement = 
             dbConnection.prepareStatement("select * from guestbook order by login");      
          //  log("GamesDataAccessor init: End");
        }
        catch (Exception e)
        {
            cleanUp();
            log(e);   
        }     
    }

    
	/**
	 *  Closes the database connection
	 */
    public void cleanUp()
    {
        try {
            log("Closing database connection");
            dbConnection.close();
        }
        catch (SQLException e)
        {
            log(e);   
        }        
    }
    
	/**
	 *  Queries the database and gets a list of players
	 */
    public Vector getList (String epil)
    {
        
        Vector gamesVector = new Vector();
        
        try
        {        
            // execute the query to get a list of the players
			System.out.println("starting query...");
			ResultSet dataResultSet;
			if ( epil.equals("3"))
           	{	  dataResultSet = displayStatement3.executeQuery();}
           	else if ( epil.equals("1"))
           	{	  Calendar cal=Calendar.getInstance();    
		          Date myDate=new Date();
		          int year = cal.get(Calendar.YEAR); 
				  int month = cal.get(Calendar.MONTH)+1; 
				  int day = cal.get(Calendar.DAY_OF_MONTH);	
				  String ast=(year+"-"+month+"-"+day).toString();
			      displayStatement1.setString(1, ast);	
           		   dataResultSet = displayStatement1.executeQuery(); 
           	}
           	else
           	 {	displayStatement2.setString(1,epil);	
           		dataResultSet = displayStatement2.executeQuery(); 
           	
           	}	 
            System.out.println("finishing query...");
			
			BookNote apexnidia = null;

            // build a players vector based on database results
            int size = 1;
			while (dataResultSet.next())
            {
				System.out.println("building games = " + size);
          	    apexnidia = new BookNote(dataResultSet);
                gamesVector.addElement(apexnidia);
            	size++;	
            	
			}

            dataResultSet.close();
			System.out.println("result set closed\n\n");
        }
        catch (SQLException e)
        {
            log(e);    
        }
        finally
        {
          return gamesVector;    
        }
    }


	public void noteadd(BookNote aGames)// 
    {
        boolean status;
       // Vector gamesVector = new Vector();
         try {
           
            registerStatement.setString(LOGIN_POSITION, aGames.getLogin());
            registerStatement.setString(DATE_POSITION,aGames.getaDate());
            registerStatement.setString(ARX_POSITION,aGames.getarxtime());
            registerStatement.setString(NOT_POSITION,aGames.getsxolia()); 
            log("pexnidiDataAccessor: destroy  "+ aGames.getsxolia() +" "+ aGames.getLogin() +" "+aGames.getarxtime()+" "+aGames.getaDate());
         	registerStatement.executeUpdate();  
	       
	      }
         catch (Exception e)
       	 {
                log ("oxi ok");	
		}

           
           
    }
  public void SaveList(BookNote aGames)
    {	int size =1;
        boolean status;
        Vector gamesVector = new Vector();
         try {
	           Calendar cal=Calendar.getInstance();    
           Date myDate=new Date();
            String helpName=myDate.toString();
            helpName=helpName.substring(11,19);
      		helpName=helpName.replace(':',':');
         
            int year = cal.get(Calendar.YEAR); 
			int month = cal.get(Calendar.MONTH)+1; 
			int day = cal.get(Calendar.DAY_OF_MONTH);	
			String ast=(year+"-"+month+"-"+day).toString();
	         String a="U";
	         String b="I";
	         
	       
      	      saveStatement.setString(1, helpName);	   
      	       saveStatement.setString(2,a);
		      saveStatement.setString(3, aGames.getLogin());
		      saveStatement.setString(4, ast);
		       saveStatement.setString(5, b);
    
		      saveStatement.execute();
			  System.out.println("perasa update closed\n\n="+helpName+" "+b);  //System.out.println("result 11 closed\n\n");          
        }
        catch (Exception e)
        {  	
				System.out.println("result 2 closed\n\n");   
		
		}	
		}

           
           
   

	/**
	 *  Simply closes the database connection
	 */
    public void destroy()
    {
        log("GamesDataAccessor: destroy");
        cleanUp();
    }
      
	/**
	 *  Simple method for logging messages to console.
	 */
    protected void log(Object msg)
    {
        System.out.println(msg);    
    }
}
