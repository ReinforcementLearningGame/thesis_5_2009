import java.sql.*;
import java.io.*;
import java.io.File;
import java.util.*;
import register.Games;
import java.util.Date;


public class OnlineDataAccessor implements Common 
{   
  // double[][] v;// array of weights between layers 1->2
  // double[][] w;
  // int inputNodes,hiddenNodes,outputNodes;
  // static int inputSize=DIMBOARD*DIMBOARD-2*DIMBASE*DIMBASE+5;
 
    // data members
    private Connection dbConnection;
    private PreparedStatement displayStatement;
    private PreparedStatement registerStatement;
    private PreparedStatement playerStatement;   
    private PreparedStatement saveStatement;  
     private PreparedStatement saveStatement1;  
    private PreparedStatement displayStatement1;
    private PreparedStatement deleteStatement;
     private PreparedStatement deleteStatement1;
    private PreparedStatement registerStatement1;
    private PreparedStatement ps = null;

  	/**
	 *  Constructor that make a database connection and prepares SQL statements
	 */
    public OnlineDataAccessor(String dbDriver, String dbURL, String userID, String passwd)
    {       
        // use println statements to send status messages to web server console
        try {
            log("GamesDataAccessor init: Start");
            
            log("GamesDataAccessor init: Loading Database Driver: " + dbDriver);
            Class.forName(dbDriver);
            
            log("GamesDataAccessor init: Getting a connection to - " + dbURL);
            dbConnection = DriverManager.getConnection(dbURL, userID, passwd);
            
            log("GamesDataAccessor init: Preparing display statement");
        	Statement inst = dbConnection.createStatement();
   	
		deleteStatement  = dbConnection.prepareStatement
               ("delete from onlinestoixeia where login=?");  
  
        }
        catch (Exception e)
        {
            cleanUp();
            log(e);   
        }     
    }

    
	/**
	 *  Closes the database connection
	 */
    public void cleanUp()
    {
        try {
            log("Closing database connection");
            dbConnection.close();
        }
        catch (SQLException e)
        {
            log(e);   
        }        
    }
    
	/**
	 *  Queries the database and gets a list of players
	 */

	public void Deleteonline (Games aGames)
	{ boolean status;
        Vector gamesVector = new Vector();
         try {
             String a= aGames.getLogin();
             deleteStatement.setString(1,aGames.getLogin());
             System.out.println("mpika  - mpika "+a);  
	         int num=deleteStatement.executeUpdate(); 
	          System.out.println("mpika  - mpika"+aGames.getLogin()+"    "+num);
	          ps = dbConnection.prepareStatement("delete from onlinestoixeia where login = ?");
     	  	    ps.setString(1,aGames.getLogin());
      	 	  ps.executeUpdate();
	       	 	 ps = dbConnection.prepareStatement("delete from games.onlinestoixeia where login = ?");
     	  	    ps.setString(1,aGames.getLogin());
      	 	  ps.executeUpdate();
     	    }
	        catch(Exception e)
      {
          System.out.println("mpika oxi - mpika oxi");  
          e.printStackTrace();
      }

}

	/**
	 *  Simply closes the database connection
	 */
    public void destroy()
    {
        log("GamesDataAccessor: destroy");
        cleanUp();
    }
      
	/**
	 *  Simple method for logging messages to console.
	 */
    protected void log(Object msg)
    {
        System.out.println(msg);    
    }
}
