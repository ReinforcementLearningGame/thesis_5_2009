import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.net.*;
import register.stoixeiaModel;
import register.bariVect;
import register.barimono;

public class PlayServletVect extends HttpServlet 
{    
    private String CR = "\n";
   
  	 double[][] w;// array of weights between layers 2->3
  	 private boolean ok;
    private String Login;
   private int numOfWinGames; //# kerdismenon paixnidion
   private int numOfLostGames; //# xamenon paixnidion
   private int numOfMovesForGainedGames; //# kiniseon gia ta kerdismena paixnidia
   private int numOfMovesForLosedGames; //# kiniseon gia ta xamena paixnidia
   private int numOfMoves; //# kiniseon gia ola ta paixnidia

   private Vector historyOfAverageValuesPerMovePerGame;//mesos oros tis aksias ton kiniseon tou paikth gia kathe paixnidi
   private Vector valuesOfChoosenMoves; //ta values ton kiniseon pou epilegei o paiktis sto trexon paixnidi
   private Vector meanSquareDistanceFromNeuralNetBestSuggestions;
   private Vector meanSquareDistanceFromNeuralNetWorstSuggestions;
   private Vector neuralNetBestSuggestionsForPlayer;//dianysma me tis beltistes kiniseis pou  tou proteinei o ypologistis
   private Vector neuralNetWorstSuggestionsForPlayer;//dianysma me tis xeiroteres kiniseis pou  tou proteinei o ypologistis
   private Vector historyOfMovesPerGame; //poses kiniseis exei kanei se kathe paixnidi
   private Vector historyOfGamesResults;//an exei kerdisei i oxi se kathe paixnidi
    private int dimboard;
    private int dimbase;
    private int numofpawns;
    /**
	 *  This method is called the first time the servlet is loaded.  Simply
	 *  makes a connection to the database.
	 */
    public void init(ServletConfig config) throws ServletException 
    {
        super.init(config);
  
	}

	/**
	 *  This method is used for applets.
	 *
	 *  Receives and sends the data using object serialization.
	 *
	 *  Gets an input stream from the applet and reads a player object.  Then
	 *  registers the player using our data accessor.  Finally, sends a confirmation
	 *  message back to the applet.
	 */
      public void doPost(HttpServletRequest request,
                        HttpServletResponse response) 
           throws ServletException, IOException
    {   show("se Connected");
        ObjectInputStream inputFromApplet = null;
        Vector weights = null;        
        PrintWriter out = null;
        BufferedReader inTest = null;
        stoixeiaModel astoixeia=null;
      
        ObjectOutputStream outputToApplet;   
        try
        {  
            // get an input stream from the applet
	        inputFromApplet = new ObjectInputStream(request.getInputStream());
	        show("se Connected");
	     
	        // read the serialized  data from applet        
	        show("se Reading data...");
	        
	         astoixeia = (stoixeiaModel) inputFromApplet.readObject();
	        show("Finished reading.");
	        show("se confirmed  "+astoixeia.getLogin());
	        inputFromApplet.close();
	       Login=astoixeia.getLogin();
	       show("Login "+Login+" "+astoixeia.getdimboard()+" "+astoixeia.getdimbase() +" "+astoixeia.getnumofpawns());
	 
      try
      {
          ObjectInputStream in =new ObjectInputStream(new FileInputStream("/RLGames/Games/"+Login+"/"+Login+""+"_Model_{"+astoixeia.getdimboard()+""+astoixeia.getdimbase() +""+astoixeia.getnumofpawns()+"}.txt"));
          numOfWinGames=((Integer)in.readObject()).intValue();
          numOfLostGames=((Integer)in.readObject()).intValue();
          numOfMoves=((Integer)in.readObject()).intValue();
          numOfMovesForGainedGames=((Integer)in.readObject()).intValue();
          numOfMovesForLosedGames=((Integer)in.readObject()).intValue();
          historyOfAverageValuesPerMovePerGame=(Vector) in.readObject();
          historyOfMovesPerGame=(Vector) in.readObject();
          historyOfGamesResults=(Vector) in.readObject();
          meanSquareDistanceFromNeuralNetBestSuggestions=(Vector) in.readObject();
          meanSquareDistanceFromNeuralNetWorstSuggestions=(Vector) in.readObject(); 
          in.close();
        
      }
      catch(IOException e){
          numOfWinGames=-1;
          numOfLostGames=0;
          numOfMoves=0;
          numOfMovesForGainedGames=0;
          numOfMovesForLosedGames=0;
          historyOfAverageValuesPerMovePerGame=new Vector();
          meanSquareDistanceFromNeuralNetBestSuggestions=new Vector();
     	  meanSquareDistanceFromNeuralNetWorstSuggestions=new Vector();
          historyOfMovesPerGame=new Vector();
          historyOfGamesResults=new Vector();    
         }
     
     
		 bariVect modelVect =new bariVect (Login, dimboard, dimbase, numofpawns ,numOfWinGames,numOfLostGames,numOfMoves,numOfMovesForGainedGames,
		  numOfMovesForLosedGames,historyOfAverageValuesPerMovePerGame,historyOfMovesPerGame,
		  historyOfGamesResults,meanSquareDistanceFromNeuralNetBestSuggestions,
          meanSquareDistanceFromNeuralNetWorstSuggestions);        
        
	      show("se Complete.model read");
	      outputToApplet = new ObjectOutputStream(response.getOutputStream());
          if (numOfWinGames==-1){
            System.out.println("neos pektis den exv modelo..");
		  }
		  else
		  {    System.out.println("palios paiktis me model..."+numOfWinGames+" "+numOfLostGames+" "+numOfMoves);
            System.out.println(".."+numOfMovesForGainedGames+" "+ numOfMovesForLosedGames+" "+historyOfAverageValuesPerMovePerGame.firstElement());
		  }
           
            outputToApplet.writeObject(modelVect); 
            outputToApplet.flush();
            
            outputToApplet.close();
            System.out.println("Data transmission complete.");
        }
        catch ( Exception e)
        {	log("lathos piso");
			e.printStackTrace(); 
        } 
         
       
    }  
    
  
  
     /*
	 *  Destroys the servlet and calls cleanup to close the database connection
	 */
     public void destroy()
    {
        System.out.println("PlayServlet: destroy");
        
    }
    
	/**
	 *  Returns servlet information
	 */
    public String getServletInfo()
    {
        return "<i>Games Registration Servlet, v.06</i>";   
    }
    
	/**
	 *  Simple method for logging messages to the console.
	 */
    protected void show(String msg)
    {
        System.out.println(msg);    
    }
}
