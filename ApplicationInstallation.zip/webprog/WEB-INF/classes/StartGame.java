import java.awt.*;
import java.awt.List;
import java.awt.event.*;
import java.util.*;
import java.applet.*;
import javax.swing.*;
import java.io.*;
import java.net.*;
import register.Games;

public class StartGame extends JApplet implements Common 
{  
	public 	String hostName="localhost";
    public   int port=8080; 
     String Login1;
    
	
	 public void init()
 	{  Login1 = getParameter("Login1");
	    int i=1;
      	URL hostURL = getCodeBase();
     	hostName = hostURL.getHost();
        port = hostURL.getPort();
		if (port == -1)
		{
			port = 80;
		}
		i=1;
		while (i==1)	
		 {  Spiel mySpiel = new Spiel(DIMBOARD,DIMBASE,NUMOFPAWNS,Login1,port,hostName);
		    mySpiel.myVisualBoardFrame.clearVisualBoard();
		    String msg=Spiel.telos;
		     startDialog registerDialog = new startDialog(new Frame(), true,msg );
	        registerDialog.setVisible(true);
   
		     if (registerDialog.isRegisterButtonPressed())
		    {
		        i=1;
		    }
		    else
		    {
		       i=0;
		       OnlineDelete myWindow = new OnlineDelete(port, hostName, Login1);
		       myWindow.registerGames();
	           stop(); 
	           	try
					{   
				  		AppletContext  appletContext= getAppletContext  ();
						 URL url=null;
						 try
						{
		 			 		url =  new  URL("http://"+hostName+":" + port +"/webprog/index.html");
							appletContext.showDocument(url); 
						}
						catch   (MalformedURLException   e)  
						{
					//	log("Malformed System.err.println URL: "  + url); 
						}
					}
					catch   (Exception   e)  
						{
					//	log("Malformed System.err.println URL: "); 
						}
					//	}
		    }
		   
	}
	}
	}