package register;
import java.sql.*;
import java.util.*;

public class bari implements java.io.Serializable
{
    // data members
    private String Login;
    private String NameFile;
    private Vector vect;
       
    private final String CR = "\n";     // carriage return
       
    // constructors
    public  bari()
    {
    }
    
    public  bari(String  aLogin, String aNameFile,Vector  avect) 
    {
        Login = aLogin;
        NameFile=aNameFile;
        vect=avect;
        
      
    }
           
     public  bari(ResultSet dataResultSet)
    {
                
        try 
		{
			System.out.println("games() start");

            // assign data members
            Login = dataResultSet.getString("xn");
           
			System.out.println("games() complete"+Login);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }   
    }
 
    //  accessors
    public String getLogin()
    {
        return Login;   
    }
    
      public String getNameFile()
    {
        return NameFile;   
    }
   
     public  Vector getv()
    {	Vector result=new Vector();
        result=vect;
        return result ;   
    }
    //  methods
    //  normal text string representation
     public String toString()
    {	
        String replyString = "";
       
        replyString += "Login: " + Login + CR;
        
        
        return replyString;
    };
 
    //  returns data as HTML formatted un-ordered list
    
    // returns data formatted for an HTML table row
    public String toTableString(int rowNumber)
    {
        String replyString = "";   
        String tdBegin = "<td>";
        String tdEnd = "</td>" + CR;
                        
        replyString += "<tr>" + CR;
        replyString += tdBegin + rowNumber + tdEnd; 
        replyString += tdBegin + Login   + tdEnd;
       
        replyString += "</tr>" + CR; 
                
        return replyString;
    }
}