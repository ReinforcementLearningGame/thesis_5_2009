import java.awt.*;
//import register.Games;
public class GamesRegisterDialogHelp extends Dialog
{
    boolean registerButtonPressed = false;
    	    
	public GamesRegisterDialogHelp(Frame parent, boolean modal)
	{
		super(parent, modal);
		setLayout(null);
	//	Color c= new Color(96,160,96);
		Color c=new Color(153,120,218);	
	//	setBackground(java.awt.Color.c);
		setBackground(c);
		
		setSize(insets().left + insets().right + 511,insets().top + insets().bottom + 500);
		helpTextArea = new java.awt.TextArea();
		helpTextArea.setBounds(insets().left + 5,insets().top + 5,600,600);
		helpTextArea.setBackground(c);
		String sInfo=" \t\t\t  The game:\n";
        sInfo+="The game is played on a rectangular board of of dimension nxn.\nAt the lower left and upper right part of the board are located the players' bases, \neach of dimension axa. Each player posssess � pawns, that initially \nare inside the corresponding base, which is considered as one square \nand not as a set of squares.\n\n";
        sInfo+="\t\t\t  The goal:\n";
        sInfo+="Each player's goal is to get one of his pawns into the enemy base. \nIf a player runs out of pawns, the opponent is declared as winner.\n";
        sInfo+="\n\n\t\t\t  The rules:\n";
        sInfo+="Each pawn can move to an empty square that is vertically or horizontaly adjacent, \nprovided that the pawn's maximum distance from its base is not decreased. \nBackward moves are not allowed. As soon as a move has taken place, \nall pawns that have no legal move are pronounced 'inactive' and are removed.";
		sInfo+="\nHuman player starts out from bottom-left base";
		sInfo+="\nTo move a pawn out of the base, if there are any left,\n(a) click on the base, then   (b) click on an adjacent square";
 		sInfo+="\nTo move any other pawn,  \n(a) click on the pawn, then   (b) click on the target square";

		
		helpTextArea.setText(sInfo);
		helpTextArea.setEditable(false);
		add(helpTextArea);
		
	    
		registerButton = new java.awt.Button();
		registerButton.setLabel(" O K ");
		registerButton.setBounds(insets().left + 360,insets().top + 312,62,24);
		registerButton.setBackground(java.awt.Color.lightGray);
		add(registerButton);
	
	/*	cancelButton = new java.awt.Button();
		cancelButton.setLabel("Cancel");
		cancelButton.setBounds(insets().left + 432,insets().top + 312,60,24);
		cancelButton.setBackground(java.awt.Color.lightGray);
		add(cancelButton);*/
		setTitle("RLGame - Web version - v 2.0 - I N F O ");
		

		//{{REGISTER_LISTENERS
		SymWindow aSymWindow = new SymWindow();
		this.addWindowListener(aSymWindow);
		SymAction lSymAction = new SymAction();
	//	cancelButton.addActionListener(lSymAction);
		registerButton.addActionListener(lSymAction);
		//}}
		
	}
	
	public void addNotify()
	{
  	    // Record the size of the window prior to calling parents addNotify.
	    Dimension d = getSize();

		super.addNotify();

		if (fComponentsAdjusted)
			return;

		// Adjust components according to the insets
		setSize(insets().left + insets().right + d.width, insets().top + insets().bottom + d.height);
		Component components[] = getComponents();
		for (int i = 0; i < components.length; i++)
		{
			Point p = components[i].getLocation();
			p.translate(insets().left, insets().top);
			components[i].setLocation(p);
		}
		fComponentsAdjusted = true;
	}

    // Used for addNotify check.
	boolean fComponentsAdjusted = false;



// 	{{DECLARE_CONTROLS
 	java.awt.TextArea helpTextArea;
  	java.awt.Button registerButton;
	java.awt.Button cancelButton;
//	}}

	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == GamesRegisterDialogHelp.this)
				Dialog1_WindowClosing(event);
		}
	}
	
	void Dialog1_WindowClosing(java.awt.event.WindowEvent event)
	{
		dispose();
	}

	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == cancelButton)
				cancelButton_Action(event);
			else if (object == registerButton)
				registerButton_Action(event);
		}
	}

	void cancelButton_Action(java.awt.event.ActionEvent event)
	{
		// to do: code goes here.
        registerButtonPressed = false;		
		this.setVisible(false);
	}
	
	public boolean isRegisterButtonPressed()
	{
	    return registerButtonPressed;    
	}

	void registerButton_Action(java.awt.event.ActionEvent event)
	{
		// to do: code goes here.
		registerButtonPressed = true;
		this.setVisible(false);
        
	}
	
 }
