/***************
  Created by:  Panagiotis Kanellopoulos
  Modified by: Eirini Ntoutsi
  Operation: The class of the game ("spiel" is game in german)
*******/
import java.util.*;
import java.io.*;
import java.awt.*;
import java.util.StringTokenizer;
import javax.swing.*;


/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
public class Spiel implements Common
{
    static NeuralNet whiteNeural; //neural ner for the white player
    static NeuralNet blackNeural; //neural ner for the black player
    static Player whitePlayer; //human player
    static Player blackPlayer; //computer player
    static Player computerForWhitePlayer; //o ypologistis paizei parallila me ton human player
    static Pawn[] whitePawn;
    static Pawn[] blackPawn;
    static Position myPosition;
    static TextArea myStats=new TextArea(); //used for the statistics
    static int inputSize=DIMBOARD*DIMBOARD-2*DIMBASE*DIMBASE+5; //abbreviation
    static int boardDimBoard1;
    static int boardDimBase1;
    static int numOfPawns1;
     static String playerLogin1;
     static int port1;
    static String hostName1;
	static String telos=null;
    //interface variables
    public static VisualBoardFrame myVisualBoardFrame;

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
              /* constructor */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/


    public Spiel(int boardDimBoard,int boardDimBase,int numOfPawns,String playerLogin,int port,String hostName)
    {	boardDimBoard1=boardDimBoard;
	    boardDimBase1=boardDimBase;
	    numOfPawns1=numOfPawns;
	    playerLogin1=playerLogin;
	    port1=port;
	    hostName1=hostName;
	    GameBoard myBoard=new GameBoard(boardDimBoard,boardDimBase);
        whitePawn=new Pawn[numOfPawns];
        blackPawn=new Pawn[numOfPawns];

        whiteNeural=new NeuralNet(1,2*inputSize,inputSize,1,0.95,0.5,playerLogin,port,hostName);
        blackNeural=new NeuralNet(2,2*inputSize,inputSize,1,0.95,0.5,playerLogin,port,hostName);

        whitePlayer=new Player(1,playerLogin); //mono aftos exei montelo(einai o human)
        blackPlayer=new Player(2,"Computer");
        computerForWhitePlayer=new Player(3,"Computer");

        for (int i=0;i<numOfPawns;i++)
        {
           whitePawn[i]=new Pawn(i,true);
           blackPawn[i]=new Pawn(i,false);
        }

        myVisualBoardFrame =new VisualBoardFrame(whitePlayer,blackPlayer,computerForWhitePlayer,playerLogin,port,hostName);
        myVisualBoardFrame.visualBoard.inputFromTextField="";
        myVisualBoardFrame.setButtonsEnable(false,0);
        myPosition=new Position(whitePawn,blackPawn);
        int counter=1; //so as not to let a game last forever, the maximum number of moves is 10000
        int[] whiteDesc=new int[2]; //not used, description of the move made
        int[] blackDesc=new int[2]; //not used, description of the move made
        int[] computerForWhiteDesc=new int[2];
        boolean written=false;
        whitePlayer.modelOfPlayer.loadModel(port,hostName);
        int result=0;
        while ((myPosition.isFinal(whitePawn,blackPawn)==false)&&(counter<10000))
        {
          //System.out.println("........... Computer for the white human .........");
//Ti tha epaize o ypologistis sti thesi tou anthropou?
//PROSOXH:den prepei na peirakso to whitePawn,Gameboard.mySquare giati tha epireaso
//to paixnidi kalytera na ta kano copy kai na peirakso to antigrafo
           computerForWhiteDesc=computerForWhitePlayer.pickComputersMoveForWhiteHuman(whitePawn,GameBoard.mySquare);
           //ayto pou telika paizei  o anthropos
           whiteDesc=whitePlayer.humanWMoveFromKeyboard(whitePawn,GameBoard.mySquare);
           if (myPosition.isFinal(whitePawn,blackPawn)==false)
           {
               blackDesc=blackPlayer.pickBlackMove(blackPawn,GameBoard.mySquare);
               myVisualBoardFrame.setButtonsEnable(true,counter);
           }
           else
           {
               written=true;
               createStats(""+counter);//prosthese to sto myStats
               createStats("aspros");telos="HUMAN";
               storeGameMovesAndStats();
               whitePlayer.modelOfPlayer.increaseNumOfWinGames();
               whitePlayer.modelOfPlayer.increaseNumOfWinMoves(counter);
               whitePlayer.modelOfPlayer.updateHistoryOfMovesPerGame((double)counter);
               result=1;
               whitePlayer.modelOfPlayer.updateHistoryOfGamesResults(1);
           }
           counter++;
        }//end of while
        if((counter<10000)&&(written==false))
        {
           createStats(""+ (--counter));
           createStats("mavros");telos="COMPUTER";
           storeGameMovesAndStats();
           whitePlayer.modelOfPlayer.increaseNumOfLostGames();
           whitePlayer.modelOfPlayer.increaseNumOfLostMoves(counter);
           whitePlayer.modelOfPlayer.updateHistoryOfGamesResults(0);
           result=0;
        }
        double tmp=0;
        for(int k=0;k<whitePlayer.modelOfPlayer.getSizeOfValuesOfChoosenMoves();k++)
        {
           tmp+=whitePlayer.modelOfPlayer.getValueOfChoosenMoves(k);
        }
        double res=tmp/whitePlayer.modelOfPlayer.getSizeOfValuesOfChoosenMoves();
        whitePlayer.modelOfPlayer.updateHistoryOfAverageValuesPerMovePerGame(res);

        double tmp1,tmp2,tmp3=0;
        for(int k=0;k<whitePlayer.modelOfPlayer.getSizeOfValuesOfChoosenMoves();k++)
        {
           tmp1=computerForWhitePlayer.modelOfPlayer.getNeuralNetBestSuggestion(k);
           tmp2=whitePlayer.modelOfPlayer.getValueOfChoosenMoves(k);
           tmp3+=(tmp1-tmp2)*(tmp1-tmp2);
        }

        whitePlayer.modelOfPlayer.updateMeanSquareDistanceFromNeuralNetBestSuggestions(tmp3);

        double tmp4,tmp5,tmp6=0;
        for(int d=0;d<whitePlayer.modelOfPlayer.getSizeOfValuesOfChoosenMoves();d++)
        {
           tmp4=whitePlayer.modelOfPlayer.getValueOfChoosenMoves(d);
           tmp5=computerForWhitePlayer.modelOfPlayer.getNeuralNetWorstSuggestion(d);
           tmp6+=(tmp4-tmp5)*(tmp4-tmp5);
        }

        whitePlayer.modelOfPlayer.updateMeanSquareDistanceFromNeuralNetWorstSuggestions(tmp6);
//=========================================
         whitePlayer.modelOfPlayer.storeModel(port,hostName); //store the model of player
        System.out.println("Store white weights");
//===================athanasia==============
         whiteNeural.storeWeights(whitePlayer.modelOfPlayer.getLogin());
         System.out.println("Store black weights");
          blackNeural.storeWeights(whitePlayer.modelOfPlayer.getLogin()); //store neural net weights
        //keep data for weka system
//====================athanasia======================
       whitePlayer.modelOfPlayer.storeDataForWeka(counter,res,tmp3,tmp6,whitePlayer.modelOfPlayer.getLogin(),result);
    }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
/* the winner and the num of moves of the game */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    public void createStats(String s)
    {
        myStats.append(s);
        myStats.append("\n");
    }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
            /* keep players moves per game */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void storeGameMovesAndStats()
    {   String x;
        String wHistory=whitePlayer.toWSaveGame.getText(); //white human player moves
        String bHistory=blackPlayer.toBSaveGame.getText(); //black computer player moves
        //grapse sto arxeio tis kiniseis
     //   history gameHistory=new history();
        StringTokenizer stW = new StringTokenizer(wHistory.replace('\n',' '));
        StringTokenizer stB = new StringTokenizer(bHistory.replace('\n',' '));
    //    System.out.println("wHistory "+wHistory.replace('\n',' '));
    //    System.out.println("bHistory "+bHistory.replace('\n',' '));
        String gameMoves="----------------\nAspros vs Mayros\n----------------\n";
        while(stB.hasMoreTokens())
        {
            gameMoves+=stW.nextToken()+"\t"+stB.nextToken()+"\n";
        }
        //PROSOXH: o aspros mporei na exei mia akomi kinisi => check it
        if(stW.hasMoreTokens())
        {
            gameMoves+=stW.nextToken()+/*stCfWH.nextToken()*/'\n';
        } 
 /*==========================athanasia==================*/
        // gameHistory.writeToFile(gameMoves,"_"+whitePlayer.modelOfPlayer.getLogin()+"_"+DIMBOARD+""+DIMBASE+""+NUMOFPAWNS+"_game");
    	arxeia arx1=new arxeia();
    	 x="1";
    	arx1.Storestat( boardDimBoard1, boardDimBase1, numOfPawns1, whitePlayer.modelOfPlayer.getLogin(), port1, hostName1,gameMoves,x);
        arxeia arx2=new arxeia();
        x="2";
    	String ola= Spiel.myStats.getText();
       	arx1.Storestat( boardDimBoard1, boardDimBase1, numOfPawns1, whitePlayer.modelOfPlayer.getLogin(), port1, hostName1,ola,x);
   	
     } 
    
    
    protected void log(String msg)
	{ 
 	GamesDialog registerDialog = new GamesDialog(new Frame(), true,msg);
	    registerDialog.setVisible(true);
	    
	     
	    if (registerDialog.isRegisterButtonPressed())
	    {
	         
	    }
	    else
	    {
	         
	        return;
	    } 
 	     
	}

}//this is the end