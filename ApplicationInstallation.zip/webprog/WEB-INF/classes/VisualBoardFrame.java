/***************
  Created by: Eirini Ntoutsi
  Operation:
*******/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.applet.*;

//import java.applet.*;

public class VisualBoardFrame  extends JFrame  implements Common
{
   public static JFrame myFrame;
   public static VisualBoard visualBoard;
   public static JTextField myText; //human input field
   public static SimpleWindow helpSimpleWindow;
   public static SimpleWindow historySimpleWindow;
   public static SimpleWindow infoSimpleWindow;
   public static SimpleWindow onlineSimpleWindow;

   
   public static JButton historyButton,plotButton,modelButton,closeButton,replayButton,bookButton,onlineButton;
   

   static Player whitePlayer;
   static Player blackPlayer;
   static Player computerForWhitePlayer;
    static String hostName;
 	 static int port1;
 	 static String Login1;
  
//	String catalinaHome = "c:/Program Files/Apache Software Foundation/Tomcat 5.5/webapps/webprog/image/";
   //constructor: stin ousia aytos kanei oles is leitourgies
   public VisualBoardFrame(Player wPlayer,Player bPlayer,Player compForWPlayer,String Login, int port,String hostname)
   {  
      super();
      myFrame=new JFrame();
      myFrame.setTitle("RLGame - Web version - v 2.0 " );
      hostName=hostname;
      port1=port;
      Login1=Login;
      whitePlayer=wPlayer;
      blackPlayer=bPlayer;
      computerForWhitePlayer=compForWPlayer;
      JPanel toolbarPanel=new JPanel();
      visualBoard=new VisualBoard();
      JPanel boardPanel=new JPanel();
      Dimension boardDim = new Dimension(480,480);
      Dimension toolbarDim = new Dimension(80,42);//100,32
      boardPanel.setPreferredSize(boardDim);
      boardPanel.setSize(boardDim);
      boardPanel.setMinimumSize(boardDim);
      boardPanel.setMaximumSize(boardDim);
      boardPanel.setPreferredSize(boardDim);
      boardPanel.add(visualBoard);
      toolbarPanel.setSize(toolbarDim);
      toolbarPanel.setPreferredSize(toolbarDim);
      toolbarPanel.setMinimumSize(toolbarDim);
      toolbarPanel.setMaximumSize(toolbarDim);
      toolbarPanel.setFont(new Font("monospaced", Font.PLAIN, 26));
   
/* (1)to closeButton kai o listener tou */
 	  JLabel closeLabel=new JLabel();
      closeButton =new JButton ("     EXIT  GAME     " );
      closeButton.setToolTipText("Stop");
      class closeButtonActionListener implements ActionListener
      {
         public void actionPerformed(ActionEvent evt)
         {            
		       OnlineDelete myWindow = new OnlineDelete(port1, hostName, Login1);
		       myWindow.registerGames();
             myFrame.dispose();
             
         }
      }
    closeButtonActionListener myCloseAL=new closeButtonActionListener();
    closeButton.addActionListener(myCloseAL);
    toolbarPanel.add(closeButton);   
/* ok me to closeButton*/

/* (2)to  modelButton kai o listener tou */
 	JLabel modelLabel=new JLabel(); 
    modelButton =new JButton ("     PLAYER  INFO   ");
    modelButton.setToolTipText("Model");
    class modelButtonActionListener implements ActionListener
      {
         public void actionPerformed(ActionEvent evt)
         { 
           whitePlayer.modelOfPlayer.loadModel(port1,hostName);
            String s1="Login:"+'\t'+whitePlayer.modelOfPlayer.getLogin()+'\n';
            if(whitePlayer.modelOfPlayer.getModel()==EXPERT)
               s1+="Model:"+'\t'+"EXPERT"+'\n';
            else
               if(whitePlayer.modelOfPlayer.getModel()==BEGINNER)
                  s1+="Model:"+'\t'+"BEGINNER"+'\n';
               else
                  if(whitePlayer.modelOfPlayer.getModel()==ADVANCED)
                     s1+="Model:"+'\t'+"ADVANCED"+'\n';
                  else
                     s1+="Model:"+'\t'+"UNKNOWN"+'\n';
            s1+="Number of win games:"+'\t'+whitePlayer.modelOfPlayer.getNumOfWinGames()+'\n';
            s1+="Number of lost games:"+'\t'+whitePlayer.modelOfPlayer.getNumOfLostGames()+'\n';
            String s2="Game"+'\t'+"Result"+'\t'+"Avg. values of moves"+'\t'+"Distance from best neural net suggestions"+'\t'+"Distance from worst neural net suggestions"+'\n';
            Vector tmp1=whitePlayer.modelOfPlayer.getHistoryOfGameResults();
            Vector tmp2=whitePlayer.modelOfPlayer.getHistoryOfAverageValuesPerMovePerGame();
            Vector tmp3=whitePlayer.modelOfPlayer.getMeanSquareDistanceFromNeuralNetBestSuggestions();
            Vector tmp4=whitePlayer.modelOfPlayer.getMeanSquareDistanceFromNeuralNetWorstSuggestions();

            for(int k=0;k<tmp1.size();k++)
            {
               s2+=""+(k+1)+'\t'+tmp1.get(k)+'\t'+tmp2.get(k)+'\t'
               +tmp3.get(k)+"  "+'\t'+'\t'+tmp4.get(k)+'\n';
            }
            s2+="\n\nEXPLANATION\nResult:  1 for the winner, 0 for the loser\n\n"+
                "Avg. values of moves:  the average value of your moves for the corresponding game\n\n"+
                "Distance from best neural net suggestions:\n  the mean square distance between your moves and neural net best suggested moves. \n"+
                "It is computed by the expression: �[(x-y)*(x-y)], where x is the value of the neural net best suggestion\n and y is the value of your move for all moves of the corresponding game.\n\n"+
                "Distance from worst neural net suggestions: \n the mean square distance between your moves and neural net worst suggested moves. \n"+
                "It is computed by the expression: �[(z-w)*(z-w)], where z is the value of your move \nand w is the value of the neural net worst suggestion for all moves of the corresponding game.\n\n";
            infoWindow myInfoWindow = new infoWindow("Model information",s1,"Game details",s2);
            myInfoWindow.showInfoWindow();
         }
      }
      modelButtonActionListener myModelAL=new modelButtonActionListener();
      modelButton.addActionListener(myModelAL);
     toolbarPanel.add(modelButton); 
/* ok me to modelButton*/

/* (3)to  historyButton kai o listener tou */
   JLabel historyLabel=new JLabel();////aaaa("HISTORY",SwingConstants.CENTER);
      historyButton =new JButton("       HISTORY      ");//new ImageIcon(catalinaHome+"history.gif"));
      historyButton.setToolTipText("History");
      class historyButtonActionListener implements ActionListener
      {
         public void actionPerformed(ActionEvent evt)
         {
            String sHelp="#\tYour moves\t\t\t    <----> \t\tComputer moves\n";
            String wHistory=whitePlayer.toWSaveGame.getText();
            String bHistory=blackPlayer.toBSaveGame.getText();
            StringTokenizer stW = new StringTokenizer(wHistory.replace('\n',' '));
            StringTokenizer stB = new StringTokenizer(bHistory.replace('\n',' '));
            String whiteRemainPawns="\nActive pawns for white "+Spiel.myPosition.getWhiteRemaining(Spiel.myPosition.whitePawns);
            String blackRemainPawns=" \tActive pawns for black "+Spiel.myPosition.getBlackRemaining(Spiel.myPosition.blackPawns);
            String gameMoves="";
            int k=0;
            while (stB.hasMoreTokens())
            {
               gameMoves+=(k+1)+")\t"+stW.nextToken()+"\t\t\t"+stB.nextToken()+"\n";
               k++;
            }
            // o aspros mporei na exei mia akomi kinisi => check it
            if (stW.hasMoreTokens())
            {
               gameMoves+=(k+1)+")\t"+stW.nextToken()+'\n';
            }
            sHelp+=gameMoves;
            sHelp+=whiteRemainPawns;
            sHelp+=blackRemainPawns;
            Dimension historySize=new Dimension(600,450);
            historySimpleWindow = new SimpleWindow("Game moves for both players",sHelp+'\n',historySize);
            historySimpleWindow.showSimpleWindow();
         }
      }
          historyButtonActionListener myHistoryAL=new historyButtonActionListener();
          historyButton.addActionListener(myHistoryAL);
      
          toolbarPanel.add(historyButton);  
      /* ok me to historyButton*/

/* (4)to plotButton kai o listener tou */
    JLabel plotLabel=new JLabel();////aaaaaaaaa("GAME STATISTICS",SwingConstants.CENTER);
       plotButton =new JButton("  GAME  STATISTICS  ");//new ImageIcon(catalinaHome+"stats1.jpg"));
      plotButton.setToolTipText("Graph");
      class plotButtonActionListener implements ActionListener
      {
         public void actionPerformed(ActionEvent evt)
         {
            //oi kalyteres kiniseis pou tou proteinei o ypologistis
            Vector v1=computerForWhitePlayer.modelOfPlayer.getNeuralNetBestSuggestion();
            //oi dikes tou kiniseis
            Vector v2=whitePlayer.modelOfPlayer.getValueOfChoosenMoves();
            //oi xeiroteres kiniseis pou tou proteinei o ypologistis
            Vector v3=computerForWhitePlayer.modelOfPlayer.getNeuralNetWorstSuggestion();
            PlotXY myGraph = new PlotXY(v1,v2,v3);
            myGraph.showPlotXY();
         }
      }
      plotButtonActionListener myPlotAL=new plotButtonActionListener();
      plotButton.addActionListener(myPlotAL);
 
      toolbarPanel.add(plotButton);
    
/* ok me to plotButton*/

/* (5)to helpButton kai o listener tou */
 	  JLabel helpLabel=new JLabel();////////aaaa("HELP",SwingConstants.CENTER);
     JButton helpButton =new JButton("       HELP        ");//new ImageIcon(catalinaHome+"metal-Question.gif"));
      helpButton.setToolTipText("Help");
      class helpButtonActionListener implements ActionListener
      {
       public void actionPerformed(ActionEvent evt)
       {  
          String sHelp="\t\t\t  Possible moves:\nMove\t\tFrom square\t\tTo square\t\tValue of movement\n"+whitePlayer.nextMoveSuggestionsForHuman;
          sHelp+="\nRemaining active pawns for you: "+Spiel.myPosition.getWhiteRemaining(Spiel.myPosition.whitePawns);
          sHelp+="\n\nHuman player starts out from bottom-left base\n";
			sHelp+="To move a pawn out of the base, if there are any left, (a) click on the base, then (b) click on an adjacent square\n";
 			sHelp+="To move any other pawn, (a) click on the pawn, then (b) click on the target square";

          Dimension helpSize=new Dimension(600,450);
          helpSimpleWindow = new SimpleWindow("Get a hint for your next move",sHelp,helpSize);
          helpSimpleWindow.showSimpleWindow();
       }
    }
    helpButtonActionListener myHelpAL=new helpButtonActionListener();
    helpButton.addActionListener(myHelpAL);
  
    toolbarPanel.add(helpButton); 
/* ok me to helpButton*/

/* (6)to infoButton kai o listener tou */
   JLabel infoLabel=new JLabel();////aaaa("GAME INFO",SwingConstants.CENTER);
     JButton infoButton =new JButton("        INFO       ");//new ImageIcon(catalinaHome+"metal-Inform.gif"));
      infoButton.setToolTipText("Info");
      class infoButtonActionListener implements ActionListener
      {
       public void actionPerformed(ActionEvent evt)
       {
          String sInfo="\t\t\t  The game:\n";
          sInfo+="The game is played on a rectangular board of of dimension nxn.\nAt the lower left and upper right part of the board are located the players' bases, \neach of dimension axa. Each player posssess � pawns, that initially \nare inside the corresponding base, which is considered as one square \nand not as a set of squares.\n\n";
          sInfo+="\t\t\t  The goal:\n";
          sInfo+="Each player's goal is to get one of his pawns into the enemy base. \nIf a player runs out of pawns, the opponent is declared as winner.\n";
          sInfo+="\n\n\t\t\t  The rules:\n";
          sInfo+="Each pawn can move to an empty square that is vertically or horizontaly adjacent, \nprovided that the pawn's maximum distance from its base is not decreased. \nBackward moves are not allowed. As soon as a move has taken place, \nall pawns that have no legal move are pronounced 'inactive' and are removed.";
          	sInfo+="\nHuman player starts out from bottom-left base\n";
		sInfo+="To move a pawn out of the base, if there are any left, (a) click on the base, then (b) click on an adjacent square\n";
 		sInfo+="To move any other pawn, (a) click on the pawn, then (b) click on the target square";
          Dimension infoSize=new Dimension(700,550);
          infoSimpleWindow = new SimpleWindow("About the game",sInfo,infoSize);
          infoSimpleWindow.showSimpleWindow();
       }
      }
      infoButtonActionListener myInfoAL=new infoButtonActionListener();
      infoButton.addActionListener(myInfoAL);
 
      toolbarPanel.add(infoButton); 
/* ok me to infoButton*/
  JLabel bookLabel=new JLabel();
      bookButton =new JButton ("     GUEST BOOK     " );
      bookButton.setToolTipText("Guest Book");
      class bookButtonActionListener implements ActionListener
      {
         public void actionPerformed(ActionEvent evt)
         { String a="RLGame - Web version - v 2.0 - GuestBook";
           GuestBookWindow mybookWindow = new GuestBookWindow(a,Login1, port1, hostName, Login1);
           mybookWindow.showBookWindow();
         }
      }
    bookButtonActionListener mybookAL=new bookButtonActionListener();
    bookButton.addActionListener(mybookAL);
    toolbarPanel.add(bookButton);   
    
    
    /////prosthiki gia on-line 
//  toolbarPanel.add(onlineButton); 
/* ok me to infoButton*/
     JLabel onlineLabel=new JLabel();
      onlineButton =new JButton ("     ON LINE PLAYER      " );
      onlineButton.setToolTipText("ON LINE");
      class onlineButtonActionListener implements ActionListener
      {
         public void actionPerformed(ActionEvent evt)
         { String a="RLGame - Web version - v 2.0 - ON LINE PLAYER";
           OnlineBookWindow myonlinebookWindow = new OnlineBookWindow( port1, hostName, Login1);
           myonlinebookWindow.online( port1, hostName, Login1);
         }
      }
    onlineButtonActionListener myonlineAL=new onlineButtonActionListener();
    onlineButton.addActionListener(myonlineAL);
    toolbarPanel.add(onlineButton);   
/* --- End of listeners --- */
/* --- End of listeners --- */


  	Color c1= new Color( 180,120,120);
 	Color c=new Color(220, 140,220);
	toolbarPanel.setLayout(new FlowLayout());
 	boardPanel.setBackground(Color. LIGHT_GRAY);
	toolbarPanel.setBackground(Color.LIGHT_GRAY );
    myFrame.getContentPane().add(BorderLayout.NORTH,toolbarPanel);
    myFrame.getContentPane().add(BorderLayout.CENTER,boardPanel);
    myFrame.setSize(1000,650); 
    myFrame.setResizable(false);
    myFrame.setBounds(30,30,1100,700); 
    myFrame.setVisible(true);
    myFrame.repaint();
    myFrame.addWindowListener(
    new WindowAdapter()
    {
        public void windowClosing(WindowEvent e)
        {
		   myFrame.dispose();
        }
    });

}


 
    public static void clearVisualBoard()
    {
       visualBoard.clearVisualBoardPawns();
       myFrame.dispose();
       
    }

    public static void setButtonsEnable(boolean enable,int k)
    {
        historyButton.setEnabled(enable);
        if((enable==true)&&(k>1))
          plotButton.setEnabled(true);
        else
          plotButton.setEnabled(false);
    }
//this is the end
}
