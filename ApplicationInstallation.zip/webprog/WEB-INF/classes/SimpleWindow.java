/***************
  Created by:  Eirini Ntoutsi
  Operation: Creates a single child window
*******/
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.awt.geom.*;
import javax.swing.border.*;

public class SimpleWindow extends JComponent
{
    static JFrame frame;
    private static String title;
    private static String textToShow;
    private static ImageIcon middle;
    private static Dimension minSize;
   // static String catalinaHome = "c:/Program Files/Apache Software Foundation/Tomcat 5.5/webapps/webprog/image/";
    public SimpleWindow(String s1,String s2,Dimension size)
    {
        super();
        title=s1;
        textToShow=s2;
        minSize=size;
        setSize(minSize);
    }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    public void setString(String str)
    {
        textToShow=str;
    }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    public Dimension getPreferredSize()
    {
        Container parent=getParent();
        return (parent!=null) ? parent.getSize():minSize;
    }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    public Dimension getMinimumSize()
    {
        return minSize;
    }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    public void refreshWindow()
    {
        this.repaint();
        if (frame!=null)
            frame.repaint();
    }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    public static void showSimpleWindow()
    {
        frame = new JFrame();
       JPanel mainPanel=new JPanel();
       JPanel upPanel=new JPanel();
       JPanel toolbarPanel=new JPanel();
       JScrollPane scrollPanel;
       JTextArea textArea;
       JButton closeButton;
       Dimension buttonSize=new Dimension(110,25);
       Dimension scrollPanelDim = new Dimension(150,150);
       Dimension toolbarPanelDim = new Dimension(150,50);
       
       
    // Color c= new Color(96,160,96);
     	Color c=new Color(153,120,218);	
       frame.setBackground(c);
       frame.setTitle(title);
       frame.setBounds(10,10,400,200);
			//setSize(insets().left + insets().right + 511,insets().top + insets().bottom + 351);
       mainPanel.setBackground(c);
       mainPanel.setLayout(new BorderLayout());
       upPanel.setBackground(c);
       upPanel.setLayout(new BorderLayout());

       textArea = new JTextArea(textToShow,15,25);
       textArea.setFont(new Font("Comic Sans MS", Font.ROMAN_BASELINE,11));
      // textArea.setLineWrap(true);
       //textArea.setWrapStyleWord(true);
       textArea.setBackground(c);

       scrollPanel = new JScrollPane(textArea,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
       scrollPanel.setBackground(c);
       scrollPanel.setSize(scrollPanelDim);
       scrollPanel.setPreferredSize(scrollPanelDim);
       scrollPanel.setMinimumSize(scrollPanelDim);



	  // Color c= new Color(102,102,255);
       toolbarPanel.setBackground(c);
      
       toolbarPanel.setSize(toolbarPanelDim);
       toolbarPanel.setMinimumSize(toolbarPanelDim);
       toolbarPanel.setMaximumSize(toolbarPanelDim);
       toolbarPanel.setPreferredSize(toolbarPanelDim);
       //buttons
       //To closeButton kai o listener tou
       closeButton=new JButton(" C L O S E ");//new ImageIcon(catalinaHome+"close.gif")
       closeButton.setToolTipText("Close");
       closeButton.setSize(buttonSize);
       closeButton.setMinimumSize(buttonSize);
       closeButton.setMaximumSize(buttonSize);
       closeButton.setPreferredSize(buttonSize);

       class closeButtonActionListener implements ActionListener
       {
            public void actionPerformed(ActionEvent evt)
            {
                 frame.dispose();
             }
       }
       closeButtonActionListener myCloseAL=new closeButtonActionListener();
       closeButton.addActionListener(myCloseAL);
       //end of buttons

       toolbarPanel.setLayout(new BoxLayout(toolbarPanel,BoxLayout.X_AXIS));
       toolbarPanel.setBorder(new BevelBorder(BevelBorder.RAISED,Color.gray,Color.gray));
       toolbarPanel.add(BorderLayout.EAST,closeButton);

       upPanel.add(BorderLayout.CENTER,scrollPanel);
       upPanel.add(BorderLayout.NORTH,toolbarPanel);
       mainPanel.add(BorderLayout.CENTER,upPanel);
       
       //add mainPanel to the frame
       frame.getContentPane().setLayout(new BorderLayout());
       frame.getContentPane().add(BorderLayout.CENTER,mainPanel);

       frame.setSize(minSize);
       frame.setVisible(true);
       frame.setResizable(true);
       frame.addWindowListener(new WindowAdapter()
       {
            public void windowClosing(WindowEvent e)
            {
                frame.dispose();
            }
       });
    }
  //send of class
}