/***************
  Created by:  athanasia Vlasi
  Operation: Creates a parent window
*******/
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.awt.*;
import java.awt.List;
import java.awt.geom.*;
import javax.swing.border.*;
import java.io.*;
import java.util.Date;
import java.net.*;
import register.BookNote;


public class GuestBookWindow extends JComponent
{
   private static String title;
   private static String textToShow;
   private static String textToShow1;
   private static String firstButtonTitle;
   private static String firstButtonTextToShow;
   private Dimension minSize=new Dimension(200,200);
   private static String webServerStr7 = null;
   private String hostName = "localhost";
   private  List showList;
   private static String servletPath7 = "/webprog/GuestBookServlet";
   private static String Login1;
   private static int port1;
// 	private static String HostName;
	private static String anote;
//	private Stringmsg=""; 
   //constructor
   public GuestBookWindow (String s1,String s2,/*,String ss1,String ss2,*/int port,String hostname1,String Login)
   {   	super(); 
   		Login1=Login;
    	port1 = port;
     	hostName=hostname1;	
        setSize(minSize);title=s1;
  }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public Dimension getPreferredSize()
  {
      Container parent=getParent();
      return (parent!=null) ? parent.getSize():minSize;
  }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public Dimension getMinimumSize()
  {
      return minSize;
  }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public void plot()
  {
      repaint();
  }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public  /*static*/ void showBookWindow()
  {
      final JFrame frame = new JFrame();
      JPanel mainPanel=new JPanel();
      JPanel upPanel=new JPanel();
      JPanel toolbarPanel=new JPanel();
      JScrollPane scrollPanel; JScrollPane scrollPanel1;
      JTextArea textArea;
      String textToShow1=null;
     // Dimension buttonSize=new Dimension(80,30);
      Dimension frameSize=new  Dimension(1000,600);
      Dimension dim = new Dimension(600,400); 
      Dimension toolbarSize = new Dimension(100,50);
      Color c=new Color(153,120,218);	
      frame.setBackground(c);
      frame.setTitle(title);
      frame.setBounds(10,10,1000,700);
      mainPanel.setBackground(c);
      mainPanel.setLayout(new BorderLayout());
      upPanel.setBackground(c);
      upPanel.setLayout(new BorderLayout());
	  //String epilogi="all";
      //Vector gamesVector = getGamesList(epilogi);
	 // displayGames(gamesVector);
	 	textToShow=" ";
      textArea = new JTextArea(textToShow,950,700);
      textArea.setFont(new Font("Comic Sans MS", Font.ROMAN_BASELINE,12));
      textArea.setLineWrap(true);
      textArea.setWrapStyleWord(true);
      textArea.setEditable(false);
      textArea.setBackground(c);
      scrollPanel = new JScrollPane(textArea,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
      scrollPanel.setBackground(c);
      scrollPanel.setSize(dim);
      scrollPanel.setPreferredSize(dim);
      scrollPanel.setMinimumSize(dim);
      scrollPanel.setMaximumSize(dim); 
    		
      toolbarPanel.setBackground(c);
      toolbarPanel.setSize(toolbarSize);
      toolbarPanel.setMinimumSize(toolbarSize);
      toolbarPanel.setMaximumSize(toolbarSize);
      toolbarPanel.setPreferredSize(toolbarSize);
       toolbarPanel.setFont(new Font("monospaced", Font.PLAIN, 26));
      //buttons
       //to add kai o listener tou
      JButton addButton=new JButton("        A D D       ");
      addButton.setToolTipText("Add");
    //  addButton.setSize(buttonSize);
   //   addButton.setMinimumSize(buttonSize);
    //  addButton.setMaximumSize(buttonSize);
   //   addButton.setPreferredSize(buttonSize);
       class addButtonActionListener implements ActionListener
      {
          public void actionPerformed(ActionEvent evt)
         {		String enas=null;
         	//	msg="DATE -  TIME  -  LOGIN :"+"\n";
			    BookNote theGames=null;
            	Calendar cal=Calendar.getInstance();    
		        Date myDate=new Date();
		        String helpName=myDate.toString();
		        helpName=helpName.substring(11,19);
		      	helpName=helpName.replace(':',':');
		        int year = cal.get(Calendar.YEAR); 
				int month = cal.get(Calendar.MONTH)+1; 
				int day = cal.get(Calendar.DAY_OF_MONTH);	
				String ast=(year+"-"+month+"-"+day).toString();
				String a=ast+" ,  " +helpName+" ,  Login: " +Login1;
				a=a.trim();
				NotesRegisterDialog registerDialog = new NotesRegisterDialog(new Frame(), true,a);
			    registerDialog.setVisible(true);
			    
			    // find out if user selected the register or cancel button
			    if (registerDialog.isRegisterButtonPressed())
			    {
			        theGames = registerDialog.getGames();
	                enas=theGames.getLogin();
		            registernotes(theGames.getsxolia()); 
			    }
			    else
			    {
			        // the cancel button was pressed, so do nothing and return
	 	            enas="all";
			        return;
			    }
	         }
      } 
      addButtonActionListener myAddAL=new addButtonActionListener();
      addButton.addActionListener(myAddAL);
      //end of buttons
      //To showButton kai o listener tou
      JButton showButton=new JButton("        S H O W        ");
     
      showButton.setToolTipText("Show");
   //   showButton.setSize(buttonSize);
    //  showButton.setMinimumSize(buttonSize);
   //   showButton.setMaximumSize(buttonSize);
  //    showButton.setPreferredSize(buttonSize);

      class showButtonActionListener implements ActionListener
      {
          public void actionPerformed(ActionEvent evt)
          {		String epilogi="all";	
//          		msg="DATE -  TIME  -  LOGIN :"+"\n";
          		Vector gamesVector = getGamesList(epilogi);
				displayGames(gamesVector);
				firstButtonTextToShow =	textToShow;
				firstButtonTitle="RLGame - Web version - v 2.0 - Guest Book - Show All  ";
                Dimension moreSize=new Dimension(1000,600);
                SimpleWindow my = new SimpleWindow(firstButtonTitle,firstButtonTextToShow,moreSize);
                my.showSimpleWindow();
          }
      }
      showButtonActionListener myShowAL=new showButtonActionListener();
      showButton.addActionListener(myShowAL);
	
	
	  //To showDateButton kai o listener tou
      JButton showDateButton=new JButton("SHOW CURRENT DATE ");
     
      showDateButton.setToolTipText("Show/Date");
    //  showDateButton.setSize(buttonSize);
    //  showDateButton.setMinimumSize(buttonSize);
    //  showDateButton.setMaximumSize(buttonSize);
    //  showDateButton.setPreferredSize(buttonSize);

      class showDateButtonActionListener implements ActionListener
      {
          public void actionPerformed(ActionEvent evt)
          {  String epilogi="date";  	
//          	msg="DATE -  TIME  -  LOGIN :"+"\n";
          	Vector gamesVector = getGamesList(epilogi);
				displayGames(gamesVector);
				firstButtonTextToShow =	textToShow;
				firstButtonTitle="RLGame - Web version - v 2.0 - Guest Book - Show / Date  ";
                Dimension moreSize=new Dimension(1000,600);
               SimpleWindow my = new SimpleWindow(firstButtonTitle,firstButtonTextToShow,moreSize);
               my.showSimpleWindow();
          }
      }
      showDateButtonActionListener myshowDateAL=new showDateButtonActionListener();
      showDateButton.addActionListener(myshowDateAL);
	
	//To showlOGINButton kai o listener tou
      JButton showLoginButton=new JButton("SHOW CURRENT LOGIN");
     
      showLoginButton.setToolTipText("Show/Login");
  //    showLoginButton.setSize(buttonSize);
  //    showLoginButton.setMinimumSize(buttonSize);
  //    showLoginButton.setMaximumSize(buttonSize);
  //    showLoginButton.setPreferredSize(buttonSize);

      class showLoginButtonActionListener implements ActionListener
      {
          public void actionPerformed(ActionEvent evt)
          {	 String epilogi="login"; 	
//          	msg="DATE -  TIME  -  LOGIN :"+"\n";	
          	Vector gamesVector = getGamesList(epilogi);
			displayGames(gamesVector);
			firstButtonTextToShow =	textToShow;
			firstButtonTitle="RLGame - Web version - v 2.0 - Guest Book - Show / Login  ";
            Dimension moreSize=new Dimension(1000,600);
            SimpleWindow my = new SimpleWindow(firstButtonTitle,firstButtonTextToShow,moreSize);
              my.showSimpleWindow();
          }
      }
      showLoginButtonActionListener myshowLoginAL=new showLoginButtonActionListener();
      showLoginButton.addActionListener(myshowLoginAL);
	
      //To closeButton kai o listener tou
      JButton closeButton=new JButton("        C L O S E       ");
      closeButton.setToolTipText("Close");
   //   closeButton.setSize(buttonSize);
  //    closeButton.setMinimumSize(buttonSize);
   //   closeButton.setMaximumSize(buttonSize);
   //   closeButton.setPreferredSize(buttonSize);
      class closeButtonActionListener implements ActionListener
      {
         public void actionPerformed(ActionEvent evt)
         {
            frame.dispose();
         }
      }
      closeButtonActionListener myCloseAL=new closeButtonActionListener();
      closeButton.addActionListener(myCloseAL);
     

     // toolbarPanel.setLayout(new BoxLayout(toolbarPanel,BoxLayout.X_AXIS));
     // toolbarPanel.setBorder(new BevelBorder(BevelBorder.RAISED,Color.gray,Color.gray));
      //prosthese ta buttons sto  toolbar panel
    	toolbarPanel.setLayout(new FlowLayout());
      toolbarPanel.add(/*BorderLayout.WEST,*/addButton);
      toolbarPanel.add(/*BorderLayout.CENTER,*/showButton);
      toolbarPanel.add(/*BorderLayout.CENTER,*/showDateButton);
      toolbarPanel.add(/*BorderLayout.EAST,*/showLoginButton);
      toolbarPanel.add(/*BorderLayout.EAST,*/closeButton);
      //prosthese sto uppanel to toolbar panel kai to scroll panel
   		upPanel.add(BorderLayout.CENTER,scrollPanel);
//       upPanel.add(BorderLayout.CENTER,scrollPanel1);
    //      upPanel.add(BorderLayout.CENTER,showList);
 //       upPanel.add(BorderLayout.NORTH,scrollPanel1);
      //prosthese sto mainpanel to uppanel
      upPanel.add(BorderLayout.NORTH,toolbarPanel);
    //  mainPanel.add(BorderLayout.NORTH,upPanel);    mainPanel.add(BorderLayout.CENTER,upPanel);
      mainPanel.add(BorderLayout.CENTER,upPanel);
      //prosthese to mainPanel sto frame
      frame.getContentPane().setLayout(new BorderLayout());
      frame.getContentPane().add(BorderLayout.CENTER,mainPanel);
      frame.setSize(frameSize);
      frame.setResizable(true);
      frame.setVisible(true);
      frame.addWindowListener(new WindowAdapter()
      {
          public void windowClosing(WindowEvent e)
          {
              frame.dispose();
          }
      });
  }
  
 	protected  void registernotes(String notes) 
 	{	ObjectInputStream inputFromServlet = null;
 	//	String notes=anote;
	    if (port1 == -1)
		 {
		 	port1 = 80;
		 }
    	webServerStr7 = "http://" + hostName + ":" + port1 + servletPath7;
     //   log("  d "+webServerStr5);
        try
	    {     
	        String servletGET = webServerStr7;
            URL gamesservlet1 = new URL( servletGET);
            URLConnection servletConnection1 = gamesservlet1.openConnection();  
	        	    
	        ///////////// 
	      // String ergasia=null;
            servletConnection1.setDoInput(true);          
	        servletConnection1.setDoOutput(true);
	        servletConnection1.setUseCaches (false);
            servletConnection1.setRequestProperty ("Content-Type", "application/octet-stream");
          //  ergasia=kod;
	     	Calendar cal=Calendar.getInstance();    
	        Date myDate=new Date();
	        String helpName=myDate.toString();
	        helpName=helpName.substring(11,19);
	      	helpName=helpName.replace(':',':');
	        int year = cal.get(Calendar.YEAR); 
			int month = cal.get(Calendar.MONTH)+1; 
			int day = cal.get(Calendar.DAY_OF_MONTH);	
			String ast=(year+"-"+month+"-"+day).toString();
			 String adate=ast;
	        // String bDate=null;
	         String arxtime=helpName;
	      //   String teltime=null;
	         BookNote booknote= new BookNote(Login1,adate,arxtime,notes);
	         
	        sendNotesToServlet(servletConnection1,booknote);
	     
            inputFromServlet = new ObjectInputStream(servletConnection1.getInputStream());

	             
	   	}
	    catch (Exception e)
	    {
	        // log(e.toString());    
	    } 
	        
	        
	        //Read the input from the servlet.  
	        //
	        // The servlet will return a serialized vector containing
	        // player entries.
	        //
		    
	}  
protected void sendNotesToServlet(URLConnection servletConnection, BookNote booknote)
    {
        ObjectOutputStream outputToServlet = null;
        
        try
        {
	        // send the player object to the servlet using serialization
	   //     log("Sending the data to the servlet...");
	        outputToServlet = new ObjectOutputStream(servletConnection.getOutputStream());
	        
	        // serialize the object
	        outputToServlet.writeObject(booknote);
	        
	        outputToServlet.flush();	        
	        outputToServlet.close();
//	        log("Complete.");
        }
        catch (IOException e)
        {
//          log(e.toString());    
        }
    }
   
    protected Vector getGamesList(String epilogi)
	{	if (port1 == -1)
		 {
		 	port1 = 80;
		 }
    	webServerStr7 = "http://" + hostName + ":" + port1 + servletPath7;
        ObjectInputStream inputFromServlet = null;
        Vector gamesVector = null;
        try
	    {     
	        // build a GET url string w/ encoded name/value pairs
	        //
	        // Send over UserOption=display.  The servlet will interpret
	        // the user option and send back the player list as a serialized vector
	        // of player objects.
	        //
	        String servletGET = webServerStr7 + "?" 
	                            + URLEncoder.encode("UserOption") + "="; 
	       if (epilogi.equals("date"))
	       { servletGET+=URLEncoder.encode("display_date");
	                              
	       }
	       else if (epilogi.equals("login"))
	       { servletGET+=URLEncoder.encode(Login1);
	                        
	       } 
	       else if(epilogi.equals("all"))
	       {  servletGET+=URLEncoder.encode("display");
	                            
	         
	       }
            // connect to the servlet
          // log("Connecting.applet..");
            URL gamesservlet = new URL( servletGET );
            URLConnection servletConnection = gamesservlet.openConnection();  
	         
	        // Read the input from the servlet.  
	        // The servlet will return a serialized vector containing
	        // player entries.
	        //
		//	log("Getting input stream");
	        inputFromServlet = new ObjectInputStream(servletConnection.getInputStream());
	        gamesVector = readGamesVector(inputFromServlet);
	    }
	    catch (Exception e)
	    {
	     //   log(e.toString());
	    }
        return gamesVector;
	}  
	
   protected Vector readGamesVector(ObjectInputStream theInputFromServlet)
    {
        Vector theGamesVector = null;
        
        try
        {	        
            // read the serialized vector of games objects from
            // the servlet
            //
	    //    log("Reading data...");
	        theGamesVector = (Vector) theInputFromServlet.readObject();
	  //      log("Finished reading data.  " + theGamesVector.size() + " games returned");
	        theInputFromServlet.close();
        }
        catch (IOException e)
        {
     //       log(e.toString());    
        }
        catch (ClassNotFoundException e)
        {
    //        log(e.toString());                
        }
        catch (Exception e)
		{
            System.out.println(e);                		
		}
		
        return theGamesVector;
    }
    
     protected void displayGames(Vector gamesVector)
    {   JTextArea textArea = new JTextArea();
        Enumeration enuma = gamesVector.elements();
       
        BookNote aGames = null;
        String login = null;
        //String msg=null;
       	String  aDate = null;	
       	String   arxtime= null;	
       	String  sxolia= null;
		int i;
        while (enuma.hasMoreElements())
        {
            aGames = (BookNote) enuma.nextElement();
            login = aGames.getLogin();
            aDate =aGames.getaDate();
            arxtime =aGames.getarxtime();
            sxolia =aGames.getsxolia(); 
            String msg=aDate+"   "+arxtime+"   "+login+" :   "+sxolia+"\n";
            for (i=1;i<220;i++)
            	msg+="-";
            msg+="\n";
   			textArea.append(msg );  
  
        } 
          textToShow=textArea.getText ();
        
    }
	
}