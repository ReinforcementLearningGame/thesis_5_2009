import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.applet.*;
import javax.swing.JTextArea;

 
public class startDialog extends Dialog
{
    boolean registerButtonPressed = false;
    	    
	public startDialog(Frame parent, boolean modal,String msg)
	{
	
	super(parent, modal);
		setLayout(null);
		setSize(insets().left + insets().right + 511,insets().top + insets().bottom + 351);
	//	Color c= new Color(96,160,96);
		Color c=new Color(153,120,218);	
	 	setBackground(c);
	 	helpTextArea = new  JTextArea(300,100);
 
	 //	helpTextArea = new java.awt.TextArea();
 	helpTextArea.setBounds(insets().left + 80,insets().top + 80,300,100);
		String sInfo="  WINNER   :  ";
        sInfo+=msg;
//        helpTextArea.setDisableTextColor (Color.RED);
		helpTextArea.setText(sInfo);	helpTextArea.setBackground(c);
		add(helpTextArea);
	    
		registerButton = new java.awt.Button();
		registerButton.setLabel("  N  E  W      G  A  M  E ");
		registerButton.setBounds(insets().left + 50,insets().top + 212,150,40);
		registerButton.setBackground(java.awt.Color.lightGray);
		add(registerButton);
	
		cancelButton = new java.awt.Button();
		cancelButton.setLabel(" S  T  O  P     P  L  A  Y ");
		cancelButton.setBounds(insets().left + 350,insets().top + 212,150,40);
		cancelButton.setBackground(java.awt.Color.lightGray);
		add(cancelButton);
		setTitle(" RLGame - Web version - v 1.0     ");
		

		//{{REGISTER_LISTENERS
		SymWindow aSymWindow = new SymWindow();
		this.addWindowListener(aSymWindow);
		SymAction lSymAction = new SymAction();
		cancelButton.addActionListener(lSymAction);
		registerButton.addActionListener(lSymAction);
		javax.swing.JTextArea   helpTextArea;
		//}}
		
	}
	
	public void addNotify()
	{
  	    // Record the size of the window prior to calling parents addNotify.
	    Dimension d = getSize();

		super.addNotify();

		if (fComponentsAdjusted)
			return;

		// Adjust components according to the insets
		setSize(insets().left + insets().right + d.width, insets().top + insets().bottom + d.height);
		Component components[] = getComponents();
		for (int i = 0; i < components.length; i++)
		{
			Point p = components[i].getLocation();
			p.translate(insets().left, insets().top);
			components[i].setLocation(p);
		}
		fComponentsAdjusted = true;
	}

    // Used for addNotify check.
	boolean fComponentsAdjusted = false;



// 	{{DECLARE_CONTROLS
//	java.awt.Label label1;
 	javax.swing.JTextArea helpTextArea;
//	java.awt.Label label2;
//	java.awt.TextField passwordTextField;
	java.awt.Button registerButton;
	java.awt.Button cancelButton;
//	}}

	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == startDialog.this)
				Dialog1_WindowClosing(event);
		}
	}
	
	void Dialog1_WindowClosing(java.awt.event.WindowEvent event)
	{
		dispose();
	}

	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == cancelButton)
				cancelButton_Action(event);
			else if (object == registerButton)
				registerButton_Action(event);
		}
	}

	void cancelButton_Action(java.awt.event.ActionEvent event)
	{
		// to do: code goes here.
        registerButtonPressed = false;		
		this.setVisible(false);
	}
	
	public boolean isRegisterButtonPressed()
	{
	    return registerButtonPressed;    
	}

	void registerButton_Action(java.awt.event.ActionEvent event)
	{
		// to do: code goes here.
		registerButtonPressed = true;
		this.setVisible(false);
        
	}
	
 }
