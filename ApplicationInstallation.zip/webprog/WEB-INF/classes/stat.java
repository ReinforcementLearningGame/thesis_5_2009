package register;
import java.sql.*;


public class stat implements java.io.Serializable
{		private int dimbase;
  	private int numofpawns;
  	private int	dimboard;
    // data members
    private String login;
    private String flag;
  // private String hostname;
   private String data;

        
    private final String CR = "\n";     // carriage return
       
    // constructors
    public  stat()
    {
    }
    
    public  stat(int adimboard,int adimbase,int anumofpawns,String aLogin,String aData,String aflag) 
    {	dimbase=adimbase;
    	numofpawns=anumofpawns;
    	dimboard=adimboard;
        login = aLogin;
        data=aData; 
        flag=aflag;
    }
           
     public  stat(ResultSet dataResultSet)
    {
                
        try 
		{
			System.out.println("games() start");

            // assign data members
            login = dataResultSet.getString("login");
          //  password = dataResultSet.getString("password");
         //   hostname = dataResultSet.getString("hostname");
  			data=dataResultSet.getString("data") ;
  			flag=dataResultSet.getString("flag") ;
		
			
			System.out.println("games() complete"+login);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }   
    }
 
    //  accessors
    public String getLogin()
    {
        return login;   
    }
       public int getdimbase ()
    {
        return dimbase;   
    }
    public int getnumofpawns()
    {
        return numofpawns;   
    }
    
    public int getdimboard ()
    {
        return dimboard;   
    }
   
    public String getdata()
    {
        return data;   
    }
    
     public String getflag()
    {
        return flag;   
    }
    //  methods
    //  normal text string representation
     public String toString()
    {	
        String replyString = "";
       replyString += "Date" +data +  CR;
        replyString += "Login: " + login + CR;
     //   replyString += "HostName " +hostname+   CR; 
     
        
        return replyString;
    };
 
    //  returns data as HTML formatted un-ordered list
    public String toWebString()
    {
        String replyString = "<ul>";
         replyString += "<li><B>Date :</B> " + data   +  CR;
        replyString += "<li><B>Login:</B> " + login +/* ", " + password +*/ CR;
     //   replyString += "<li><B>HostName :</B> " +   hostname +  CR;
       
     
    
        replyString += "</ul>" + CR;
        
        return replyString;        
    }

    // returns data formatted for an HTML table row
    public String toTableString(int rowNumber)
    {
        String replyString = "";   
        String tdBegin = "<td>";
        String tdEnd = "</td>" + CR;
                        
        replyString += "<tr>" + CR;
        replyString += tdBegin + rowNumber + tdEnd; 
         replyString += tdBegin +  data + tdEnd;
        replyString += tdBegin + login + /*", " + password +*/ tdEnd;
       
                               
      //  replyString += tdBegin +  hostname + tdEnd;
       
        
        replyString += "</tr>" + CR; 
                
        return replyString;
    }
}