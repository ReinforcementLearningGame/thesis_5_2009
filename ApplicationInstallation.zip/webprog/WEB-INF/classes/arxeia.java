/***************
  Created by:  Eirini Ntoutsi
  Operation: Implements the model of the player.
*******/
import java.util.*;
import java.io.*;
import java.awt.*;
import java.lang.Math.*;
import java.awt.List;
import java.awt.event.*;
import java.net.*;
import register.stoixeiaModel;
import register.bariVect;
import register.Weka;
import register.pexnidia;
import register.stat;

public class arxeia implements Common
{  	private String webServerStr1 = null;
	private String webServerStr2= null;
	private String webServerStr5= null;
	private String webServerStr6= null;
	private String webServerStr3= null;
    private String servletPath1 = "/webprog/PlayServletVect";
    private String servletPath5 = "/webprog/PexnidiaServlet";
    private String servletPath6 = "/webprog/PlayServletStoreStat";
    private String servletPath2 = "/webprog/PlayServletStoreVect";

   private String servletPath3 = "/webprog/PlayServletStoreWeka";
   private int port1;
	private String	hostName1;
   private int id;
   private String login;
 
  
   //gia ton kathorismo tou montelou tou paikti
	
 	  public arxeia(int boardDimBoard,int boardDimBase,int numOfPawns,String Login,int port,String hostName,String s,String flag )
	   { Storestat(boardDimBoard, boardDimBase, numOfPawns, Login, port, hostName, s,flag);

	  }
	 
 	public arxeia(){}	        
	        
	
    public final  void  Storestat(int boardDimBoard,int boardDimBase,int numOfPawns,String Login,int port,String hostName,String gameMoves,String flag)
 	
	{ 	ObjectInputStream inputFromServlet = null;
	    //PrintWriter outTest = null;
	    BufferedReader inTest = null;
	   
		 if (port == -1)
		 {
		 	port = 80;
		 }
    	webServerStr6 = "http://" + hostName + ":" + port + servletPath6;
       // log("  d "+webServerStr6);
        try
	    {     
	        String servletGET = webServerStr6;
	        
            // connect to the servlet
//            log("Connecting.applet..");
            URL gamesservlet1 = new URL( servletGET);
            URLConnection servletConnection1 = gamesservlet1.openConnection();  
	        	    
	        ///////////// 
	    //   log ("athanasia stat ============"+Login);
            servletConnection1.setDoInput(true);          
	        servletConnection1.setDoOutput(true);
	        servletConnection1.setUseCaches (false);
            servletConnection1.setRequestProperty ("Content-Type", "application/octet-stream");
            stat astat= new stat(boardDimBoard, boardDimBase, numOfPawns,Login,gameMoves,flag);
	          
	        sendstatToServlet1(servletConnection1,astat);
	     
            inputFromServlet = new ObjectInputStream(servletConnection1.getInputStream());

	             
	   	}
	    catch (Exception e)
	    {
	      //   log(e.toString());    
	    } 
	        
	        
	        //Read the input from the servlet.  
	        //
	        // The servlet will return a serialized vector containing
	        // player entries.
	        //
		    
	}  

   
    	public void sendstatToServlet1(URLConnection servletConnection1,stat astat)
    {
        ObjectOutputStream outputToServlet = null;
        
        try
        {
	        
 	    //    log("Sending the data to the servlet...");
	        outputToServlet = new ObjectOutputStream(servletConnection1.getOutputStream());
	        
	        // serialize the object
	        outputToServlet.writeObject(astat);
	        
	        outputToServlet.flush();	        
	        outputToServlet.close();
	    //    log("Complete.");
        }
        catch (IOException e)
        {
         //  log(e.toString());    
        }

    }
    
    
    protected void log(String msg)
	{ 
 	GamesDialog registerDialog = new GamesDialog(new Frame(), true,msg);
	    registerDialog.setVisible(true);
	    
	     
	    if (registerDialog.isRegisterButtonPressed())
	    {
	         
	    }
	    else
	    {
	         
	        return;
	    } 
 	     
	}
    }

//this is the end