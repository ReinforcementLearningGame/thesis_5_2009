package register;
import java.sql.*;

public class stoixeiaModel implements java.io.Serializable
{
    // data members
    private String login;
     
    private int dimboard;
    private int dimbase;
    private int numofpawns;
   
        
    private final String CR = "\n";     // carriage return
       
    // constructors
    public  stoixeiaModel()
    {
    }
    
    public  stoixeiaModel(String aLogin, int adimboard,int adimbase,int anumofpawns) 
    {
        login = aLogin;
         dimboard=adimboard;
     dimbase=adimbase;
     numofpawns=anumofpawns;
       
    }
           
     public  stoixeiaModel(ResultSet dataResultSet)
    {
                
        try 
		{
			System.out.println("stoixeia() start");

            // assign data members
            login = dataResultSet.getString("login");
      //      file_name = dataResultSet.getString("file_name");
            
			System.out.println("games() complete"+login);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }   
    }
 
    //  accessors
    public String getLogin()
    {
        return login;   
    }
    
    public int getdimboard()
    {
        return dimboard;  
         
    }
    
    public int getdimbase()
    {
        return dimbase;  
         
    }
    
   public int getnumofpawns()
    {
        return numofpawns;  
         
    }
    
    //  methods
    //  normal text string representation
     public String toString()
    {	
        String replyString = "";
       
        replyString += "Login: " + login + CR;
       
        
        return replyString;
    };
 
    //  returns data as HTML formatted un-ordered list
    public String toWebString()
    {
        String replyString = "<ul>";
        
        replyString += "<li><B>Login:</B> " + login +  CR;
          
        replyString += "</ul>" + CR;
        
        return replyString;        
    }

    // returns data formatted for an HTML table row
    public String toTableString(int rowNumber)
    {
        String replyString = "";   
        String tdBegin = "<td>";
        String tdEnd = "</td>" + CR;
                        
        replyString += "<tr>" + CR;
        replyString += tdBegin + rowNumber + tdEnd; 
        replyString += tdBegin + login + tdEnd;
      
        
        replyString += "</tr>" + CR; 
                
        return replyString;
    }
}