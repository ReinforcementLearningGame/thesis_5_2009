import java.awt.*;
import java.awt.List;
import java.awt.event.*;
import java.applet.*;
import java.util.*;
import java.io.*;
import java.util.Date;
import java.net.*;
import javax.swing.*;
import javax.swing.JRadioButton;
import java.awt.Color;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import register.Games;
import register.pexnidia;
import register.BookNote;

public class GamesApplet  extends JApplet implements Common
{ 
	private JPanel toolBarPanel;
	private JButton loginButton;
	private JButton onLineButton; ///
	private JButton setupButton;
	private JButton gamesButton;
	private JButton infoButton;
	private JButton bookButton;
	private JButton playerButton;
	private List gamesList;
 	private JRadioButton statusRadioButton;
 	private JRadioButton statusRadioButton1;
	private JPanel statusBarPanel;
	private Label statusLabel;
	JLabel bookLabel=new JLabel();
	private  TextArea statusTextArea;
	private ButtonGroup radioGroup;
    private String webServerStr = null;
    private String webServerStr1 = null;
    private String webServerStr2 = null;
    private String webServerStr5 = null;    
    private String webServerStr6 = null;
    private String hostName = "localhost";
	private int port = 8080;
    private String servletPath = "/webprog/GamesServlet";
    private final int COLUMN_WIDTH = 18;
    private String servletPath1 = "/webprog/PlayServlet";
    private String servletPath2 = "/webprog/PlayServletrec";
    private String servletPath5 = "/webprog/PexnidiaServlet";
    private String servletPath6 = "/webprog/OnLineServlet";
 	private String Login1;
	private int port1;
	private String Host;
	private boolean show=false;


	public void init()
	{  	this.setLayout(new BorderLayout());
	//dimiourgi tin othoni 
		Color c=new Color(153,120,218);	
		setBackground(java.awt.Color.blue);		
		gamesList = new List();
		gamesList.setFont(new Font("monospaced", Font.PLAIN, 12));
 		gamesList.setBackground(java.awt.Color.LIGHT_GRAY);
		this.add(BorderLayout.CENTER, gamesList);
		
		toolBarPanel = new JPanel();
		toolBarPanel.setLayout(new FlowLayout());
		this.add(BorderLayout.NORTH, toolBarPanel); 
      	gamesButton = new JButton ("          PLAY       ");
		toolBarPanel.add (gamesButton);
	    onLineButton = new JButton("   ON LINE PLAYER    ");
		toolBarPanel.add(onLineButton);
	    loginButton = new JButton ("   STOIXEIA   PAIKTH  ");
		toolBarPanel.add (loginButton);
		playerButton = new JButton("     LIST   PLAYER    ");
		toolBarPanel.add(playerButton);
		setupButton = new JButton("       LIST   GAMES    ");
		toolBarPanel.add(setupButton);
		infoButton = new JButton ("          INFO         ");
		toolBarPanel.add(infoButton);
		bookButton =new JButton ("     GUEST BOOK     " );
        bookButton.setToolTipText("Guest Book");
       
        toolBarPanel.add (bookButton);
		statusBarPanel = new JPanel();
		statusBarPanel.setLayout(new FlowLayout());
		this.add(BorderLayout.SOUTH, statusBarPanel); 
		statusLabel = new Label("Status Messages");
		statusBarPanel.add(statusLabel);

        statusTextArea = new  TextArea(3,50);
       	statusBarPanel.add(statusTextArea);
      	statusRadioButton=new JRadioButton(" Hide ",true);
  	 	statusBarPanel.add(statusRadioButton);
  	 	statusRadioButton1=new JRadioButton(" Show ",false);
  	 	statusBarPanel.add(statusRadioButton1);
		statusTextArea.setEditable(false);
  	 	
        onLineButton.addActionListener(new OnLineButtonActionListener());
		gamesButton.addActionListener(new GamesButtonActionListener());
        loginButton.addActionListener(new LoginButtonActionListener());
		playerButton.addActionListener(new PlayerButtonActionListener());
	    infoButton.addActionListener(new InfoButtonActionListener());	
	    setupButton.addActionListener(new SetupButtonActionListener());
	    bookButton.addActionListener(new bookButtonActionListener());
	    
	    
	    statusRadioButton.addActionListener(new StatusButtonActionListener());
	    statusRadioButton1.addActionListener(new StatusButtonActionListener1());
	    radioGroup = new ButtonGroup(); 
  	 	radioGroup.add( statusRadioButton ); 
  	 	radioGroup.add( statusRadioButton1 ); 
        // get the host name and port of the applet's web server        
//	    String login;
        URL hostURL = getCodeBase();
		hostName = hostURL.getHost();
        port = hostURL.getPort();
        Host=hostName;
		if (port == -1)
		{
			port = 80;
		}
		port1=port;
	 	log("Web Server host name: " + hostName);
        webServerStr = "http://" + hostName + ":" + port + servletPath;
        log("Web String full = " + webServerStr);        
        webServerStr1 = "http://" + hostName + ":" + port + servletPath1;
        log("Web String full = " + webServerStr1);  
         webServerStr2 = "http://" + hostName + ":" + port + servletPath2; 
        log("Web String full = " + webServerStr2); 
        webServerStr5  = "http://" + hostName + ":" + port + servletPath5;
        log("Web String full = " + webServerStr6); 
        webServerStr6  = "http://" + hostName + ":" + port + servletPath6;

  }
    
  protected Vector getGamesList()
	{
        ObjectInputStream inputFromServlet = null;
        Vector gamesVector = null;
        try
	    {     
	        // build a GET url string w/ encoded name/value pairs
	        //
	        // Send over UserOption=display.  The servlet will interpret
	        // the user option and send back the player list as a serialized vector
	        // of player objects.
	        //
	        String servletGET = webServerStr + "?" 
	                            + URLEncoder.encode("UserOption") + "=" 
	                            + URLEncoder.encode("display");
	        
            // connect to the servlet
            log("Connecting.applet..");
            URL gamesservlet = new URL( servletGET );
            URLConnection servletConnection = gamesservlet.openConnection();  
	         
	        // Read the input from the servlet.  
	        // The servlet will return a serialized vector containing
	        // player entries.
	        //
			log("Getting input stream");
	        inputFromServlet = new ObjectInputStream(servletConnection.getInputStream());
	        gamesVector = readGamesVector(inputFromServlet);
	    }
	    catch (Exception e)
	    {
	        log(e.toString());
	    }
        return gamesVector;
	}  
	
	protected Vector onLinegetGamesList()
	{
        ObjectInputStream inputFromServlet = null;
        Vector gamesVector = null;
        try
	    {     
	        // build a GET url string w/ encoded name/value pairs
	        //
	        // Send over UserOption=display.  The servlet will interpret
	        // the user option and send back the player list as a serialized vector
	        // of player objects.
	        //
	        String servletGET = webServerStr + "?" 
	                            + URLEncoder.encode("UserOption") + "=" 
	                            + URLEncoder.encode("info");
	        
            // connect to the servlet
            log("Connecting.applet..");
            URL gamesservlet = new URL( servletGET );
            URLConnection servletConnection = gamesservlet.openConnection();  
	         
	        // Read the input from the servlet.  
	        // The servlet will return a serialized vector containing
	        // player entries.
	        //
			log("Getting input stream");
	        inputFromServlet = new ObjectInputStream(servletConnection.getInputStream());
	        gamesVector = readGamesVector(inputFromServlet);
	    }
	    catch (Exception e)
	    {
	        log(e.toString());
	    }
        return gamesVector;
	}  
	
	protected void getGames()
	{
        ObjectInputStream inputFromServlet = null;
        Vector gamesVector = null;
        try
	    {     
	        // build a GET url string w/ encoded name/value pairs
	        //
	        // Send over UserOption=display.  The servlet will interpret
	        // the user option and send back the player list as a serialized vector
	        // of player objects.
	        //
	        String servletGET = webServerStr + "?" 
	                            + URLEncoder.encode("UserOption") + "=" 
	                            + URLEncoder.encode("setup");
	        
            // connect to the servlet
            log("Connecting.applet..");
            URL gamesservlet = new URL( servletGET );
            URLConnection servletConnection = gamesservlet.openConnection();  
	        	    
	        // Read the input from the servlet.  
	        //
	        // The servlet will return a serialized vector containing
	        // player entries.
	        //
			log("Getting input stream");
	      //  inputFromServlet = new ObjectInputStream(servletConnection.getInputStream());

	       // gamesVector = readGamesVector(inputFromServlet);
	        
	    }
	    catch (Exception e)
	    {
	        log(e.toString());
	    }

      //  return gamesVector;
            
	}  

	 protected Vector readGamesVector(ObjectInputStream theInputFromServlet)
    {
        Vector theGamesVector = null;
        
        try
        {	        
            // read the serialized vector of games objects from
            // the servlet
            //
	        log("Reading data...");
	        theGamesVector = (Vector) theInputFromServlet.readObject();
	        log("Finished reading data.  " + theGamesVector.size() + " games returned");
	        theInputFromServlet.close();
        }
        catch (IOException e) 
        {
            log(e.toString());    
        }
        catch (ClassNotFoundException e)
        {
            log(e.toString());                
        }
        catch (Exception e)
		{
            System.out.println(e);                		
		}
		
        return theGamesVector;
    }
    
	 protected void displayGames(Vector gamesVector)
    {   
        Enumeration enuma = gamesVector.elements();
        
        Games aGames = null;
        String login = null;
      //  String password = null;
       	String numOfWinGames = null;	
       	String numOfLostGames = null;	
       	String numOfMovesForGainedGames= null;
       	String numOfMovesForLostGames  =null;
       	String  numOfMoves = null;
       	
		// clear out the list first
	 	gamesList.removeAll();
	//			String headings = createRow("LOGIN ","# GAMES WON","# GAMES LOST",
//		"TOTAL # MOVES FOR GAINED GAMES","TOTAL # MOVES FOR LOST GAMES","TOTAL # OF MOVES");
		
		String headings = createRow("LOGIN ","# GAMES WON","# GAMES LOST",
		"TOTAL # MOVES FOR","TOTAL # MOVES FOR","TOTAL # OF MOVES");
		
		gamesList.add(headings);
	    String headings2 = createRow(" "," "," ","  GAINED GAMES","  LOST GAMES"," ");
   		gamesList.add(headings2);
        String headings1=("------------------|------------------|-------------------|-------------------|-------------------|-------------------|");
//	 	String headings1=("----------------------------------------------------------------------------------------------------------------------");
		gamesList.add(headings1);
         while (enuma.hasMoreElements())
        {
            aGames = (Games) enuma.nextElement();
            login = aGames.getLogin();
//            password = aGames.getPassword();
            numOfWinGames =aGames.getnumOfWinGames();
            numOfLostGames =aGames.getnumOfLostGames();
            numOfMovesForGainedGames =aGames.getnumOfMovesForGainedGames();
            numOfMovesForLostGames =aGames.getnumOfMovesForLostGames();
            numOfMoves =aGames.getnumOfMoves();
                    
            // display this games info as a row 
			String row = createRow(login,numOfWinGames,numOfLostGames,numOfMovesForGainedGames,numOfMovesForLostGames , numOfMoves);
            gamesList.add(row);
        } 
        
    }
	
  	protected void sendGamesToServlet(URLConnection servletConnection, Games theGames)
    {
        ObjectOutputStream outputToServlet = null;
        
        try
        {
	        // send the player object to the servlet using serialization
	        log("Sending the data to the servlet...");
	        outputToServlet = new ObjectOutputStream(servletConnection.getOutputStream());
	        
	        // serialize the object
	        outputToServlet.writeObject(theGames);
	        
	        outputToServlet.flush();	        
	        outputToServlet.close();
	        log("Complete.");
        }
        catch (IOException e)
        {
          log(e.toString());    
        }
    }
   
  protected void readServletResponse(URLConnection servletConnection)
    {
        BufferedReader inFromServlet = null;
        
        try
        {
	        // now, let's read the response from the servlet.
	        // this is simply a confirmation string
	        inFromServlet = new BufferedReader(new InputStreamReader(servletConnection.getInputStream()));
	        
            String str;
            while (null != ((str = inFromServlet.readLine())))
            {
                log("Reading servlet response: " + str);
            }
            
            inFromServlet.close();
        }
        catch (IOException e)
        {
          log(e.toString());    
        }
    }
    
	protected void registerGames()
	{	ObjectInputStream inputFromServlet = null;
	    PrintWriter outTest = null;
	    BufferedReader inTest = null;
	 
        Vector gamesVector = null;
 	    Games theGames = null;
	    String login=null;
	    // show the dialog for registering player
	    GamesRegisterDialog registerDialog = new GamesRegisterDialog(new Frame(), true);
	    registerDialog.setVisible(true);
	    
	    // find out if user selected the register or cancel button
	    if (registerDialog.isRegisterButtonPressed())
	    {
	        theGames = registerDialog.getGames();
            log("Register button: " + registerDialog.isRegisterButtonPressed());
	    }
	    else
	    {
	        // the cancel button was pressed, so do nothing and return
            log("Register button: " + registerDialog.isRegisterButtonPressed());
            Login1="AGNOSTOS";
	        return;
	    }
	   try
        {
            // connect to the servlet
	        log("Connecting to servlet...");
            URL gamesservlet = new URL( webServerStr );
            URLConnection servletConnection = gamesservlet.openConnection();  
	        log("Connected");

            // inform the connection that we will send output and accept input
            servletConnection.setDoInput(true);          
	        servletConnection.setDoOutput(true);
	        
            // Don't used a cached version of URL connection.
             servletConnection.setUseCaches (false);

            // Specify the content type that we will send binary data
            servletConnection.setRequestProperty
                ("Content-Type", "application/octet-stream");
	        	        	                       
	        // send the player object to the servlet using serialization
	        sendGamesToServlet(servletConnection, theGames);
	        Login1=theGames.getLogin();	        
	        login=Login1;
	        // now, let's read the response from the servlet.
	        // this is simply a confirmation string
    	        
           inputFromServlet = new ObjectInputStream(servletConnection.getInputStream());

	        gamesVector = readGamesVector(inputFromServlet);
	        inputFromServlet.close();
		
			displayGames(gamesVector);
		
			 
	   	}
	    catch (Exception e)
	    {
	        log(e.toString());    
	    } 
	   
	   }
	

	        
	        //Read the input from the servlet.  
	        //
	        // The servlet will return a serialized vector containing
	        // player entries.
	        //
		    
 

  

	protected void registerGamesHelp()
	{	ObjectInputStream inputFromServlet = null;
	    PrintWriter outTest = null;
	    BufferedReader inTest = null;
 	    Games theGames = null;
	    String login=null;
	    // show the dialog for registering player
	    GamesRegisterDialogHelp registerDialogHelp = new GamesRegisterDialogHelp(new Frame(), true);
	    registerDialogHelp.setVisible(true);
	    log ("a");
	    
	    // find out if user selected the register or cancel button
	    if (registerDialogHelp.isRegisterButtonPressed())
	    {
	        log("Register button: " + registerDialogHelp.isRegisterButtonPressed());
	    }
	    else
	    {
	        // the cancel button was pressed, so do nothing and return
            log("Register button: " + registerDialogHelp.isRegisterButtonPressed());
	        return;
	    }
	    
    
	    
	}
 	protected String createRow(String login, String numOfWinGames,String numOfLostGames ,
    	  	String numOfMovesForGainedGames,String numOfMovesForLostGames,String numOfMoves )
	{
		StringBuffer row = new StringBuffer();
		String temp = null;
		int a=0;
		temp = padString(login);
		row.append(temp + "|");
 	 	temp = padString( numOfWinGames ); 
 	   	row.append(temp+ "| ");
	    temp = padString(numOfLostGames );
	    row.append(temp+ "| ");
	    temp = padString(numOfMovesForGainedGames ); 
	 	row.append(temp+ "| ");
	 	temp = padString(numOfMovesForLostGames);
	 	row.append(temp+ "| ");	
	    temp = padString(numOfMoves); 
	    row.append(temp+ "| ");
		return row.toString();		
	}
	
  	protected String createRow1(String login,String aDate,String arxtime,String tDate,String teltime,String ergasia )
	{
		StringBuffer row = new StringBuffer();
		String temp = null;
		int a=0;
 	 	temp = padString( login ); 
 	   	row.append(temp+  "| ");	
 	   	temp = padString(aDate);
	 	row.append(temp + "| ");
	    temp = padString(arxtime );
	    row.append(temp+  "| ");
	    temp = padString(tDate);
	 	row.append(temp + "| ");
	    temp = padString(teltime );
	    row.append(temp+  "| ");
	     
	     temp = padString(ergasia );
	    row.append(temp+  "| ");
		return row.toString();		
	}
	/**
	 *  Pads a string w/ extra spaces if it is shorter than the COLUMN_WIDTH
	 */
 	protected String padString(String text)
	{
		StringBuffer result = null;
		
		if (text.length() < COLUMN_WIDTH)
		{
			int count = COLUMN_WIDTH - text.length();
			result = new StringBuffer(text);
			
			for (int i=0; i < count; i++)
			{
				result.append(" ");
			}
		}
		else
		{
			result = new StringBuffer(text.substring(0, COLUMN_WIDTH));
		}
		
		return result.toString();
	}
	
	 protected Vector readpexnidiaVector(ObjectInputStream theInputFromServlet)
    {
        Vector theGamesVector = null;
        
        try
        {	        
            // read the serialized vector of games objects from
            // the servlet
            //
	        log("Reading data...");
	        theGamesVector = (Vector) theInputFromServlet.readObject();
	        log("Finished reading data.  " + theGamesVector.size() + " stoixeia  returned");
	        theInputFromServlet.close();
        }
        catch (IOException e)
        {
            log(e.toString());    
        }
        catch (ClassNotFoundException e)
        {
            log(e.toString());                
        }
        catch (Exception e)
		{
            System.out.println(e);                		
		}
		
        return theGamesVector;
    }
    
	protected Vector getpexnidiaList()
	{
        ObjectInputStream inputFromServlet = null;
        Vector gamesVector = null;
        try
	    {     
	        // build a GET url string w/ encoded name/value pairs
	        //
	        // Send over UserOption=display.  The servlet will interpret
	        // the user option and send back the player list as a serialized vector
	        // of player objects.
	        //
	        String servletGET = webServerStr5 + "?" 
	                            + URLEncoder.encode("UserOption") + "=" 
	                            + URLEncoder.encode("display");
	        
            // connect to the servlet
            log("Connecting.applet..");
            URL gamesservlet = new URL( servletGET );
            URLConnection servletConnection = gamesservlet.openConnection();  
	        	    
	        // Read the input from the servlet.  
	        //
	        // The servlet will return a serialized vector containing
	        // player entries.
	        //
			log("Getting input stream");
	        inputFromServlet = new ObjectInputStream(servletConnection.getInputStream());

	        gamesVector = readpexnidiaVector(inputFromServlet);
	        
	    }
	    catch (Exception e)
	    {
	        log(e.toString());
	    }

        return gamesVector;
            
	}  
 protected void displaypexnidia(Vector stoixia,String enas)
    {   
        Enumeration enuma = stoixia.elements();
        
        pexnidia apexnidia = null;
        String login = null;
      //  String password = null;
       	
       	String arxtime  =null;
       	String teltime = null;
       	String  aDate = null;
       	String  tDate = null;
       	String  ergasia=null;
       	String b="all";
		// clear out the list first
		gamesList.removeAll();
		String headings = createRow1(  " LOGIN "," DATE START "," TIME START ", "END DATE " , "END TIME"," WINNER ");
		gamesList.add(headings);
		String headings1=("------------------|-------------------|-------------------|-------------------|-------------------|-------------------|");
		gamesList.add(headings1);
	 	
       while (enuma.hasMoreElements())
        {
            apexnidia = (pexnidia) enuma.nextElement();
            login = apexnidia.getLogin();
            arxtime =apexnidia.getarxtime();
            teltime =apexnidia.getteltime();
            aDate =apexnidia.getaDate();
            tDate = apexnidia.gettDate();
            ergasia=apexnidia.getergasia();
			if (enas.equals(b))
			{	String row = createRow1(  login,aDate,arxtime,tDate,teltime,ergasia);
	            gamesList.add(row);
	        }
	        else
	        	{if (login.equals(enas))
	        		{String row = createRow1(  login,aDate,arxtime,tDate,teltime,ergasia);
	            	gamesList.add(row);}
	        		
	        	}
        } 
        
    }
	class InfoButtonActionListener implements ActionListener
	{	
		public void actionPerformed(ActionEvent event)
		{
			try
			{ 	registerGamesHelp();
		 			 
			}
			catch (Exception e)
			{
				System.out.println("Error: " + e);
			}
		}
	}
	
 	class GamesButtonActionListener implements ActionListener
	{ 
		public void actionPerformed(ActionEvent event)
		{
			try
			{     registerGames();
				  if     (((Login1.equals("AGNOSTOS"))==false) && ((Login1.equals(""))==false))
				  {	try
					{
				  		AppletContext  appletContext= getAppletContext  ();
						 URL url=null;
						 try
						{
		 			 		url =  new  URL("http://"+hostName+":" + port +"/webprog/index1.jsp?Login1="+Login1);
							appletContext.showDocument(url); 
						}
						catch   (MalformedURLException   e)  
						{
						log("Malformed System.err.println URL: "  + url); 
						}
					}
					catch   (Exception   e)  
						{
						log("Malformed System.err.println URL: "); 
						}
				}
				}
			catch (Exception e)
			{
				System.out.println("Error: " + e);
			}
		
		
	} 
	}
	class OnLineButtonActionListener implements ActionListener
	{ 
		public void actionPerformed(ActionEvent event)
		{
			try
			{
				Vector onLinegamesVector = onLinegetGamesList();
				displayGames(onLinegamesVector);
			}
			catch (Exception e)
			{
				System.out.println("Error: " + e);
			}
		}
	} 
	class PlayerButtonActionListener implements ActionListener
	{ 
		public void actionPerformed(ActionEvent event)
		{
			try
			{
				Vector gamesVector = getGamesList();
				displayGames(gamesVector);
			}
			catch (Exception e)
			{
				System.out.println("Error: " + e);
			}
		}
	} 
	
		class LoginButtonActionListener implements ActionListener
	{ 
		public void actionPerformed(ActionEvent event)
		{
			try
			{
			   String enas=null;
			   Games theGames=null;
			   GamesRegisterDialog registerDialog = new GamesRegisterDialog(new Frame(), true);
			    registerDialog.setVisible(true);
			    
			    // find out if user selected the register or cancel button
			    if (registerDialog.isRegisterButtonPressed())
			    {
			        theGames = registerDialog.getGames();
		            log("Register button: " + registerDialog.isRegisterButtonPressed());
		            enas=theGames.getLogin();
			    }
			    else
			    {
			        // the cancel button was pressed, so do nothing and return
		            log("Register button: " + registerDialog.isRegisterButtonPressed());
		            enas="all";
			        return;
			    }
			    Vector gamesVector = getpexnidiaList();
				displaypexnidia(gamesVector,enas);
			}
			catch (Exception e)
			{
				System.out.println("Error: " + e);
			}
		}
	} 
	class SetupButtonActionListener implements ActionListener
	{ 
		public void actionPerformed(ActionEvent event)
		{   String enas="all";
		 	Vector gamesVector = getpexnidiaList();
			displaypexnidia(gamesVector,enas);
		}
	} 
	  class bookButtonActionListener implements ActionListener
      {
         public void actionPerformed(ActionEvent evt)
         {  	String enas=null;
			    Games theGames=null;
			   GamesRegisterDialog registerDialog = new GamesRegisterDialog(new Frame(), true);
			    registerDialog.setVisible(true);
			    
			    // find out if user selected the register or cancel button
			    if (registerDialog.isRegisterButtonPressed())
			    {
			        theGames = registerDialog.getGames();
		            log("Register button: " + registerDialog.isRegisterButtonPressed());
		            enas=theGames.getLogin();
			    }
			    else
			    {
			        // the cancel button was pressed, so do nothing and return
		            log("Register button: " + registerDialog.isRegisterButtonPressed());
		            enas="all";
			        return;
			    }
         
         if (enas.equals("all"))
        	 log (port1+" sss "+Host+" "+enas);
         else
         {
            	String a="RLGame - Web version - v 2.0 - GuestBook";
	           log (port1+" "+Host+" "+enas);
	           GuestBookWindow mybookWindow = new GuestBookWindow(a,theGames.getLogin() ,port1,Host,theGames.getLogin() );
	           mybookWindow.showBookWindow();
         }
         }
      }
   // bookButtonActionListener mybookAL=new bookButtonActionListener();
   // bookButton.addActionListener(mybookAL);
	
	class StatusButtonActionListener implements ActionListener
	{ 
		public void actionPerformed(ActionEvent event)
		{ 
		 		statusTextArea.setBackground(java.awt.Color.DARK_GRAY);
				statusTextArea.setEditable(false);
				show=false;
		}
	}		
			
	
	class StatusButtonActionListener1 implements ActionListener
	{ 
		public void actionPerformed(ActionEvent event)
		{ 	
			statusTextArea.setBackground(java.awt.Color.white);
			statusTextArea.setEditable(true);
			show=true;
		}
	} 
	
	protected void log(String msg)
	{
	    if (show )
	    	statusTextArea.append(msg + "\n");    
	    	
	}
	
	 public void destroy()
    {
        log("GamesApplet: destroy");
       
    }
}	