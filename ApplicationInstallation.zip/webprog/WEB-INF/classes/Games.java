package register;
import java.sql.*;

public class Games implements java.io.Serializable
{
    // data members
    private String login;
  //  private String password;
    private String numOfWinGames;
	private	String	numOfLostGames ;
	private	String	numOfMovesForGainedGames ;
	private	String	numOfMovesForLostGames ;
	private	String	numOfMoves ;

        
    private final String CR = "\n";     // carriage return
       
    // constructors
    public  Games()
    {
    }
    
    public  Games(String aLogin, /*String aPassword,*/String anumOfWinGames,String anumOfLostGames ,
    		  	String anumOfMovesForGainedGames,String anumOfMovesForLostGames,String anumOfMoves ) 
    {
        login = aLogin;
        //password = aPassword;
        numOfWinGames=anumOfWinGames;
 		numOfLostGames=anumOfLostGames ;
		numOfMovesForGainedGames=anumOfMovesForGainedGames ;
		numOfMovesForLostGames =anumOfMovesForLostGames;
		numOfMoves=anumOfMoves;   
    }
           
     public  Games(ResultSet dataResultSet)
    {
                
        try 
		{
			System.out.println("games() start");

            // assign data members
            login = dataResultSet.getString("login");
          //  password = dataResultSet.getString("password");
            numOfWinGames = dataResultSet.getString("numOfWinGames");
  			numOfLostGames=dataResultSet.getString("numOfLostGames") ;
			numOfMovesForGainedGames=dataResultSet.getString("numOfMovesForGainedGames") ;
			numOfMovesForLostGames =dataResultSet.getString("numOfMovesForLostGames");
			numOfMoves=dataResultSet.getString("numOfMoves"); 
			
			System.out.println("games() complete"+login);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }   
    }
 
    //  accessors
    public String getLogin()
    {
        return login;   
    }
    
    /*public String getPassword()
    {
        return password;   
    }*/
    
    public String getnumOfWinGames()
    {
        return numOfWinGames;   
    }
    
    public String getnumOfLostGames()
    {
        return numOfLostGames;   
    }
    
    public String getnumOfMovesForGainedGames()
    {
        return numOfMovesForGainedGames;   
    }
    
    public String getnumOfMovesForLostGames()
    {
        return numOfMovesForLostGames;   
    }
   public String getnumOfMoves ()
    {
        return numOfMoves ;   
    }
   
    //  methods
    //  normal text string representation
     public String toString()
    {	
        String replyString = "";
       
        replyString += "Login: " + login +/* ","  +password +*/ CR;
        replyString += "Number of win Games: " +numOfWinGames +  CR;
        replyString += "Number of lost Games: " +numOfLostGames  +  CR;
        replyString += "number Of Moves For Gained Games: " +numOfMovesForGainedGames  +  CR;
        replyString += "number Of Moves For Lost Games: " +numOfMovesForLostGames  +  CR;
        replyString += "number Of Moves: " +numOfMoves  +   CR; 
     
        
        return replyString;
    };
 
    //  returns data as HTML formatted un-ordered list
    public String toWebString()
    {
        String replyString = "<ul>";
        
        replyString += "<li><B>Login:</B> " + login +/* ", " + password +*/ CR;
        replyString += "<li><B>Number of win Games: :</B> " +   numOfWinGames +  CR;
        replyString += "<li><B>Number of lost Games: :</B> " + numOfLostGames    +  CR;
        replyString += "<li><B>number Of Moves For Gained Games: :</B> " +  numOfMovesForGainedGames  + CR;
        replyString += "<li><B>number Of Moves For Lost Games: :</B> " +  numOfMovesForLostGames  +  CR;
        replyString += "<li><B>number Of Moves: :</B> " + numOfMoves  +  CR;
    
        replyString += "</ul>" + CR;
        
        return replyString;        
    }

    // returns data formatted for an HTML table row
    public String toTableString(int rowNumber)
    {
        String replyString = "";   
        String tdBegin = "<td>";
        String tdEnd = "</td>" + CR;
                        
        replyString += "<tr>" + CR;
        replyString += tdBegin + rowNumber + tdEnd; 
        replyString += tdBegin + login + /*", " + password +*/ tdEnd;
        replyString += tdBegin +  numOfWinGames + tdEnd;
                               
        replyString += tdBegin +  numOfLostGames + tdEnd;
        replyString += tdBegin +  numOfMovesForGainedGames  + tdEnd;
        replyString += tdBegin +  numOfMovesForLostGames + tdEnd;
        replyString += tdBegin +  numOfMoves   + tdEnd; 
        
        replyString += "</tr>" + CR; 
                
        return replyString;
    }
}