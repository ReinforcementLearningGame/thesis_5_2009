package register;
import java.sql.*;


public class BookNote implements java.io.Serializable
{
    // data members
   
    private String login;
    private String aDate;
 	private String arxtime;
    private String sxolia;
 
        
    private final String CR = "\n";     // carriage return
       
    // constructors
    public  BookNote()
    {
    }
    
    public  BookNote(String aLogin,String aaDate,String aarxtime,String asxolia) 
    {  login = aLogin;
       arxtime=aarxtime;
       aDate=aaDate;  
       sxolia=asxolia; 
    }
           
     public  BookNote(ResultSet dataResultSet)
    {
                
        try 
		{
			System.out.println("games() start");

            // assign data members
        
            login = dataResultSet.getString("login");
        
  			aDate=dataResultSet.getString("aDate") ;
  			arxtime=dataResultSet.getString("arxtime") ; 
       		sxolia=dataResultSet.getString("sxolia") ; 
		
			
			System.out.println("note() complete"+login);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }   
    }
 
    //  accessors
    public String getLogin()
    {
        return login;   
    }
       
    public String getarxtime()
    {
        return arxtime;   
    }
      public String getsxolia()
    {
        return sxolia;   
    }
    public String getaDate()
    {
        return aDate;   
    }
    
    
    //  methods
    //  normal text string representation
     public String toString()
    {	
        String replyString = "";
       replyString += "Date" +aDate +  CR;
        replyString += "Login: " + login + CR;
     
     
        
        return replyString;
    };
 
    //  returns data as HTML formatted un-ordered list
    public String toWebString()
    {
        String replyString = "<ul>";
         replyString += "<li><B>Date :</B> " + aDate    +  CR;
        replyString += "<li><B>Login:</B> " + login +/* ", " + password +*/ CR;
      //  replyString += "<li><B>HostName :</B> " +   hostname +  CR;
       
     
    
        replyString += "</ul>" + CR;
        
        return replyString;        
    }

    // returns data formatted for an HTML table row
    public String toTableString(int rowNumber)
    {
        String replyString = "";   
        String tdBegin = "<td>";
        String tdEnd = "</td>" + CR;
                        
        replyString += "<tr>" + CR;
        replyString += tdBegin + rowNumber + tdEnd; 
        replyString += tdBegin +  aDate + tdEnd;
        replyString += tdBegin + login +  tdEnd;
       
                               
      //  replyString += tdBegin +  hostname + tdEnd;
       
        
        replyString += "</tr>" + CR; 
                
        return replyString;
    }
}