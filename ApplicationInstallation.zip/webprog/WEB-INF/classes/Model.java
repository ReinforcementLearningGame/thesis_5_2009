/***************
  Created by:  Eirini Ntoutsi
  Operation: Implements the model of the player.
*******/
import java.util.*;
import java.io.*;
import java.awt.*;
import java.lang.Math.*;
import java.awt.List;
import java.awt.event.*;
import java.net.*;
import register.stoixeiaModel;
import register.bariVect;
import register.Weka;
import register.pexnidia;
import register.stat;

public class Model implements Common
{  	private String webServerStr1 = null;
	private String webServerStr2= null;
	private String webServerStr5= null;
	private String webServerStr6= null;
	private String webServerStr3= null;
    private String servletPath1 = "/webprog/PlayServletVect";
    private String servletPath5 = "/webprog/PexnidiaServlet";
    private String servletPath6 = "/webprog/PlayServletStoreStat";
    private String servletPath2 = "/webprog/PlayServletStoreVect";
   private String helpName=null;
   private String servletPath3 = "/webprog/PlayServletStoreWeka";
   private int port1;
	private String	hostName1;
   private int id;
   private String login;
   private int numOfWinGames; //# kerdismenon paixnidion
   private int numOfLostGames; //# xamenon paixnidion
   private int numOfMovesForGainedGames; //# kiniseon gia ta kerdismena paixnidia
   private int numOfMovesForLosedGames; //# kiniseon gia ta xamena paixnidia
   private int numOfMoves; //# kiniseon gia ola ta paixnidia

   private Vector historyOfAverageValuesPerMovePerGame;//mesos oros tis aksias ton kiniseon tou paikth gia kathe paixnidi
   private Vector valuesOfChoosenMoves; //ta values ton kiniseon pou epilegei o paiktis sto trexon paixnidi
   private Vector meanSquareDistanceFromNeuralNetBestSuggestions;
   private Vector meanSquareDistanceFromNeuralNetWorstSuggestions;
   private Vector neuralNetBestSuggestionsForPlayer;//dianysma me tis beltistes kiniseis pou  tou proteinei o ypologistis
   private Vector neuralNetWorstSuggestionsForPlayer;//dianysma me tis xeiroteres kiniseis pou  tou proteinei o ypologistis
   private Vector historyOfMovesPerGame; //poses kiniseis exei kanei se kathe paixnidi
   private Vector historyOfGamesResults;//an exei kerdisei i oxi se kathe paixnidi
//   private int pointsOfMaxDeclination; //se posa simeia i apoklisi tou apo ton ypologisti kseperna ena orio (den ksero akomi)

   //gia ton kathorismo tou montelou tou paikti
   private static double BEGINNER_PERCENT=0.4;
   private static double ADVANCED_PERCENT=0.8;
   private int num;
   private int num1;
   private String ast=null;
 	
   public Model(int who,String theLogin)
   {
      id=who;
      login=theLogin;
      historyOfAverageValuesPerMovePerGame=new Vector();
      valuesOfChoosenMoves=new Vector();
      meanSquareDistanceFromNeuralNetBestSuggestions=new Vector();
      meanSquareDistanceFromNeuralNetWorstSuggestions=new Vector();
      neuralNetBestSuggestionsForPlayer=new Vector();
      neuralNetWorstSuggestionsForPlayer=new Vector();
      historyOfMovesPerGame=new Vector();
      historyOfGamesResults=new Vector();
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getPlayerID()
   {
      return id;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateHistoryOfMovesPerGame(double x)
   {
      historyOfMovesPerGame.addElement(new Double(x));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateHistoryOfGamesResults(int s)
   {
   //if s=1=>gain, else if s=0=>lose
      historyOfGamesResults.addElement(new Integer(s));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getNumOfWinGames()
   {
      return numOfWinGames;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void increaseNumOfWinGames()
   {
      numOfWinGames++;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getNumOfLostGames()
   {
      return numOfLostGames;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void increaseNumOfLostGames()
   {
      numOfLostGames++;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getNumOfMovesForGainedGames()
   {
      return numOfMovesForGainedGames;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getNumOfMovesForLosedGames()
   {
      return numOfMovesForLosedGames;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void increaseNumOfWinMoves(int what1 )
   {
      numOfMovesForGainedGames+=what1;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void increaseNumOfLostMoves(int what2)
   {
      numOfMovesForLosedGames+=what2;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getNumOfMoves()
   {
      return (numOfMovesForGainedGames+numOfMovesForLosedGames);
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void increaseNumOfMoves()
   {
      numOfMoves++;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void addValuesOfChoosenMovesForCurrentGame(Double valueOfMovement)
   {
     valuesOfChoosenMoves.addElement(valueOfMovement);
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final double getNumOfPlayedGames()
   {
      return historyOfAverageValuesPerMovePerGame.size();
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final Vector getHistoryOfAverageValuesPerMovePerGame()
   {
      Vector  result=new Vector();
      result=historyOfAverageValuesPerMovePerGame;
      return result;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final Vector getMeanSquareDistanceFromNeuralNetBestSuggestions()
   {
      Vector  result=new Vector();
      result=meanSquareDistanceFromNeuralNetBestSuggestions;
      return result;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final Vector getMeanSquareDistanceFromNeuralNetWorstSuggestions()
   {
      Vector  result=new Vector();
      result=meanSquareDistanceFromNeuralNetWorstSuggestions;
      return result;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateHistoryOfAverageValuesPerMovePerGame(double res)
   {
      historyOfAverageValuesPerMovePerGame.addElement(new Double(res));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void displayHistoryOfAverageValuesPerMovePerGame()
   {
      for (int k=0;k<historyOfAverageValuesPerMovePerGame.size();k++)
         System.out.println("display historyOfAverageValuesPerGame: Game "+k+" = "+historyOfAverageValuesPerMovePerGame.get(k));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void displayValuesOfChoosenMoves()
   {
      for (int k=0;k<valuesOfChoosenMoves.size();k++)
         System.out.println("display valuesOfChoosenMoves: Game "+k+" = "+valuesOfChoosenMoves.get(k));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void displayHistoryOfMovesPerGame()
   {
      for (int k=0;k<historyOfMovesPerGame.size();k++)
         System.out.println("display historyOfMovesPerGame: Game "+k+" = "+historyOfMovesPerGame.get(k));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void displayHistoryOfGamesResults()
   {
      for (int k=0;k<historyOfGamesResults.size();k++)
         System.out.println("display historyOfGamesResults: Game "+k+" = "+historyOfGamesResults.get(k));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateValuesOfChoosenMoves(double x)
   {
       valuesOfChoosenMoves.addElement(new Double(x));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getSizeOfValuesOfChoosenMoves()
   {
       return valuesOfChoosenMoves.size();
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateNeuralNetBestSuggestionsForPlayer(double x)
   {
      neuralNetBestSuggestionsForPlayer.addElement(new Double(x));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final Vector getNeuralNetBestSuggestion()
   {
      Vector  result=neuralNetBestSuggestionsForPlayer;
      return result;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final double getNeuralNetBestSuggestion(int k)
   {
       double tmp = ((Double)neuralNetBestSuggestionsForPlayer.get(k)).doubleValue();
       return tmp;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final double getNeuralNetWorstSuggestion(int k)
   {
       double tmp = ((Double)neuralNetWorstSuggestionsForPlayer.get(k)).doubleValue();
       return tmp;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final double getValueOfChoosenMoves(int k)
   {
       double tmp = ((Double)valuesOfChoosenMoves.get(k)).doubleValue();
       return tmp;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateNeuralNetWorstSuggestionsForPlayer(double x)
   {
       neuralNetWorstSuggestionsForPlayer.addElement(new Double(x));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateMeanSquareDistanceFromNeuralNetBestSuggestions(double z)
   {       meanSquareDistanceFromNeuralNetBestSuggestions.addElement(new Double(z));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void updateMeanSquareDistanceFromNeuralNetWorstSuggestions(double v)
   {
      meanSquareDistanceFromNeuralNetWorstSuggestions.addElement(new Double(v));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void displayMeanSquareDistanceFromNeuralNetBestSuggestions()
   {
      for (int k=0;k<meanSquareDistanceFromNeuralNetBestSuggestions.size();k++)
         System.out.println("display meanSquareDistanceFromNeuralNetBestSuggestions: Game "+k+" = "+meanSquareDistanceFromNeuralNetBestSuggestions.get(k));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void displayMeanSquareDistanceFromNeuralNetWorstSuggestions()
   {
      for (int k=0;k<meanSquareDistanceFromNeuralNetWorstSuggestions.size();k++)
         System.out.println("display meanSquareDistanceFromNeuralNetWorstSuggestions: Game "+k+" = "+meanSquareDistanceFromNeuralNetWorstSuggestions.get(k));
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final Vector getNeuralNetWorstSuggestion()
   {
      Vector  result=neuralNetWorstSuggestionsForPlayer;
      return result;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final Vector getValueOfChoosenMoves()
   {
      Vector  result=valuesOfChoosenMoves;
      return result;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final Vector getHistoryOfGameResults()
   {
      Vector  result=historyOfGamesResults;
      return result;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final int getModel()
   {
      if(numOfWinGames+numOfLostGames<4)
         return UNKNOWN;
      float percent =numOfWinGames/(numOfWinGames+numOfLostGames);
      if (percent<=BEGINNER_PERCENT)
         return BEGINNER;
      if (percent>=ADVANCED_PERCENT)
         return EXPERT;
      return ADVANCED;
   }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final String getLogin()
   {
      return login;
   }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
    /* Loads the model - blasi*/
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public   void loadModel  (int port, String hostName)
   {  Calendar cal=Calendar.getInstance();    
      Date myDate=new Date();
      helpName=myDate.toString();
  	  helpName=helpName.substring(11,19);
      helpName=helpName.replace(':',':');
      int year = cal.get(Calendar.YEAR); 
	  int month = cal.get(Calendar.MONTH)+1; 
	  int day = cal.get(Calendar.DAY_OF_MONTH);	
	  ast=(year+"-"+month+"-"+day).toString();
      System.out.println ("fdgvfdg");
      port1=port;
	  hostName1=hostName;
      try
      {	       
	       getModelList(port,hostName);
	                   
      }
      catch(Exception e)
      {
          System.out.println("sorry");
          e.printStackTrace();
      }
 } 
    
    public boolean  getModelList(int port, String hostName)
	{ 	if (port == -1)
		 {
		 	port = 80;
		 }
  		
		 String Login=login;
    	int dimboard= DIMBOARD;
     	int dimbase= DIMBASE;
    	int numofpawns= NUMOFPAWNS;
        ObjectInputStream inputFromServlet = null;
        log(dimboard+" "+dimbase+" "+numofpawns);
        boolean flag;
        bariVect ModelVector = null;
        try
	    {   webServerStr1 = "http://" + hostName + ":" + port + servletPath1; 
	        String servletGET = webServerStr1;
	       
            // connect to the servlet
            log("Connecting.applet..");
            log(webServerStr1);
           
	        URL gamesservlet1 = new URL(servletGET);
            URLConnection servletConnection1 = gamesservlet1.openConnection();  
	        	    
	        ///////////// 
	       
            servletConnection1.setDoInput(true);          
	        servletConnection1.setDoOutput(true);
	        servletConnection1.setUseCaches (false);
            servletConnection1.setRequestProperty ("Content-Type", "application/octet-stream");
	
	        stoixeiaModel astoixeia=new stoixeiaModel (Login,dimboard,dimbase,numofpawns); 
          	log (astoixeia.getLogin());
            sendModelToServlet(servletConnection1,astoixeia);
	        
	        // Read the input from the servlet.  
	        //
	        // The servlet will return a serialized vector containing
	        // player entries.
	        //
 		//	log("Getting input stream");
	        inputFromServlet = new ObjectInputStream(servletConnection1.getInputStream());
	       try
        	{	        
            // read the serialized vector of weight objects from
            // the servlet
            //
	  	  	  ModelVector = (bariVect )  inputFromServlet.readObject();
		      numOfWinGames=ModelVector.getnumOfWinGames();
		      num=numOfWinGames;
	          numOfLostGames=ModelVector.getnumOfLostGames();
	       	  numOfMoves=ModelVector.getnumOfMoves ();
	          numOfMovesForGainedGames=ModelVector.getnumOfMovesForGainedGames ();
	          numOfMovesForLosedGames= ModelVector.getnumOfMovesForLosedGames();
	          historyOfAverageValuesPerMovePerGame= ModelVector.gethistoryOfAverageValuesPerMovePerGame();
	          historyOfMovesPerGame=ModelVector.gethistoryOfMovesPerGame ();
	          historyOfGamesResults= ModelVector.gethistoryOfGamesResults();
	          meanSquareDistanceFromNeuralNetBestSuggestions=ModelVector.getmeanSquareDistanceFromNeuralNetBestSuggestions(); 
	          meanSquareDistanceFromNeuralNetWorstSuggestions=ModelVector.getmeanSquareDistanceFromNeuralNetWorstSuggestions(); 
		      log("  "+numOfMoves);
		      inputFromServlet.close(); 
	         }   
	        catch (Exception e)
	        {
	            log(e.toString());   log("lathos"); 
	        }
		    if ( numOfWinGames==-1)
		     { 	flag=false;
		      	numOfWinGames=0;
		      	num=numOfWinGames;
		     }
		    else
		        flag = true;
		        
	    }
	    catch (Exception e)
	    {
 	        log(e.toString());
 	        flag = false;
	    }
        return flag;
	}  
     
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
      /* the class name tells the story */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/

    
	    
 protected final void storeModel(int port, String hostName)
{ 	ObjectInputStream inputFromServlet = null;
	BufferedReader inTest = null;
	int dimboard= DIMBOARD;
    int dimbase= DIMBASE;
    int numofpawns= NUMOFPAWNS;
	num1=numOfWinGames;
	bariVect ModelVector =new bariVect (login,dimboard,dimbase,numofpawns,numOfWinGames,numOfLostGames,numOfMoves,numOfMovesForGainedGames,
		  numOfMovesForLosedGames,historyOfAverageValuesPerMovePerGame,historyOfMovesPerGame,
		  historyOfGamesResults,meanSquareDistanceFromNeuralNetBestSuggestions,
          meanSquareDistanceFromNeuralNetWorstSuggestions); 
	 if (port == -1)
	 {
		 	port = 80;
	 }
     webServerStr2 = "http://" + hostName + ":" + port + servletPath2;
     log("  d "+webServerStr2);
     try
	 {     
	        String servletGET = webServerStr2;
            URL gamesservlet1 = new URL( servletGET);
            URLConnection servletConnection1 = gamesservlet1.openConnection();  
	        	    
	        ///////////// 
	       
            servletConnection1.setDoInput(true);          
	        servletConnection1.setDoOutput(true);
	        servletConnection1.setUseCaches (false);
            servletConnection1.setRequestProperty ("Content-Type", "application/octet-stream");
        	sendModelToServlet1(servletConnection1,ModelVector);
            inputFromServlet = new ObjectInputStream(servletConnection1.getInputStream());
	   	}
	    catch (Exception e)
	    {
	         log(e.toString());    
	    } 
	        //Read the input from the servlet.  
	        //
	        // The servlet will return a serialized vector containing
	        // player entries.
	        //
		    
	}  
	public void sendModelToServlet(URLConnection servletConnection1, stoixeiaModel astoixeia)
    {
        ObjectOutputStream outputToServlet = null;
        try
        {
 	        log("Sending the data to the servlet...");
	        outputToServlet = new ObjectOutputStream(servletConnection1.getOutputStream());
	        
	        // serialize the object
	        outputToServlet.writeObject(astoixeia);
	        
	        outputToServlet.flush();	        
	        outputToServlet.close();
	        log("Complete.");
        }
        catch (IOException e)
        {
           log(e.toString());    
        }
    }
    
    	public void sendModelToServlet1(URLConnection servletConnection1,bariVect abari)
    {
        ObjectOutputStream outputToServlet = null;
        
        try
        {
	        
 	        log("Sending the data to the servlet...");
	        outputToServlet = new ObjectOutputStream(servletConnection1.getOutputStream());
	        // serialize the object
	        outputToServlet.writeObject(abari);
	        outputToServlet.flush();	        
	        outputToServlet.close();
	        log("Complete.");
        }
        catch (IOException e)
        {
           log(e.toString());    
        }
    }
    
    protected final void storeWeka( Weka weka)
	{ 	ObjectInputStream inputFromServlet = null;
	    BufferedReader inTest = null;
	    String hostName=hostName1;
	    int port=port1;
		 if (port == -1)
		 {
		 	port = 80;
		 }
    	webServerStr3 = "http://" + hostName + ":" + port + servletPath3;
        log("  d "+webServerStr3);
        try
	    {     
	        String servletGET = webServerStr3;
	        
            // connect to the servlet
//            log("Connecting.applet..");
            URL gamesservlet1 = new URL( servletGET);
            URLConnection servletConnection1 = gamesservlet1.openConnection();  
	        	    
	        ///////////// 
	       
            servletConnection1.setDoInput(true);          
	        servletConnection1.setDoOutput(true);
	        servletConnection1.setUseCaches (false);
            servletConnection1.setRequestProperty ("Content-Type", "application/octet-stream");
	        sendWekaToServlet1(servletConnection1,weka);
	     
            inputFromServlet = new ObjectInputStream(servletConnection1.getInputStream());

	             
	   	}
	    catch (Exception e)
	    {
	         log(e.toString());    
	    } 
	        
	        
	        //Read the input from the servlet.  
	        //
	        // The servlet will return a serialized vector containing
	        // player entries.
	        //
		    
	}  

    
    	public void sendWekaToServlet1(URLConnection servletConnection1,Weka weka)
    {
        ObjectOutputStream outputToServlet = null;
        
        try
        {
	        
 	        log("Sending the data to the servlet...");
	        outputToServlet = new ObjectOutputStream(servletConnection1.getOutputStream());
	        
	        // serialize the object
	        outputToServlet.writeObject(weka);
	        
	        outputToServlet.flush();	        
	        outputToServlet.close();
	        log("Complete.");
        }
        catch (IOException e)
        {
           log(e.toString());    
        }
    }
    
	protected void log(String msg)
	{//	statusTextArea.append(msg + "\n"); 
 		/*GamesDialog registerDialog = new GamesDialog(new Frame(), true,msg);
	    registerDialog.setVisible(true);
	    
	    // find out if user selected the register or cancel button
	    if (registerDialog.isRegisterButtonPressed())
	    {
	        //theGames = registerDialog.getGames();
           // log("Register button: " + registerDialog.isRegisterButtonPressed());
	    }
	    else
	    {
	        // the cancel button was pressed, so do nothing and return
            //log("Register button: " + registerDialog.isRegisterButtonPressed());
	        return;
	    }
//	    statusTextArea.append(msg + "\n");     */
	}
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/

//===============athanasia
	

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
   public final void storeDataForWeka(int numOfMovesForThisGame,
          double averageValueOfChoosenMovesForThisGame,
          double meanSquareDistanceFromNeuralNetBestSuggestionsForThisGame,
          double meanSquareDistanceFromNeuralNetWorstSuggestionsForThisGame,
          String theLogin,
          int result)
   {	
   		Weka weka=new Weka(DIMBOARD,DIMBASE,NUMOFPAWNS,numOfMovesForThisGame,
           averageValueOfChoosenMovesForThisGame,
           meanSquareDistanceFromNeuralNetBestSuggestionsForThisGame,
           meanSquareDistanceFromNeuralNetWorstSuggestionsForThisGame,
           theLogin, result );
           storeWeka(weka);
           int k;
           k=num1-num;
           String kod=null;
           if (k>0) 
           	kod="HUMAN";
           else 
           kod="COMPUTER";	
           Storepexnidi(kod);
      
   }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
 
 public final void  Storepexnidi(String kod)
{	
	{ 	ObjectInputStream inputFromServlet = null;
	    //PrintWriter outTest = null;
	    BufferedReader inTest = null;
	    String hostName=hostName1;
	    int port=port1;
		 if (port == -1)
		 {
		 	port = 80;
		 }
    	webServerStr5 = "http://" + hostName + ":" + port + servletPath5;
        log("  d "+webServerStr5);
        try
	    {     
	        String servletGET = webServerStr5;
            URL gamesservlet1 = new URL( servletGET);
            URLConnection servletConnection1 = gamesservlet1.openConnection();  
	        	    
	        ///////////// 
	       String ergasia=null;
            servletConnection1.setDoInput(true);          
	        servletConnection1.setDoOutput(true);
	        servletConnection1.setUseCaches (false);
            servletConnection1.setRequestProperty ("Content-Type", "application/octet-stream");
            ergasia=kod;
	     	
			 String adate=ast;
	         String bDate=null;
	         String arxtime=helpName;
	         String teltime=null;
	         pexnidia pexnidi1= new pexnidia(ergasia,login,adate,arxtime,bDate,teltime);
	         
	        sendpexnidiToServlet1(servletConnection1,pexnidi1);
	     
            inputFromServlet = new ObjectInputStream(servletConnection1.getInputStream());

	             
	   	}
	    catch (Exception e)
	    {
	         log(e.toString());    
	    } 
	        
	        
	        //Read the input from the servlet.  
	        //
	        // The servlet will return a serialized vector containing
	        // player entries.
	        //
		    
	}  

   } 
    	public void sendpexnidiToServlet1(URLConnection servletConnection1,pexnidia pexnidi)
    {
        ObjectOutputStream outputToServlet = null;
        
        try
        {
	        
 	        log("Sending the data to the servlet...");
	        outputToServlet = new ObjectOutputStream(servletConnection1.getOutputStream());
	        
	        // serialize the object
	        outputToServlet.writeObject(pexnidi);
	        
	        outputToServlet.flush();	        
	        outputToServlet.close();
	        log("Complete.");
        }
        catch (IOException e)
        {
           log(e.toString());    
        }
    }

    }

//this is the end