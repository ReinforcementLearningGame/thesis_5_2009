import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import register.Games;

public class OnlineServlet extends HttpServlet 
{   private OnlineDataAccessor myDataAccessor = null;
	    private String Login;
   private int numOfWinGames; //# kerdismenon paixnidion
   private int numOfLostGames; //# xamenon paixnidion
   private int numOfMovesForGainedGames; //# kiniseon gia ta kerdismena paixnidia
   private int numOfMovesForLosedGames; //# kiniseon gia ta xamena paixnidia
   private int numOfMoves; //# kiniseon gia ola ta paixnidia
    private String CR = "\n";
    /**
	 *  This method is called the first time the servlet is loaded.  Simply
	 *  makes a connection to the database.
	 */
    public void init(ServletConfig config) throws ServletException 
    {
        super.init(config);
     	String value = null;
		String dbDriver = "com.mysql.jdbc.Driver"; 
	    String dbURL =  "jdbc:mysql://localhost/games";
	   	String userid = "ath";
	   	String passwd = "ath";
	 	myDataAccessor = new OnlineDataAccessor(dbDriver, dbURL, userid, passwd);
	}

	/**
	 *  This method is used for applets.
	 *
	 *  Receives and sends the data using object serialization.
	 *
	 *  Gets an input stream from the applet and reads a player object.  Then
	 *  registers the player using our data accessor.  Finally, sends a confirmation
	 *  message back to the applet.
	 */
    public void doPost(HttpServletRequest request,
                        HttpServletResponse response) 
           throws ServletException, IOException
    {
        ObjectInputStream inputFromApplet = null;
        Games aGames = null;        
        PrintWriter out = null;
        BufferedReader inTest = null;
        
        try
        {  
            // get an input stream from the applet
	        inputFromApplet = new ObjectInputStream(request.getInputStream());
	        show("se Connected - on line servlet gia delete ");
	    
	        // read the serialized  data from applet        
	        show("se Reading data...");
	        aGames = (Games) inputFromApplet.readObject();
	        show("Finished reading.");
	        show("se confirmed");
	        inputFromApplet.close();
	            
	        System.out.println(aGames); 
	         myDataAccessor.Deleteonline(aGames);
	        show("se Complete.");
	        show("se init ---");
	         Vector gamesVector = null; 
	        //////////////////
	    		
	      //  myDataAccessor.SaveList2(aGames);  
	        sendGamesList(response, gamesVector); 
            out = new PrintWriter(response.getOutputStream());
 			 out.println("se confirmed");
           
 	 		out.flush();
            out.close();          
            
        }
        catch (Exception e)
        {
			e.printStackTrace();    
        }
    }
    
    
     protected void sendGamesList(HttpServletResponse response, Vector gamesVector)
    {
        ObjectOutputStream outputToApplet;
        
        try
        {
            outputToApplet = new ObjectOutputStream(response.getOutputStream());
            
            System.out.println("Sending games vector to applet...");
            outputToApplet.writeObject(gamesVector);
            outputToApplet.flush();
            
            outputToApplet.close();
            System.out.println("Data transmission complete.");
        }
        catch (IOException e)
        {
			e.printStackTrace(); 
        }
    }
    
  
     protected void cleanUp()
    {
        // close the database connections
        myDataAccessor.cleanUp();
    }
    
     /*
	 *  Destroys the servlet and calls cleanup to close the database connection
	 */
     public void destroy()
    {
        System.out.println("GamesServlet: destroy");
        cleanUp();
    }
    
	/**
	 *  Returns servlet information
	 */
    public String getServletInfo()
    {
        return "<i>Games Registration Servlet, v.06</i>";   
    }
    
	/**
	 *  Simple method for logging messages to the console.
	 */
    protected void show(String msg)
    {
        System.out.println(msg);    
    }
}
