/***************
  Created by:  Panagiotis Kanellopoulos
  Modified by: Eirini Ntoutsi
  Operation: The class of the square: every function performs according to its name
*******/
import java.util.*;

public class Square implements Cloneable,Common
{
  int xCoord,yCoord;
  private boolean isFree; // no pawn is on that square
  private boolean isInWBase;
  private boolean isInBBase;

  public Square(){}

  public Square(int x,int y,int dimBoard,int dimBase)
  {
      xCoord=x;
      yCoord=y;
      isFree=true;
      isInWBase=((x<dimBase)&&(y<dimBase));
      isInBBase=((x>dimBoard-dimBase-1)&&(y>dimBoard-dimBase-1));
/*      if ((x==0)&&(y==1))
        System.out.println("is in white base???"+isInWBase);*/

  }

  public final boolean isFree()
  {
    boolean jjjj=isFree;
    return isFree;
  }

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
            /* the square is free */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public final void setFree()
  {
    isFree=true;
  }

  public final void setUnFree(){
    isFree=false;
  }
  public final boolean isInWhiteBase()
  {
//    return (isInWBase);
      return ((xCoord<DIMBASE)&&(yCoord<DIMBASE));
  }
  public final boolean isInBlackBase()
  {
      return ((xCoord>DIMBOARD-DIMBASE-1)&&(yCoord>DIMBOARD-DIMBASE-1));
//      return (isInBBase);
  }
  public final void setXCoord(int x)
  {
    xCoord=x;
  }
  public final void setYCoord(int y){
    yCoord=y;
  }
  public final int getXCoord(){
    return xCoord;
  }
  public final int getYCoord(){
    return yCoord;
  }
  public final Object clone() {
    Object o = null;
    try {
      o = super.clone();
    } catch (CloneNotSupportedException e) {
        System.out.println("MyObject can't clone");
      }
    return o;
  }

  //tag is a number I map each square with. I use it for describing the move when human players are involved
  public final int square2Tag(){
    return xCoord*DIMBOARD+yCoord+1;
  }
  public final Square tag2Square(int tg){
    int tag=tg-1;
    Square tagSq=new Square();
    tagSq.xCoord=(int)tag/DIMBOARD;
    tagSq.yCoord=(int) tag-DIMBOARD*(tagSq.xCoord);
    return tagSq;
  }

}
//this is the end