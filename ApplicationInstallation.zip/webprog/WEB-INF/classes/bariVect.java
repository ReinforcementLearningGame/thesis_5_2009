package register;
import java.sql.*;
import java.util.*;

public class bariVect implements java.io.Serializable
{
    // data members
 //  private boolean ok;
 private int dimboard;
    private int dimbase;
    private int numofpawns;
   private String Login;
   private int numOfWinGames; //# kerdismenon paixnidion
   private int numOfLostGames; //# xamenon paixnidion
   private int numOfMoves; //# kiniseon gia ola ta paixnidia
   private int numOfMovesForGainedGames; //# kiniseon gia ta kerdismena paixnidia
   private int numOfMovesForLosedGames; //# kiniseon gia ta xamena paixnidia
      private Vector historyOfAverageValuesPerMovePerGame;//mesos oros tis aksias ton kiniseon tou paikth gia kathe paixnidi
   private Vector historyOfMovesPerGame; //poses kiniseis exei kanei se kathe paixnidi
   private Vector historyOfGamesResults;//
    //  private Vector valuesOfChoosenMoves; //ta values ton kiniseon pou epilegei o paiktis sto trexon paixnidi
   private Vector meanSquareDistanceFromNeuralNetBestSuggestions;
   private Vector meanSquareDistanceFromNeuralNetWorstSuggestions;
  // private Vector neuralNetBestSuggestionsForPlayer;//dianysma me tis beltistes kiniseis pou  tou proteinei o ypologistis
  // private Vector neuralNetWorstSuggestionsForPlayer;//dianysma me tis xeiroteres kiniseis pou  tou proteinei o ypologistis
    
    
    private final String CR = "\n";     // carriage return
 
   //   private int pointsOfMaxDeclination; //se posa simeia i apoklisi tou apo ton ypologisti kseperna ena orio (den ksero akomi)

   //gia ton kathorismo tou montelou tou paikti
 
   public bariVect ()
   {
   	}
   	
    public bariVect (String alogin,int adimboard,int adimbase,int anumofpawns,int anumOfWinGames, int anumOfLostGames,int anumOfMoves, int anumOfMovesForGainedGames,
    	int anumOfMovesForLosedGames,Vector ahistoryOfAverageValuesPerMovePerGame,Vector ahistoryOfMovesPerGame,
				    Vector ahistoryOfGamesResults, Vector ameanSquareDistanceFromNeuralNetBestSuggestions,
				    Vector ameanSquareDistanceFromNeuralNetWorstSuggestions)
  
   	{  // ok=aok;
   		Login=alogin;
   		 dimboard=adimboard;
     dimbase=adimbase;
     numofpawns=anumofpawns;
   		numOfWinGames=anumOfWinGames;
 		numOfLostGames=anumOfLostGames ;
		numOfMovesForGainedGames=anumOfMovesForGainedGames ;
		numOfMovesForLosedGames =anumOfMovesForLosedGames;
		numOfMoves=anumOfMoves;  
		historyOfAverageValuesPerMovePerGame=ahistoryOfAverageValuesPerMovePerGame;
      //  valuesOfChoosenMoves = avaluesOfChoosenMoves;
        meanSquareDistanceFromNeuralNetBestSuggestions=ameanSquareDistanceFromNeuralNetBestSuggestions;
		meanSquareDistanceFromNeuralNetWorstSuggestions=ameanSquareDistanceFromNeuralNetWorstSuggestions;
	//	neuralNetBestSuggestionsForPlayer =aneuralNetBestSuggestionsForPlayer;
	//	neuralNetWorstSuggestionsForPlayer=	neuralNetWorstSuggestionsForPlayer;	      
		historyOfMovesPerGame=ahistoryOfMovesPerGame;		      
		historyOfGamesResults=	ahistoryOfGamesResults;	      		     
     }   
   
   
           
     public  bariVect(ResultSet dataResultSet)
    {
                
        try 
		{
			System.out.println("games() start");

            // assign data members
            Login = dataResultSet.getString("xn");
           
			System.out.println("games() complete"+Login);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }   
    }
 
    //  accessors
 /* public boolean getok()
  { return ok;
  }
  */
  public String getLogin()
  {	return Login;
  }
   public int getdimboard()
    {
        return dimboard;  
         
    }
    
    public int getdimbase()
    {
        return dimbase;  
         
    }
    
   public int getnumofpawns()
    {
        return numofpawns;  
         
    }
    
   public int getnumOfWinGames()
    {
        return numOfWinGames;   
    }
    
    public int getnumOfLostGames()
    {
        return numOfLostGames;   
    }
    
    public int getnumOfMovesForGainedGames()
    {
        return numOfMovesForGainedGames;   
    }
    
    public int getnumOfMovesForLosedGames()
    {
        return numOfMovesForLosedGames;   
    }
    
   public int getnumOfMoves ()
    {
        return numOfMoves ;   
    }
    
   public Vector 	gethistoryOfAverageValuesPerMovePerGame()
   {	Vector result=new Vector();
        result=historyOfAverageValuesPerMovePerGame; 
        return result ; 
    }
    
 /* public Vector 	getvaluesOfChoosenMoves()
   { 	Vector result=new Vector();
        result=valuesOfChoosenMoves; 
        return result ; 
    
   }*/
   
  public Vector 	getmeanSquareDistanceFromNeuralNetBestSuggestions()
   {	Vector result=new Vector();
        result=meanSquareDistanceFromNeuralNetBestSuggestions;
        return result ; 
   	}
   
  public Vector 	 getmeanSquareDistanceFromNeuralNetWorstSuggestions()
   { 	Vector result=new Vector();
        result=meanSquareDistanceFromNeuralNetWorstSuggestions;
        return result ; 
   }
   
  /* public Vector 	 getneuralNetBestSuggestionsForPlayer ()
   { Vector result=new Vector();
        result= neuralNetBestSuggestionsForPlayer ;
        return result ; 
      } */
       
 /*  public Vector 	 getneuralNetWorstSuggestionsForPlayer ()
   {	Vector result=new Vector();
        result=neuralNetWorstSuggestionsForPlayer ;
        return result ; 
   
   }  */
    public Vector 	 gethistoryOfMovesPerGame ()
   {Vector result=new Vector();
        result=historyOfMovesPerGame;
        return result ; 
   }  
    
    public Vector 	 gethistoryOfGamesResults ()
   {Vector result=new Vector();
        result= historyOfGamesResults ;
        return result ; 
   }     
	 

   
    
    //  methods
    //  normal text string representation
     public String toString()
    {	
        String replyString = "";
       
        replyString += "Login: " + Login + CR;
        
        
        return replyString;
    };
 
    //  returns data as HTML formatted un-ordered list
    
    // returns data formatted for an HTML table row
    public String toTableString(int rowNumber)
    {
        String replyString = "";   
        String tdBegin = "<td>";
        String tdEnd = "</td>" + CR;
                        
        replyString += "<tr>" + CR;
        replyString += tdBegin + rowNumber + tdEnd; 
        replyString += tdBegin + Login   + tdEnd;
       
        replyString += "</tr>" + CR; 
                
        return replyString;
    }
}