package register;
import java.sql.*;


public class pexnidia implements java.io.Serializable
{
    // data members
    private String ergasia;
    private String login;
    private String aDate;
 	private String arxtime;
  private String tDate;
 	private String teltime;

        
    private final String CR = "\n";     // carriage return
       
    // constructors
    public  pexnidia()
    {
    }
    
    public  pexnidia(String aergasia,String aLogin,String aaDate,String aarxtime,String atDate,String ateltime) 
    {  ergasia=aergasia;
       login = aLogin;
       arxtime=aarxtime;
       teltime=ateltime;
       aDate=aaDate;  
       tDate=atDate; 
    }
           
     public  pexnidia(ResultSet dataResultSet)
    {
                
        try 
		{
			System.out.println("games() start");

            // assign data members
            ergasia=dataResultSet.getString("ergasia");
            login = dataResultSet.getString("login");
        	tDate=dataResultSet.getString("tDate") ;
  			aDate=dataResultSet.getString("aDate") ;
  			arxtime=dataResultSet.getString("arxtime") ; 
       		teltime=dataResultSet.getString("teltime") ; 
		
			
			System.out.println("games() complete"+login);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }   
    }
 
    //  accessors
    public String getLogin()
    {
        return login;   
    }
     public String getergasia()
    {
        return ergasia;   
    }
   
    
    public String getarxtime()
    {
        return arxtime;   
    }
      public String getteltime()
    {
        return teltime;   
    }
    public String getaDate()
    {
        return aDate;   
    }
    
     public String gettDate()
    {
        return tDate;   
    }
    //  methods
    //  normal text string representation
     public String toString()
    {	
        String replyString = "";
       replyString += "Date" +aDate +  CR;
        replyString += "Login: " + login + CR;
     
     
        
        return replyString;
    };
 
    //  returns data as HTML formatted un-ordered list
    public String toWebString()
    {
        String replyString = "<ul>";
         replyString += "<li><B>Date :</B> " + aDate    +  CR;
        replyString += "<li><B>Login:</B> " + login +/* ", " + password +*/ CR;
      //  replyString += "<li><B>HostName :</B> " +   hostname +  CR;
       
     
    
        replyString += "</ul>" + CR;
        
        return replyString;        
    }

    // returns data formatted for an HTML table row
    public String toTableString(int rowNumber)
    {
        String replyString = "";   
        String tdBegin = "<td>";
        String tdEnd = "</td>" + CR;
                        
        replyString += "<tr>" + CR;
        replyString += tdBegin + rowNumber + tdEnd; 
        replyString += tdBegin +  aDate + tdEnd;
        replyString += tdBegin + login +  tdEnd;
       
                               
      //  replyString += tdBegin +  hostname + tdEnd;
       
        
        replyString += "</tr>" + CR; 
                
        return replyString;
    }
}