import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import register.Games;

public class GamesServlet extends HttpServlet 
{   private GamesDataAccessor myDataAccessor = null;
	    private String Login;
   private int numOfWinGames; //# kerdismenon paixnidion
   private int numOfLostGames; //# xamenon paixnidion
   private int numOfMovesForGainedGames; //# kiniseon gia ta kerdismena paixnidia
   private int numOfMovesForLosedGames; //# kiniseon gia ta xamena paixnidia
   private int numOfMoves; //# kiniseon gia ola ta paixnidia
    private String CR = "\n";
    /**
	 *  This method is called the first time the servlet is loaded.  Simply
	 *  makes a connection to the database.
	 */
    public void init(ServletConfig config) throws ServletException 
    {
        super.init(config);
     	String value = null;
		String dbDriver = "com.mysql.jdbc.Driver"; 
	    String dbURL =  "jdbc:mysql://localhost/games";
	   	String userid = "ath";
	   	String passwd = "ath";
	 	myDataAccessor = new GamesDataAccessor(dbDriver, dbURL, userid, passwd);
	}

	/**
	 *  This method is used for applets.
	 *
	 *  Receives and sends the data using object serialization.
	 *
	 *  Gets an input stream from the applet and reads a player object.  Then
	 *  registers the player using our data accessor.  Finally, sends a confirmation
	 *  message back to the applet.
	 */
    public void doPost(HttpServletRequest request,
                        HttpServletResponse response) 
           throws ServletException, IOException
    {
        ObjectInputStream inputFromApplet = null;
        Games aGames = null;        
        PrintWriter out = null;
        BufferedReader inTest = null;
        
        try
        {  
            // get an input stream from the applet
	        inputFromApplet = new ObjectInputStream(request.getInputStream());
	        show("se Connected");
	    
	        // read the serialized  data from applet        
	        show("se Reading data...");
	        aGames = (Games) inputFromApplet.readObject();
	        show("Finished reading.");
	        show("se confirmed");
	        inputFromApplet.close();
	            
	        System.out.println(aGames); 
	         myDataAccessor.PlayerList1(aGames);
	        show("se Complete.");
	        show("se init ---");
	        Vector gamesVector = myDataAccessor.GList(aGames); 
	       
	        //////////////////
	    		
	      //  myDataAccessor.SaveList2(aGames);  
	        sendGamesList(response, gamesVector); 
            out = new PrintWriter(response.getOutputStream());
 			 out.println("se confirmed");
           
 	 		out.flush();
            out.close();          
            
        }
        catch (Exception e)
        {
			e.printStackTrace();    
        }
    }
    
   
   /**
	 *  This method is used by HTML clients and applets.
	 *
	 *  Handles a request and reads information from HTML form data.
	 *
	 *  Figures out if the HTML form is sending a request to register
	 *  or display the player.  Also, handles a request from an applet
	 *  to simply display the player.
	 */
    public void doGet(HttpServletRequest request,
                        HttpServletResponse response) 
           throws ServletException, IOException
    {
        System.out.println("in doGet(...)");
	   	String userOption = null;
        userOption = request.getParameterValues("UserOption")[0];
        System.out.println("\n userOption =" + userOption); 
       if (userOption.equals ("info"))
        {          
            appletDisplayGames1(response); 
        }        
        else if (userOption.equals("setup"))
        { 
               //  RequestDispatcher dispatcher =request.getRequestDispatcher("/index1.jsp");
               // dispatcher.forward(request,response); 
           //  response.sendRedirect("index1.jsp");
  
           //registerGames(request, response);
                   	 
        }
       else if (userOption.equals("display"))
        {   show("Displaying the players");        
            System.out.println("userOption =" + userOption);
            appletDisplayGames(response);  
        } 
    
    }

    /**
	 *  This method is used for applets.
	 *
	 *  Displays the players to the applet.  This is accomplished by
	 *  getting the players list and returning a vector of players.  This
	 *  vector is returned to the applet using object serialization.
	 */
     protected void appletDisplayGames(HttpServletResponse response)
    {
        // build the players vector by accessing the database
        System.out.println("okay, building vector");
        Vector gamesVector = myDataAccessor.getGamesList();
        
        // send the player vector back to the applet using 
        // object serialization
        System.out.println("sending response");
        sendGamesList(response, gamesVector);
    }
    
    protected void appletDisplayGames1(HttpServletResponse response)
    {
        // build the players vector by accessing the database
        System.out.println("okay, building vector");
        Vector gamesVector = myDataAccessor.getGamesList1();
        
        // send the player vector back to the applet using 
        // object serialization
        System.out.println("sending response");
        sendGamesList(response, gamesVector);
    } 
     protected void sendGamesList(HttpServletResponse response, Vector gamesVector)
    {
        ObjectOutputStream outputToApplet;
        
        try
        {
            outputToApplet = new ObjectOutputStream(response.getOutputStream());
            
            System.out.println("Sending games vector to applet...");
            outputToApplet.writeObject(gamesVector);
            outputToApplet.flush();
            
            outputToApplet.close();
            System.out.println("Data transmission complete.");
        }
        catch (IOException e)
        {
			e.printStackTrace(); 
        }
    }
    
    //}

	/**
	 *  Build a players object based on the form data
	 */
 	protected Games buildGames(HttpServletRequest request)	
	{
		Games theGames = null;
		
		try
		{
			String login  = request.getParameterValues("login")[0];
	
	 		String numOfWinGames =  request.getParameterValues ("numOfWinGames")[0] ;
			String numOfLostGames = request.getParameterValues ("numOfLostGames")[0] ;

			String numOfMovesForGainedGames = request.getParameterValues ("numOfMovesForGainedGames")[0];
			String numOfMovesForLostGames = request.getParameterValues ("numOfMovesForLostGames")[0] ;
			String numOfMoves =   request.getParameterValues ("numOfMoves")[0] ;                
 
			theGames = new Games(login,numOfWinGames,numOfLostGames ,numOfMovesForGainedGames, numOfMovesForLostGames, numOfMoves);
		
		}
		
		catch (Exception e)
		{
			System.out.println(e);
		}
		
		return theGames;
	}
	
	/**
	 *  This method is used for players.
	 *
	 *  Creates a new players based on the form data and registers the players
	 *  in the database.  Next, creates a confirmation page for the client.
	 */
      protected void registerGames(HttpServletRequest request,
                                HttpServletResponse response)
    {
		// create a new player based on the form data
 
 		Games aGames = buildGames(request);            
	   // now use the business object to insert data into the database
		
	 	myDataAccessor.PlayerList1(aGames); 
	   	String htmlPage = "<html><head><title>Confirmation Page</title></head>";
		htmlPage += "<body>";
		htmlPage += "<center><h1>Confirmation Page</h1></center><hr>";
		htmlPage += "The following information was entered successfully";
	 	htmlPage += aGames.toWebString();

		htmlPage += "<hr>";
		htmlPage += "<center><a href= /index.html>Return to Home Page</a> | ";
		htmlPage += "<a href=/webprog/GamesServlet>View Player List</a>";
		htmlPage += "<p><i>" + this.getServletInfo() + "</i>";
		htmlPage += "</center></body></html>";
        
		try
		{
			// now let's send this dynamic data
			// back to the browser
			PrintWriter outputToBrowser =  new PrintWriter(response.getOutputStream());

			response.setContentType("text/html");
			outputToBrowser.println(htmlPage);
			outputToBrowser.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();   
		} 
    }

 
	 /*  Simply closes the database connection
	 */
     protected void cleanUp()
    {
        // close the database connections
        myDataAccessor.cleanUp();
    }
    
     /*
	 *  Destroys the servlet and calls cleanup to close the database connection
	 */
     public void destroy()
    {
        System.out.println("GamesServlet: destroy");
        cleanUp();
    }
    
	/**
	 *  Returns servlet information
	 */
    public String getServletInfo()
    {
        return "<i>Games Registration Servlet, v.06</i>";   
    }
    
	/**
	 *  Simple method for logging messages to the console.
	 */
    protected void show(String msg)
    {
        System.out.println(msg);    
    }
}
