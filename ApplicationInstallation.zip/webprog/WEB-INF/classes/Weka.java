package register;
import java.sql.*;

public class Weka implements java.io.Serializable
{
    // data members
  	private int dimbase;
  	private int numofpawns;
  	private int	dimboard;
	private int numOfMovesForThisGame;
    private double averageValueOfChoosenMovesForThisGame;
    private double meanSquareDistanceFromNeuralNetBestSuggestionsForThisGame;
    private double meanSquareDistanceFromNeuralNetWorstSuggestionsForThisGame; 
    private String theLogin; 
    private int result;
/*		DIMBOARD+",");
      wekaData.append(""+DIMBASE+",");
      wekaData.append(""+NUMOFPAWNS+",");
      wekaData.append(""+numOfMovesForThisGame+",");
      wekaData.append(""+averageValueOfChoosenMovesForThisGame+",");
      wekaData.append(""+meanSquareDistanceFromNeuralNetBestSuggestionsForThisGame+",");
      wekaData.append(""+meanSquareDistanceFromNeuralNetWorstSuggestionsForThisGame+",");
      wekaData.append(""+theLogin+",");
      wekaData.append(""+result+"*/
        
    private final String CR = "\n";     // carriage return
       
    // constructors
    public  Weka()
    {
    }
    
    public  Weka(int adimboard,int adimbase,int anumofpawns, int anumOfMovesForThisGame,
          double aaverageValueOfChoosenMovesForThisGame,
          double ameanSquareDistanceFromNeuralNetBestSuggestionsForThisGame,
          double ameanSquareDistanceFromNeuralNetWorstSuggestionsForThisGame,
          String atheLogin,int aresult ) 
    {	 
  
    	dimbase=adimbase;
    	numofpawns=anumofpawns;
    	dimboard=adimboard;
    	numOfMovesForThisGame	=anumOfMovesForThisGame;
          averageValueOfChoosenMovesForThisGame= aaverageValueOfChoosenMovesForThisGame;
          meanSquareDistanceFromNeuralNetBestSuggestionsForThisGame= ameanSquareDistanceFromNeuralNetBestSuggestionsForThisGame;
          meanSquareDistanceFromNeuralNetWorstSuggestionsForThisGame =ameanSquareDistanceFromNeuralNetWorstSuggestionsForThisGame;
          theLogin =atheLogin	;
          result = aresult ;
           
    }
           
  /*   public  Weka(ResultSet dataResultSet)
    {
                
        try 
		{
			System.out.println("games() start");

            // assign data members
            login = dataResultSet.getString("login");
            password = dataResultSet.getString("password");
            numOfWinGames = dataResultSet.getString("numOfWinGames");
  			numOfLostGames=dataResultSet.getString("numOfLostGames") ;
			numOfMovesForGainedGames=dataResultSet.getString("numOfMovesForGainedGames") ;
			numOfMovesForLostGames =dataResultSet.getString("numOfMovesForLostGames");
			numOfMoves=dataResultSet.getString("numOfMoves"); 
			
			System.out.println("games() complete"+login);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }   
    }
 */
    //  accessors
    
    	
   

    public int getresult ()
    {
        return result;   
    }
    public int getnumOfMovesForThisGame()
    {
        return numOfMovesForThisGame;   
    }
    public String gettheLogin()
    {
        return theLogin;   
    }
    public int getdimbase ()
    {
        return dimbase;   
    }
    public int getnumofpawns()
    {
        return numofpawns;   
    }
    
    public int getdimboard ()
    {
        return dimboard;   
    }
    
     public double getaverageValueOfChoosenMovesForThisGame()
    {
        return averageValueOfChoosenMovesForThisGame;   
    }
    
    public double getmeanSquareDistanceFromNeuralNetBestSuggestionsForThisGame()
    {
        return meanSquareDistanceFromNeuralNetBestSuggestionsForThisGame;   
    }
    
    public double getmeanSquareDistanceFromNeuralNetWorstSuggestionsForThisGame()
    {
        return meanSquareDistanceFromNeuralNetWorstSuggestionsForThisGame;   
    }
   
    //  methods
    //  normal text string representation
    /* public String toString()
    {	
        String replyString = "";
       
        replyString += "Login: " + login + ","  +password + CR;
        replyString += "Number of win Games: " +numOfWinGames +  CR;
        replyString += "Number of lost Games: " +numOfLostGames  +  CR;
        replyString += "number Of Moves For Gained Games: " +numOfMovesForGainedGames  +  CR;
        replyString += "number Of Moves For Lost Games: " +numOfMovesForLostGames  +  CR;
        replyString += "number Of Moves: " +numOfMoves  +   CR; 
     
        
        return replyString;
    };
 
    //  returns data as HTML formatted un-ordered list
    public String toWebString()
    {
        String replyString = "<ul>";
        
        replyString += "<li><B>Login:</B> " + login + ", " + password + CR;
        replyString += "<li><B>Number of win Games: :</B> " +   numOfWinGames +  CR;
        replyString += "<li><B>Number of lost Games: :</B> " + numOfLostGames    +  CR;
        replyString += "<li><B>number Of Moves For Gained Games: :</B> " +  numOfMovesForGainedGames  + CR;
        replyString += "<li><B>number Of Moves For Lost Games: :</B> " +  numOfMovesForLostGames  +  CR;
        replyString += "<li><B>number Of Moves: :</B> " + numOfMoves  +  CR;
    
        replyString += "</ul>" + CR;
        
        return replyString;        
    }

    // returns data formatted for an HTML table row
    public String toTableString(int rowNumber)
    {
        String replyString = "";   
        String tdBegin = "<td>";
        String tdEnd = "</td>" + CR;
                        
        replyString += "<tr>" + CR;
        replyString += tdBegin + rowNumber + tdEnd; 
        replyString += tdBegin + login + ", " + password + tdEnd;
        replyString += tdBegin +  numOfWinGames + tdEnd;
                               
        replyString += tdBegin +  numOfLostGames + tdEnd;
        replyString += tdBegin +  numOfMovesForGainedGames  + tdEnd;
        replyString += tdBegin +  numOfMovesForLostGames + tdEnd;
        replyString += tdBegin +  numOfMoves   + tdEnd; 
        
        replyString += "</tr>" + CR; 
                
        return replyString;
    }*/
}