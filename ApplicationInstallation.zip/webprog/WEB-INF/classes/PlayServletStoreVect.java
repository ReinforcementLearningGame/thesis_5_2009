import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.net.*;
import register.stoixeiaModel;
import register.bariVect;
//import register.barimono;
import register.Games;

public class PlayServletStoreVect extends HttpServlet 
{    private GamesDataAccessor myDataAccessor = null;
    private String CR = "\n";
     double[][] v;// array of weights between layers 1->2
  	 double[][] w;// array of weights between layers 2->3
     private String Login;
   private int numOfWinGames; //# kerdismenon paixnidion
   private int numOfLostGames; //# xamenon paixnidion
   private int numOfMovesForGainedGames; //# kiniseon gia ta kerdismena paixnidia
   private int numOfMovesForLosedGames; //# kiniseon gia ta xamena paixnidia
   private int numOfMoves; //# kiniseon gia ola ta paixnidia

   private Vector historyOfAverageValuesPerMovePerGame;//mesos oros tis aksias ton kiniseon tou paikth gia kathe paixnidi
   private Vector valuesOfChoosenMoves; //ta values ton kiniseon pou epilegei o paiktis sto trexon paixnidi
   private Vector meanSquareDistanceFromNeuralNetBestSuggestions;
   private Vector meanSquareDistanceFromNeuralNetWorstSuggestions;
   private Vector neuralNetBestSuggestionsForPlayer;//dianysma me tis beltistes kiniseis pou  tou proteinei o ypologistis
   private Vector neuralNetWorstSuggestionsForPlayer;//dianysma me tis xeiroteres kiniseis pou  tou proteinei o ypologistis
   private Vector historyOfMovesPerGame; //poses kiniseis exei kanei se kathe paixnidi
   private Vector historyOfGamesResults;//an exei kerdisei i oxi se kathe paixnidi
    
    /**
	 *  This method is called the first time the servlet is loaded.  Simply
	 *  makes a connection to the database.
	 */
    public void init(ServletConfig config) throws ServletException 
    {
        super.init(config);
  	    	String value = null;
		String dbDriver = "com.mysql.jdbc.Driver"; 
	    String dbURL =  "jdbc:mysql://localhost/games";
	   	String userid = "ath";
	   	String passwd = "ath";
	 	myDataAccessor = new GamesDataAccessor(dbDriver, dbURL, userid, passwd);
	}

	/**
	 *  This method is used for applets.
	 *
	 *  Receives and sends the data using object serialization.
	 *
	 *  Gets an input stream from the applet and reads a player object.  Then
	 *  registers the player using our data accessor.  Finally, sends a confirmation
	 *  message back to the applet.
	 */
      public void doPost(HttpServletRequest request,
                        HttpServletResponse response) 
           throws ServletException, IOException
    {   
        ObjectInputStream inputFromApplet = null;
         
        PrintWriter out3 = null;
        BufferedReader inTest = null;
        bariVect abari=null;
        ObjectOutputStream outputToApplet;   
        try
        {  
            // get an input stream from the applet
	        inputFromApplet = new ObjectInputStream(request.getInputStream());
	        show("se Connected");
	     
	        // read the serialized  data from applet        
	        show("se Reading data...");
	        
	         abari = (bariVect) inputFromApplet.readObject();
	        show("Finished reading.");
	      
	        show("o kodikos  "+abari.getLogin() );
	    	Login=abari.getLogin();
	         inputFromApplet.close();
	    	 storeModel(Login,abari);   
	         outputToApplet = new ObjectOutputStream(response.getOutputStream());
            
            System.out.println("Sending weight vector to applet...");
           // outputToApplet.writeObject(WeightVector); 
            outputToApplet.flush();
            
            outputToApplet.close();
            System.out.println("Data transmission complete.");
        }
        catch ( Exception e)
        {	log("lathos piso");
			e.printStackTrace(); 
        } 
         
       
    }  
 	public final void storeModel(String Login,bariVect abari )
   {
          try
          {
          ObjectOutputStream out =new ObjectOutputStream(new FileOutputStream("/RLGames/Games/"+Login+"/"+Login+""+"_Model_{"+abari.getdimboard()+""+abari.getdimbase() +""+abari.getnumofpawns()+"}.txt"));
       
           numOfWinGames= abari.getnumOfWinGames();
           numOfLostGames= abari.getnumOfLostGames();
           numOfMoves =abari.getnumOfMoves();
         
            numOfMovesForGainedGames=abari.getnumOfMovesForGainedGames();
            numOfMovesForLosedGames=abari.getnumOfMovesForLosedGames();
           String password="ath";
           String a1=new  Integer (numOfWinGames).toString();  
           String a2=new  Integer ( numOfLostGames).toString();
          
          String a3=new  Integer (  numOfMovesForGainedGames).toString();
           String a4=new  Integer (  numOfMovesForLosedGames).toString();
           String a5=new  Integer (numOfMoves).toString();
			Games agames=new Games(Login,a1,a2,a3,a4,a5);
			myDataAccessor.SaveList(agames);
			myDataAccessor.SaveList1(agames);
            historyOfAverageValuesPerMovePerGame= abari.gethistoryOfAverageValuesPerMovePerGame() ;
            historyOfMovesPerGame= abari.gethistoryOfMovesPerGame() ;
            historyOfGamesResults= abari.gethistoryOfGamesResults() ;
            meanSquareDistanceFromNeuralNetBestSuggestions= abari.getmeanSquareDistanceFromNeuralNetBestSuggestions() ;
            meanSquareDistanceFromNeuralNetWorstSuggestions= abari.getmeanSquareDistanceFromNeuralNetWorstSuggestions() ;
             
            out.writeObject(new Integer(numOfWinGames));
            out.writeObject(new Integer(numOfLostGames));
            out.writeObject(new Integer( numOfMoves ));
            out.writeObject(new Integer( numOfMovesForGainedGames ));
            out.writeObject(new Integer( numOfMovesForLosedGames  ));
            out.writeObject( historyOfAverageValuesPerMovePerGame );
            out.writeObject( historyOfMovesPerGame );
            out.writeObject( historyOfGamesResults );
            out.writeObject( meanSquareDistanceFromNeuralNetBestSuggestions  );
            out.writeObject(  meanSquareDistanceFromNeuralNetWorstSuggestions );
            out.close();
          }
          catch(Exception e){System.out.println("Error in writing to  file "+Login+"_model.txt."); e.printStackTrace(); }
   } 

    
     /*
	 *  Destroys the servlet and calls cleanup to close the database connection
	 */
     public void destroy()
    {
        System.out.println("PlayServlet: destroy");
        
    }
    
	/**
	 *  Returns servlet information
	 */
    public String getServletInfo()
    {
        return "<i>Games Registration Servlet, v.06</i>";   
    }
    
	/**
	 *  Simple method for logging messages to the console.
	 */
    protected void show(String msg)
    {
        System.out.println(msg);    
    }
}
