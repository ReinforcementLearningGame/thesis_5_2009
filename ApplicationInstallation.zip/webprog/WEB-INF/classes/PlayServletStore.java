import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.net.*;
import register.stoixeia;
import register.bari;
//import register.barimono;

public class PlayServletStore extends HttpServlet 
{    
    private String CR = "\n";
     double[][] v;// array of weights between layers 1->2
  	 double[][] w;// array of weights between layers 2->3
   
    /**
	 *  This method is called the first time the servlet is loaded.  Simply
	 *  makes a connection to the database.
	 */
    public void init(ServletConfig config) throws ServletException 
    {
        super.init(config);
  
	}

	/**
	 *  This method is used for applets.
	 *
	 *  Receives and sends the data using object serialization.
	 *
	 *  Gets an input stream from the applet and reads a player object.  Then
	 *  registers the player using our data accessor.  Finally, sends a confirmation
	 *  message back to the applet.
	 */
      public void doPost(HttpServletRequest request,
                        HttpServletResponse response) 
           throws ServletException, IOException
    {   
        ObjectInputStream inputFromApplet = null;
        
        Vector weights = null;        
        PrintWriter out3 = null;
        BufferedReader inTest = null;
        bari abari=null;
        ObjectOutputStream outputToApplet;   
        try
        {  
            // get an input stream from the applet
	        inputFromApplet = new ObjectInputStream(request.getInputStream());
	        show("se Connected");
	     
	        // read the serialized  data from applet        
	        show("se Reading data...");
	        
	         abari = (bari) inputFromApplet.readObject();
	        show("Finished reading.");
	        show("o kodikos  "+abari.getLogin()+" vcv "+abari.getNameFile());
	        String name_file=abari.getNameFile();
	        String Login=abari.getLogin();
 	        Vector   vect =abari.getv();
 	        show("ok onoma "+name_file +" a");
 	        inputFromApplet.close();
	        if (abari.getNameFile().equals("whVWeights")) 
	               	storeWeights1(Login,name_file,vect); 
	        if  (abari.getNameFile().equals("blVWeights"))
	          	storeWeights1(Login,name_file,vect); 
	        if  (name_file.equals("whWWeights")) 
	    		 storeWeights(Login,name_file,vect); 
			if (name_file.equals( "blWWeights"))
			  	 storeWeights(Login,name_file,vect); 
            outputToApplet = new ObjectOutputStream(response.getOutputStream());
            
            System.out.println("Sending weight vector to applet...");
           // outputToApplet.writeObject(WeightVector); 
            outputToApplet.flush();
            
            outputToApplet.close();
            System.out.println("Data transmission complete.");
        }
        catch ( Exception e)
        {	log("lathos piso");
			e.printStackTrace(); 
        } 
         
       
    }  

  
     public void storeWeights1(String Login,String name_file, Vector vect)
    {	show("name 1"+name_file);
    
       
            int t=-1;
	        double [][] vv = new double[123][62];
	        for (int i = 0; i <=  122 ; i++) {
	            for (int j = 0; j <= 61; j ++) {
	                 t++; 
	              vv[i][j] =((Double) vect.elementAt(t)).doubleValue() ;
  	       
	          }
	          }
	      
	        try
	        { ObjectOutputStream out2 = 
	        new ObjectOutputStream(new FileOutputStream ("/RLGames/Games/"+Login+"/"+name_file));
	        out2.writeObject(vv);
	        out2.close();
	        
	        }   
	        catch (Exception e)
	        { e.printStackTrace();
	        	show ("problem");
	        }
	       }
	       
	     
      public void storeWeights(String Login,String name_file, Vector vect)
    {	show("name STOREwEIGHTS "+name_file+"  "+vect.size());
       	   	int t=-1;
	        double [][] ww = new double[62][2];
	        for (int i = 0; i <62; i++) {
	           
	                 t++; 
	                
	              ww[i][0] =((Double) vect.elementAt(t)).doubleValue() ; 
	              }
	            
	        try
	        {  
	        ObjectOutputStream out1 = 
	        new ObjectOutputStream(new FileOutputStream ("/RLGames/Games/"+Login+"/"+name_file));
	        out1.writeObject(ww);
	        out1.close();
	        
	        }   
	        catch (Exception e)
	        { e.printStackTrace();
	        	show ("problem");
	        } 
	     }
   
   

     /*
	 *  Destroys the servlet and calls cleanup to close the database connection
	 */
     public void destroy()
    {
        System.out.println("PlayServlet: destroy");
        
    }
    
	/**
	 *  Returns servlet information
	 */
    public String getServletInfo()
    {
        return "<i>Games Registration Servlet, v.06</i>";   
    }
    
	/**
	 *  Simple method for logging messages to the console.
	 */
    protected void show(String msg)
    {
        System.out.println(msg);    
    }
}
