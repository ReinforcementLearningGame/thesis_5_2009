/***************
  Created by:  athanasia Vlasi
  Operation: Creates a parent window
*******/
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.awt.*;
import java.awt.List;
import java.awt.geom.*;
import javax.swing.border.*;
import java.io.*;
import java.util.Date;
import java.net.*;
import register.Games;


public class OnlineDelete extends JComponent
{
   private static String title;
 // private static String textToShow;
   //private static String firstButtonTitle;
  // private static String firstButtonTextToShow;
   	///	private  List showList;
  // private Dimension minSize=new Dimension(200,200);
   private static String webServerStr9  = null;
   private String hostName = "localhost";
  // private  List showList;
   private static String servletPath9  = "/webprog/OnlineServlet";
   private static String Login1;
   private static int port1;
  
	/*	*/
   //constructor

   public OnlineDelete (int port,String hostname1,String Login)
   {   	super(); 
   		Login1=Login;
    	port1 = port;
     	hostName=hostname1;	
//        setSize(minSize);
  }


   	protected void registerGames()//(int port,String hostname1,String Login)
	{	ObjectInputStream inputFromServlet = null;
	    PrintWriter outTest = null;
	    BufferedReader inTest = null;
	 
        Vector gamesVector = null;
 
	   // String LoginA=Login;
	    //String hostnameA=hostname1;
	    //int portA=port;
	    // show the dialog for registering player
	    if (port1 == -1)
		 {
		 	port1 = 80;
		 }
    	webServerStr9 = "http://" + hostName + ":" + port1 + servletPath9;
     //   log("  d "+webServerStr5);
      
	   try
        {String servletGET = webServerStr9;
            // connect to the servlet

            URL gamesservlet = new URL( webServerStr9 );
            URLConnection servletConnection = gamesservlet.openConnection();  
	   

            // inform the connection that we will send output and accept input
            servletConnection.setDoInput(true);          
	        servletConnection.setDoOutput(true);
	        
            // Don't used a cached version of URL connection.
             servletConnection.setUseCaches (false);

            // Specify the content type that we will send binary data
            servletConnection.setRequestProperty
                ("Content-Type", "application/octet-stream");
	         Games theGames=new Games(Login1,"0","0","0","0","0");
	             	                       
	        // send the player object to the servlet using serialization
	        sendGamesToServlet(servletConnection, theGames);
	      
	        // now, let's read the response from the servlet.
	        // this is simply a confirmation string
    	        
           inputFromServlet = new ObjectInputStream(servletConnection.getInputStream());

	        gamesVector = readGamesVector(inputFromServlet);
	        inputFromServlet.close();
		
		//	displayGames(gamesVector);
		
			 
	   	}
	    catch (Exception e)
	    {
	  //      log(e.toString());    
	    } 
	   
	   }
	
		protected void sendGamesToServlet(URLConnection servletConnection, Games theGames)
    {
        ObjectOutputStream outputToServlet = null;
        
        try
        {
	        // send the player object to the servlet using serialization
	    //    log("Sending the data to the servlet...");
	        outputToServlet = new ObjectOutputStream(servletConnection.getOutputStream());
	        
	        // serialize the object
	        outputToServlet.writeObject(theGames);
	        
	        outputToServlet.flush();	        
	        outputToServlet.close();
	   //     log("Complete.");
        }
        catch (IOException e)
        {
       //   log(e.toString());    
        }
    }
   
 	protected Vector onLinegetGamesList()
	{
        ObjectInputStream inputFromServlet = null;
        Vector gamesVector = null;
        if (port1 == -1)
		 {
		 	port1 = 80;
		 }
    	webServerStr9 = "http://" + hostName + ":" + port1 + servletPath9;
        try
	    {     
	        // build a GET url string w/ encoded name/value pairs
	        //
	        // Send over UserOption=display.  The servlet will interpret
	        // the user option and send back the player list as a serialized vector
	        // of player objects.
	        //
	        String servletGET = webServerStr9 + "?" 
	                            + URLEncoder.encode("UserOption") + "=" 
	                            + URLEncoder.encode("info");
	        
            // connect to the servlet
//            log("Connecting.applet..");
            URL gamesservlet = new URL( servletGET );
            URLConnection servletConnection = gamesservlet.openConnection();  
	         
	        // Read the input from the servlet.  
	        // The servlet will return a serialized vector containing
	        // player entries.
	        //
//			log("Getting input stream");
	        inputFromServlet = new ObjectInputStream(servletConnection.getInputStream());
	        gamesVector = readGamesVector(inputFromServlet);
	      
	         
	    }
	    catch (Exception e)
	    {
//	        log(e.toString());
	    }
        return gamesVector;
	}  

   
   
   protected Vector readGamesVector(ObjectInputStream theInputFromServlet)
    {
        Vector theGamesVector = null;
        
        try
        {	        
            // read the serialized vector of games objects from
            // the servlet
            //
	    //    log("Reading data...");
	        theGamesVector = (Vector) theInputFromServlet.readObject();
	  //      log("Finished reading data.  " + theGamesVector.size() + " games returned");
	        theInputFromServlet.close();
        }
        catch (IOException e)
        {
     //       log(e.toString());    
        }
        catch (ClassNotFoundException e)
        {
    //        log(e.toString());                
        }
        catch (Exception e)
		{
            System.out.println(e);                		
		}
		
        return theGamesVector;
    }
    
	
}