import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.net.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.OutputStreamWriter;

import register.stoixeiaModel;
import register.bariVect;
//import register.barimono;
import register.Weka;

public class PlayServletStoreWeka extends HttpServlet 
{   // private GamesDataAccessor myDataAccessor = null;
    private String CR = "\n";
    	private int dimbase;
  	private int numofpawns;
  	private int	dimboard;
	private int numOfMovesForThisGame;
    private double averageValueOfChoosenMovesForThisGame;
    private double meanSquareDistanceFromNeuralNetBestSuggestionsForThisGame;
    private double meanSquareDistanceFromNeuralNetWorstSuggestionsForThisGame; 
    private String theLogin; 
    private int result;
    FileWriter out;
    /**
	 *  This method is called the first time the servlet is loaded.  Simply
	 *  makes a connection to the database.
	 */
    public void init(ServletConfig config) throws ServletException 
    {
        super.init(config);
  	 	}

	/**
	 *  This method is used for applets.
	 *
	 *  Receives and sends the data using object serialization.
	 *
	 *  Gets an input stream from the applet and reads a player object.  Then
	 *  registers the player using our data accessor.  Finally, sends a confirmation
	 *  message back to the applet.
	 */
      public void doPost(HttpServletRequest request,
                        HttpServletResponse response) 
           throws ServletException, IOException
    {  
        ObjectInputStream inputFromApplet = null;
             
        PrintWriter out3 = null;
        BufferedReader inTest = null;
        Weka weka=null;
        ObjectOutputStream outputToApplet;   
        try
        {  
            // get an input stream from the applet
	        inputFromApplet = new ObjectInputStream(request.getInputStream());
	        show("se Connected");
	     
	        // read the serialized  data from applet        
	        show("se Reading data...");
	        
	         weka = (Weka) inputFromApplet.readObject();
	        show("Finished reading.");
	     
	        show("o kodikos  "+weka.gettheLogin() );
	    
	         inputFromApplet.close();
	 
	    	 storeWeka(weka);   
	    
	         show("ok  ");  
	  
            outputToApplet = new ObjectOutputStream(response.getOutputStream());
            
            System.out.println("Sending weight vector to applet...");
           // outputToApplet.writeObject(WeightVector); 
            outputToApplet.flush();
            
            outputToApplet.close();
            System.out.println("Data transmission complete.");
        }
        catch ( Exception e)
        {	log("lathos piso");
			e.printStackTrace(); 
        } 
         
       
    }  
    
      
 	public final void storeWeka (Weka weka)
   {	 TextArea wekaData=new TextArea();
	      wekaData.append(""+weka.getdimboard()+",");
	      wekaData.append(""+weka.getdimbase()+",");
	      wekaData.append(""+weka.getnumofpawns()+",");
	      wekaData.append(""+weka.getnumOfMovesForThisGame()+",");
	      wekaData.append(""+weka.getaverageValueOfChoosenMovesForThisGame()+",");
	      wekaData.append(""+weka.getmeanSquareDistanceFromNeuralNetBestSuggestionsForThisGame()+",");
	      wekaData.append(""+weka.getmeanSquareDistanceFromNeuralNetWorstSuggestionsForThisGame()+",");
	      wekaData.append(""+weka.gettheLogin()+",");
	      wekaData.append(""+weka.getresult()+"\n");
	     
    	 String s=wekaData.getText();
    	 String name="/RLGames/Games/"+weka.gettheLogin()+"/"+"WEKA";
         try
      {
          out=new FileWriter(name+".txt",true);
          out.write(s);
          out.close();
      }
      catch (IOException e1)
      	{System.out.println("error in file "+name+".txt");}
   }
 
 
     /*
	 *  Destroys the servlet and calls cleanup to close the database connection
	 */
     public void destroy()
    {
        System.out.println("PlayServlet: destroy");
        
    }
    
	/**
	 *  Returns servlet information
	 */
    public String getServletInfo()
    {
        return "<i>Games Registration Servlet, v.06</i>";   
    }
    
	/**
	 *  Simple method for logging messages to the console.
	 */
    protected void show(String msg)
    {
        System.out.println(msg);    
    }
}
