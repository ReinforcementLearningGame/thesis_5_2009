package register;
import java.sql.*;

public class stoixeia implements java.io.Serializable
{
    // data members
    private String login;
    private String file_name;
   
        
    private final String CR = "\n";     // carriage return
       
    // constructors
    public  stoixeia()
    {
    }
    
    public  stoixeia(String aLogin, String afile_name ) 
    {
        login = aLogin;
        file_name = afile_name;
       
    }
           
     public  stoixeia(ResultSet dataResultSet)
    {
                
        try 
		{
			System.out.println("stoixeia() start");

            // assign data members
            login = dataResultSet.getString("login");
            file_name = dataResultSet.getString("file_name");
            
			System.out.println("games() complete"+login);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }   
    }
 
    //  accessors
    public String getLogin()
    {
        return login;   
    }
    
    public String getfile_name()
    {
        return file_name;   
    }
    
   
    //  methods
    //  normal text string representation
     public String toString()
    {	
        String replyString = "";
       
        replyString += "Login: " + login + ","  +file_name+ CR;
       
        
        return replyString;
    };
 
    //  returns data as HTML formatted un-ordered list
    public String toWebString()
    {
        String replyString = "<ul>";
        
        replyString += "<li><B>Login:</B> " + login + ", " + file_name + CR;
          
        replyString += "</ul>" + CR;
        
        return replyString;        
    }

    // returns data formatted for an HTML table row
    public String toTableString(int rowNumber)
    {
        String replyString = "";   
        String tdBegin = "<td>";
        String tdEnd = "</td>" + CR;
                        
        replyString += "<tr>" + CR;
        replyString += tdBegin + rowNumber + tdEnd; 
        replyString += tdBegin + login + ", " + file_name + tdEnd;
      
        
        replyString += "</tr>" + CR; 
                
        return replyString;
    }
}