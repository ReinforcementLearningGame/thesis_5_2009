import java.awt.*;
import register.Games;
public class GamesDialog extends Dialog
{
    boolean registerButtonPressed = false;
    	    
	public GamesDialog(Frame parent, boolean modal,String msg)
	{
		super(parent, modal);
		setLayout(null);
		setSize(insets().left + insets().right + 511,insets().top + insets().bottom + 351);
		helpTextArea = new java.awt.TextArea();
		helpTextArea.setBounds(insets().left + 5,insets().top + 5,500,300);
		String sInfo=" \t\t\t  The game:\n";
        sInfo+=msg;
		helpTextArea.setText(sInfo);helpTextArea.setEditable(false);
		add(helpTextArea);
	    
		registerButton = new java.awt.Button();
		registerButton.setLabel(" O K ");
		registerButton.setBounds(insets().left + 360,insets().top + 312,62,24);
		registerButton.setBackground(java.awt.Color.lightGray);
		add(registerButton);
	
		cancelButton = new java.awt.Button();
		cancelButton.setLabel(" C A N C E L");
		cancelButton.setBounds(insets().left + 432,insets().top + 312,60,24);
		cancelButton.setBackground(java.awt.Color.lightGray);
		add(cancelButton);
		setTitle("RLGame - Web version - v 2.0 - P L A Y E R ");
		

		//{{REGISTER_LISTENERS
		SymWindow aSymWindow = new SymWindow();
		this.addWindowListener(aSymWindow);
		SymAction lSymAction = new SymAction();
		cancelButton.addActionListener(lSymAction);
		registerButton.addActionListener(lSymAction);
		//}}
		
	}
	
	public void addNotify()
	{
  	    // Record the size of the window prior to calling parents addNotify.
	    Dimension d = getSize();

		super.addNotify();

		if (fComponentsAdjusted)
			return;

		// Adjust components according to the insets
		setSize(insets().left + insets().right + d.width, insets().top + insets().bottom + d.height);
		Component components[] = getComponents();
		for (int i = 0; i < components.length; i++)
		{
			Point p = components[i].getLocation();
			p.translate(insets().left, insets().top);
			components[i].setLocation(p);
		}
		fComponentsAdjusted = true;
	}

    // Used for addNotify check.
	boolean fComponentsAdjusted = false;



// 	{{DECLARE_CONTROLS
//	java.awt.Label label1;
	java.awt.TextArea helpTextArea;
//	java.awt.Label label2;
//	java.awt.TextField passwordTextField;
	java.awt.Button registerButton;
	java.awt.Button cancelButton;
//	}}

	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == GamesDialog.this)
				Dialog1_WindowClosing(event);
		}
	}
	
	void Dialog1_WindowClosing(java.awt.event.WindowEvent event)
	{
		dispose();
	}

	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == cancelButton)
				cancelButton_Action(event);
			else if (object == registerButton)
				registerButton_Action(event);
		}
	}

	void cancelButton_Action(java.awt.event.ActionEvent event)
	{
		// to do: code goes here.
        registerButtonPressed = false;		
		this.setVisible(false);
	}
	
	public boolean isRegisterButtonPressed()
	{
	    return registerButtonPressed;    
	}

	void registerButton_Action(java.awt.event.ActionEvent event)
	{
		// to do: code goes here.
		registerButtonPressed = true;
		this.setVisible(false);
        
	}
	
 }
