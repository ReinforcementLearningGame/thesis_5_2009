import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.net.*;
import java.awt.*;

import java.io.FileWriter;
import java.io.OutputStreamWriter;
import register.bariVect;
import register.stat;


public class PlayServletStoreStat extends HttpServlet 
{   
    private String CR = "\n";
    	private int dimbase;
  	private int numofpawns;
  	private int	dimboard;
    private String theLogin; 
      File file;
    private int result;
    FileWriter out;
    /**
	 *  This method is called the first time the servlet is loaded.  Simply
	 *  makes a connection to the database.
	 */
    public void init(ServletConfig config) throws ServletException 
    {
        super.init(config);
  	 	}

	/**
	 *  This method is used for applets.
	 *
	 *  Receives and sends the data using object serialization.
	 *
	 *  Gets an input stream from the applet and reads a player object.  Then
	 *  registers the player using our data accessor.  Finally, sends a confirmation
	 *  message back to the applet.
	 */
      public void doPost(HttpServletRequest request,
                        HttpServletResponse response) 
           throws ServletException, IOException
    {  
        ObjectInputStream inputFromApplet = null;
         
        PrintWriter out3 = null;
        BufferedReader inTest = null;
        stat astat=null;
        ObjectOutputStream outputToApplet;   
        try
        {  
            // get an input stream from the applet
	        inputFromApplet = new ObjectInputStream(request.getInputStream());
	        show("se Connected  Stat");
	         // read the serialized  data from applet        
	        show("se Reading data...");
	        astat = (stat) inputFromApplet.readObject();
	         
	         inputFromApplet.close();
	 		log("login"+ astat.getLogin());
	    	 storestat(astat);   
	    
	         show("ok  ");  
	  
            outputToApplet = new ObjectOutputStream(response.getOutputStream());
            
            System.out.println("Sending stat vector to applet...");
           // outputToApplet.writeObject(WeightVector); 
            outputToApplet.flush();
            
            outputToApplet.close();
            System.out.println("Data transmission complete.");
        }
        catch ( Exception e)
        {	log("lathos piso");
			e.printStackTrace(); 
        } 
         
       
    }  
    
      
 	public  void storestat (stat astat)
   {
   	  Date myDate=new Date();
      String arxiname="/RLGames/Games/"+astat.getLogin()+"/";
      String fileName="_"+astat.getLogin()+"_"+astat.getdimboard()+""+astat.getdimbase()+""+astat.getnumofpawns()+"_game" ;
      String helpName=myDate.toString();
      helpName=helpName.substring(11,19);
      helpName=helpName.replace(':',' ');
      if    (astat.getflag().equals("1"))
     {	 fileName=arxiname+helpName+fileName;
     	System.out.println("game");	
     }
      else
      {		fileName=arxiname+helpName+"stats";
      		System.out.println("stats");	
      }
      fileName=fileName.concat(".txt");
      file=new File(fileName);
      try
      {
        out=new FileWriter(file);
        out.write(astat.getdata());
        out.close();
      }
      catch (IOException e1){System.out.println("error in file "+fileName+".txt");}
    
   }
 
 
     /*
	 *  Destroys the servlet and calls cleanup to close the database connection
	 */
     public void destroy()
    {
        System.out.println("PlayServlet: destroy");
        
    }
    
	/**
	 *  Returns servlet information
	 */
    public String getServletInfo()
    {
        return "<i>Games Registration Servlet, v.06</i>";   
    }
    
	/**
	 *  Simple method for logging messages to the console.
	 */
    protected void show(String msg)
    {
        System.out.println(msg);    
    }
}
