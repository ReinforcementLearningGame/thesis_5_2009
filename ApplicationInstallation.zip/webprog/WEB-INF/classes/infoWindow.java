/***************
  Created by:  Eirini Ntoutsi
  Operation: Creates a parent window
*******/
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.awt.geom.*;
import javax.swing.border.*;


public class infoWindow extends JComponent
{
   private static String title;
   private static String textToShow;
   private static String firstButtonTitle;
   private static String firstButtonTextToShow;
   private Dimension minSize=new Dimension(200,200);
  // static String catalinaHome = "c:/Program Files/Apache Software Foundation/Tomcat 5.5/webapps/webprog/image/";
   //constructor
   public infoWindow(String s1,String s2,String ss1,String ss2)
   {
      super();
      title=s1;
      textToShow=s2;
      firstButtonTitle=ss1;
      firstButtonTextToShow=ss2;
      setSize(minSize);
  }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public Dimension getPreferredSize()
  {
      Container parent=getParent();
      return (parent!=null) ? parent.getSize():minSize;
  }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public Dimension getMinimumSize()
  {
      return minSize;
  }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public void plot()
  {
      repaint();
  }
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
  public static void showInfoWindow()
  {
      final JFrame frame = new JFrame();
      JPanel mainPanel=new JPanel();
      JPanel upPanel=new JPanel();
      JPanel toolbarPanel=new JPanel();
      JScrollPane scrollPanel;
      JTextArea textArea;
      Dimension buttonSize=new Dimension(110,25);
      Dimension frameSize=new Dimension(450,350);
      Dimension dim = new Dimension(200,100);
      Dimension toolbarSize = new Dimension(200,50);
    // Color c= new Color(96,160,96);
		Color c=new Color(153,120,218);	

      frame.setBackground(c);
      frame.setTitle(title);
      frame.setBounds(10,10,460,350);
      mainPanel.setBackground(c);
      mainPanel.setLayout(new BorderLayout());
      upPanel.setBackground(c);
      upPanel.setLayout(new BorderLayout());

      textArea = new JTextArea(textToShow,10,20);
      textArea.setFont(new Font("Comic Sans MS", Font.ROMAN_BASELINE,12));
      textArea.setLineWrap(true);
      textArea.setWrapStyleWord(true);
      textArea.setBackground(c);

      scrollPanel = new JScrollPane(textArea,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
      scrollPanel.setBackground(c);
      scrollPanel.setSize(dim);
      scrollPanel.setPreferredSize(dim);
      scrollPanel.setMinimumSize(dim);
      scrollPanel.setMaximumSize(dim);
      
      
      toolbarPanel.setBackground(c);
      toolbarPanel.setSize(toolbarSize);
      toolbarPanel.setMinimumSize(toolbarSize);
      toolbarPanel.setMaximumSize(toolbarSize);
      toolbarPanel.setPreferredSize(toolbarSize);
      //buttons
      //To moreButton kai o listener tou
      JButton moreButton=new JButton(" M O R E ");
     
      moreButton.setToolTipText("More");
      moreButton.setSize(buttonSize);
      moreButton.setMinimumSize(buttonSize);
      moreButton.setMaximumSize(buttonSize);
      moreButton.setPreferredSize(buttonSize);

      class moreButtonActionListener implements ActionListener
      {
          public void actionPerformed(ActionEvent evt)
          {
              Dimension moreSize=new Dimension(750,600);
              SimpleWindow my = new SimpleWindow(firstButtonTitle,firstButtonTextToShow,moreSize);
              my.showSimpleWindow();
          }
      }
      moreButtonActionListener myMoreAL=new moreButtonActionListener();
      moreButton.addActionListener(myMoreAL);

      //To closeButton kai o listener tou
      JButton closeButton=new JButton(" C L O S E ");
      closeButton.setToolTipText("Close");
      closeButton.setSize(buttonSize);
      closeButton.setMinimumSize(buttonSize);
      closeButton.setMaximumSize(buttonSize);
      closeButton.setPreferredSize(buttonSize);
      class closeButtonActionListener implements ActionListener
      {
         public void actionPerformed(ActionEvent evt)
         {
            frame.dispose();
         }
      }
      closeButtonActionListener myCloseAL=new closeButtonActionListener();
      closeButton.addActionListener(myCloseAL);
      //end of buttons

      toolbarPanel.setLayout(new BoxLayout(toolbarPanel,BoxLayout.X_AXIS));
      toolbarPanel.setBorder(new BevelBorder(BevelBorder.RAISED,Color.gray,Color.gray));
      //prosthese ta buttons sto  toolbar panel
      toolbarPanel.add(BorderLayout.EAST,closeButton);
      toolbarPanel.add(BorderLayout.WEST,moreButton);

      //prosthese sto uppanel to toolbar panel kai to scroll panel
      upPanel.add(BorderLayout.CENTER,scrollPanel);
      //prosthese sto mainpanel to uppanel
      upPanel.add(BorderLayout.SOUTH,toolbarPanel);
      mainPanel.add(BorderLayout.CENTER,upPanel);
      //prosthese to mainPanel sto frame
      frame.getContentPane().setLayout(new BorderLayout());
      frame.getContentPane().add(BorderLayout.CENTER,mainPanel);
      frame.setSize(frameSize);
      frame.setResizable(true);
      frame.setVisible(true);
      frame.addWindowListener(new WindowAdapter()
      {
          public void windowClosing(WindowEvent e)
          {
              frame.dispose();
          }
      });
  }
//this is the end
}