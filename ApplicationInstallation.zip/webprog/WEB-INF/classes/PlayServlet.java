import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.net.*;
import register.stoixeia;
import register.bari;
import register.barimono;

public class PlayServlet extends HttpServlet 
{    
    private String CR = "\n";
     double[][] v;// array of weights between layers 1->2
  	 double[][] w;// array of weights between layers 2->3
   
    /**
	 *  This method is called the first time the servlet is loaded.  Simply
	 *  makes a connection to the database.
	 */
    public void init(ServletConfig config) throws ServletException 
    {
        super.init(config);
  
	}

	/**
	 *  This method is used for applets.
	 *
	 *  Receives and sends the data using object serialization.
	 *
	 *  Gets an input stream from the applet and reads a player object.  Then
	 *  registers the player using our data accessor.  Finally, sends a confirmation
	 *  message back to the applet.
	 */
      public void doPost(HttpServletRequest request,
                        HttpServletResponse response) 
           throws ServletException, IOException
    {   show("se Connected");
        ObjectInputStream inputFromApplet = null;
        Vector weights = null;        
        PrintWriter out = null;
        BufferedReader inTest = null;
        stoixeia astoixeia=null;
        ObjectOutputStream outputToApplet;   
        try
        {  
            // get an input stream from the applet
	        inputFromApplet = new ObjectInputStream(request.getInputStream());
	        show("se Connected");
	     
	        // read the serialized  data from applet        
	        show("se Reading data...");
	        
	         astoixeia = (stoixeia) inputFromApplet.readObject();
	        show("Finished reading.");
	        show("se confirmed  "+astoixeia.getLogin()+"vcv "+astoixeia.getfile_name());
	        inputFromApplet.close();
	       
	        try
	        { ObjectInputStream in = 
	        new ObjectInputStream(new FileInputStream ("/RLGames/Games/"+astoixeia.getLogin()+"/"+astoixeia.getfile_name()));
	        w=(double [] [] ) in.readObject();
	        
	        }   
	        catch (Exception e)
	        { e.printStackTrace();
	        	show ("problem");
	        }
	       
     		int i,j,k;
	   
         /*metatropi array se Vector*/   
   	      Vector<Double> WeightVector = new Vector<Double>(); 
	    
	        for ( i=0;i<w.length;i++)
	        {	for (j=0;j<w[i].length;j++)
	        		{	WeightVector.add (Double.valueOf (w[i][j]));
	        		  	 // 	show("w[ "+i+"]["+j+"]="+w[i][j]);
	        		}
	        }		
	      

	
	         show("ok platservlet "+astoixeia.getfile_name());  
	  
            outputToApplet = new ObjectOutputStream(response.getOutputStream());
                    
            outputToApplet.writeObject(WeightVector); 
            outputToApplet.flush();
            
            outputToApplet.close();
         }
        catch ( Exception e)
        {	log("lathos piso");
			e.printStackTrace(); 
        } 
         
       
    }  
    
   /*
	 *  This method is used by HTML clients and applets.
	 *
	 *  Handles a request and reads information from HTML form data.
	 *
	 *  Figures out if the HTML form is sending a request to register
	 *  or display the player.  Also, handles a request from an applet
	 *  to simply display the player.
	 */
   
	    public void doGet(HttpServletRequest request,
                        HttpServletResponse response) 
           throws ServletException, IOException
    {
        System.out.println("in doGet(...)");
        show("se Connected");
	   	String userOption = null;
        userOption = request.getParameterValues("UserOption")[0];
        String userOption1 = request.getParameterValues("UserOption")[1];
        System.out.println("\n userOption =" + userOption+" "+userOption1); 
        appletDisplayGames(response,userOption);
    
    }

    /**
	 *  This method is used for applets.
	 *
	 *  Displays the players to the applet.  This is accomplished by
	 *  getting the players list and returning a vector of players.  This
	 *  vector is returned to the applet using object serialization.
	 */
     protected void appletDisplayGames(HttpServletResponse response,String name)
    {String catalinaHome = "/RLGames/Games/";	
     try
     {  ObjectInputStream in = new ObjectInputStream(new FileInputStream(catalinaHome+name));
        Vector weightVector =(Vector) in.readObject();
         System.out.println("okay, building vector");
        // send the player vector back to the applet using 
        // object serialization
        System.out.println("sending response");
        sendGamesList(response, weightVector);
       }
        catch (Exception e)
        {	System.out.println("asdsaD");
			e.printStackTrace(); 
        } 
      
    }
    
   
     protected void sendGamesList(HttpServletResponse response, Vector weightVector)
    {
        ObjectOutputStream outputToApplet;
        
        try
        {
            outputToApplet = new ObjectOutputStream(response.getOutputStream());
            
            System.out.println("Sending weight vector to applet...");
            outputToApplet.writeObject(weightVector);
            outputToApplet.flush();
            
            outputToApplet.close();
            System.out.println("Data transmission complete.");
        }
        catch (IOException e)
        {
			e.printStackTrace(); 
        }
    }
    
        /*
	 *  Destroys the servlet and calls cleanup to close the database connection
	 */
     public void destroy()
    {
        System.out.println("PlayServlet: destroy");
        
    }
    
	/**
	 *  Returns servlet information
	 */
    public String getServletInfo()
    {
        return "<i>Games Registration Servlet, v.06</i>";   
    }
    
	/**
	 *  Simple method for logging messages to the console.
	 */
    protected void show(String msg)
    {
        System.out.println(msg);    
    }
}
